const CACHE_NAME = 'expiryalert-static-v4';
const SNAPSHOT_CACHE = 'expiryalert-reminder-snapshot-v1';
const SNAPSHOT_KEY = '/__ea_reminder_snapshot.json';

const STATIC_ASSETS = [
  '/',
  '/manifest.webmanifest',
  '/icon.svg',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch(() => undefined);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_NAME && k !== SNAPSHOT_CACHE)
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  let url;
  try {
    url = new URL(event.request.url);
  } catch {
    return;
  }

  // Only handle same-origin static/navigation requests
  if (url.origin !== self.location.origin) return;
  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches
            .open(CACHE_NAME)
            .then((cache) => cache.put(event.request, clone))
            .catch(() => undefined);
        }
        return response;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        if (event.request.mode === 'navigate') {
          const fallback = await caches.match('/');
          if (fallback) return fallback;
        }
        return Response.error();
      })
  );
});

function showLockscreenNotification(payload) {
  const title = (payload && payload.title) || 'ExpiryAlert Reminder';
  const body =
    (payload && payload.body) || 'You have food items approaching or past their expiry date.';
  const url = (payload && payload.url) || '/#/household/reminders';
  const tag = (payload && payload.tag) || 'expiryalert-reminder';

  const options = {
    body,
    icon: '/pwa-192x192.png',
    badge: '/pwa-192x192.png',
    tag,
    renotify: true,
    requireInteraction: Boolean(payload && payload.requireInteraction !== false),
    vibrate: [200, 100, 200],
    timestamp: Date.now(),
    data: { url },
    actions: [
      { action: 'open', title: 'View Reminders' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
  };

  return self.registration.showNotification(title, options);
}

async function saveReminderSnapshot(snapshot) {
  const cache = await caches.open(SNAPSHOT_CACHE);
  await cache.put(
    SNAPSHOT_KEY,
    new Response(JSON.stringify(snapshot), {
      headers: { 'Content-Type': 'application/json' },
    })
  );
}

async function evaluateBackgroundReminderSnapshot() {
  try {
    const cache = await caches.open(SNAPSHOT_CACHE);
    const res = await cache.match(SNAPSHOT_KEY);
    if (!res) return;
    const snap = await res.json();
    if (!snap || !snap.notificationsEnabled) return;

    const today = new Date().toISOString().slice(0, 10);
    if (snap.dueHouseholdCount > 0) {
      await showLockscreenNotification({
        title: `Household: ${snap.dueHouseholdCount} item(s) need attention`,
        body: snap.householdSummary || 'Check your pantry items approaching expiry.',
        url: '/#/household/reminders',
        tag: `ea-bg-household-${today}`,
      });
    }
    if (snap.dueSupermarketCount > 0) {
      await showLockscreenNotification({
        title: `Supermarket: ${snap.dueSupermarketCount} batch(es) need attention`,
        body: snap.supermarketSummary || 'Check retail batches approaching expiry.',
        url: '/#/supermarket/reminders',
        tag: `ea-bg-supermarket-${today}`,
      });
    }
  } catch {
    // ignore snapshot read errors
  }
}

self.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'SHOW_EXPIRY_NOTIFICATION') {
    event.waitUntil(showLockscreenNotification(msg.payload));
  } else if (msg.type === 'SCHEDULE_EXPIRY_NOTIFICATION') {
    const delayMs = Math.max(0, Math.min(60000, Number(msg.delayMs) || 5000));
    event.waitUntil(
      new Promise((resolve) => {
        setTimeout(() => {
          showLockscreenNotification(msg.payload).then(resolve, resolve);
        }, delayMs);
      })
    );
  } else if (msg.type === 'SYNC_REMINDER_SNAPSHOT' && msg.snapshot) {
    event.waitUntil(saveReminderSnapshot(msg.snapshot));
  }
});

// Handles both standard Web Push and Firebase Cloud Messaging (FCM) background payloads
self.addEventListener('push', (event) => {
  let raw = {};
  if (event.data) {
    try {
      raw = event.data.json();
    } catch {
      raw = { body: event.data.text() };
    }
  }

  const notif = raw.notification || {};
  const data = raw.data || {};
  const payload = {
    title: notif.title || data.title || raw.title || 'ExpiryAlert Reminder',
    body: notif.body || data.body || raw.body || 'Check your upcoming food expiry reminders.',
    url: data.url || raw.url || '/#/household/reminders',
    tag: data.tag || raw.tag || 'expiryalert-fcm',
    requireInteraction: true,
  };

  event.waitUntil(showLockscreenNotification(payload));
});

self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'expiryalert-daily-check') {
    event.waitUntil(evaluateBackgroundReminderSnapshot());
  }
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'dismiss') {
    return;
  }
  const targetUrl = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          if ('navigate' in client) {
            client.navigate(targetUrl).catch(() => undefined);
          }
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
      return undefined;
    })
  );
});
