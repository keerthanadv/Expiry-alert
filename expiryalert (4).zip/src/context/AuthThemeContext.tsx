import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  reload,
  sendEmailVerification,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import { auth, testFirestoreConnection } from '../firebase/config.ts';
import {
  clearDemoSandbox,
  getDemoSandbox,
  loadOrCreateUserProfile,
  startDemoSandbox,
  updateUserProfile,
} from '../services/dataService.ts';
import type {
  AccountType,
  FontSizePref,
  OperatingMode,
  ThemeMode,
  UserProfile,
} from '../types/index.ts';
import {
  computeAccessibleAccent,
  DEFAULT_DARK_ACCENT,
  DEFAULT_LIGHT_ACCENT,
  type ComputedAccentPalette,
} from '../utils/colorContrast.ts';

interface AuthThemeContextValue {
  user: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  needsEmailVerification: boolean;
  loadingAuth: boolean;
  theme: ThemeMode;
  accentColor: string;
  fontSize: FontSizePref;
  activeMode: OperatingMode;
  accentPalette: ComputedAccentPalette;
  setPendingRegistrationMeta: (meta: {
    fullName: string;
    accountType: AccountType;
    preferredMode: OperatingMode;
  }) => void;
  refreshVerificationStatus: () => Promise<boolean>;
  resendVerificationEmail: () => Promise<void>;
  enterDemoSandbox: (mode: OperatingMode) => UserProfile;
  refreshUser: () => Promise<UserProfile | null>;
  setUser: React.Dispatch<React.SetStateAction<UserProfile | null>>;
  setActiveMode: (mode: OperatingMode) => void;
  updateAppearance: (prefs: {
    theme?: ThemeMode;
    accentColor?: string;
    fontSize?: FontSizePref;
  }) => Promise<void>;
  resetAppearance: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthThemeContext = createContext<AuthThemeContextValue | null>(null);

const LOCAL_PREFS_KEY = 'expiryalert_guest_prefs_v1';

interface GuestPrefs {
  theme: ThemeMode;
  accentColor: string;
  fontSize: FontSizePref;
}

function loadGuestPrefs(): GuestPrefs {
  try {
    const raw = localStorage.getItem(LOCAL_PREFS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<GuestPrefs>;
      return {
        theme: parsed.theme === 'dark' ? 'dark' : 'light',
        accentColor:
          typeof parsed.accentColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(parsed.accentColor)
            ? parsed.accentColor
            : parsed.theme === 'dark'
            ? DEFAULT_DARK_ACCENT
            : DEFAULT_LIGHT_ACCENT,
        fontSize:
          parsed.fontSize === 'small' || parsed.fontSize === 'large' ? parsed.fontSize : 'medium',
      };
    }
  } catch {
    // ignore storage errors
  }
  return { theme: 'light', accentColor: DEFAULT_LIGHT_ACCENT, fontSize: 'medium' };
}

export const AuthThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialGuest = useMemo(() => loadGuestPrefs(), []);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [needsEmailVerification, setNeedsEmailVerification] = useState(false);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [guestPrefs, setGuestPrefs] = useState<GuestPrefs>(initialGuest);
  const [activeMode, setActiveModeState] = useState<OperatingMode>('household');

  const userRef = useRef<UserProfile | null>(null);
  userRef.current = user;
  const activeModeRef = useRef<OperatingMode>(activeMode);
  activeModeRef.current = activeMode;
  const pendingMetaRef = useRef<{
    fullName?: string;
    accountType?: AccountType;
    preferredMode?: OperatingMode;
  } | null>(null);

  const theme: ThemeMode = user ? user.theme : guestPrefs.theme;
  const accentColor: string = user ? user.accentColor : guestPrefs.accentColor;
  const fontSize: FontSizePref = user ? user.fontSize : guestPrefs.fontSize;

  const accentPalette = useMemo(
    () => computeAccessibleAccent(accentColor, theme),
    [accentColor, theme]
  );

  // Sync theme, CSS accent variables, and font scale onto document.documentElement
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    root.style.setProperty('--accent', accentPalette.accent);
    root.style.setProperty('--accent-fg', accentPalette.accentFg);
    root.style.setProperty('--accent-text', accentPalette.accentText);
    root.style.setProperty('--accent-soft', accentPalette.accentSoft);
    root.style.setProperty('--accent-ring', accentPalette.accentRing);

    const scale = fontSize === 'small' ? '0.92' : fontSize === 'large' ? '1.08' : '1';
    root.style.setProperty('--font-scale', scale);

    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', accentPalette.accent);
    }
  }, [theme, accentPalette, fontSize]);

  useEffect(() => {
    void testFirestoreConnection();

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (!fbUser) {
        setNeedsEmailVerification(false);
        const sandbox = getDemoSandbox();
        if (sandbox) {
          setUser(sandbox.user);
          setActiveModeState(sandbox.user.preferredMode);
        } else {
          setUser(null);
        }
        setLoadingAuth(false);
        return;
      }

      clearDemoSandbox();
      if (!fbUser.emailVerified) {
        setNeedsEmailVerification(true);
        setUser(null);
        setLoadingAuth(false);
        return;
      }

      setNeedsEmailVerification(false);
      try {
        const meta = pendingMetaRef.current ?? undefined;
        pendingMetaRef.current = null;
        const profile = await loadOrCreateUserProfile(fbUser, meta);
        setUser(profile);
        setActiveModeState(profile.preferredMode);
      } catch (err) {
        console.error('Failed to load profile:', err);
        setUser(null);
      } finally {
        setLoadingAuth(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const setPendingRegistrationMeta = useCallback(
    (meta: { fullName: string; accountType: AccountType; preferredMode: OperatingMode }) => {
      pendingMetaRef.current = meta;
    },
    []
  );

  const refreshVerificationStatus = useCallback(async (): Promise<boolean> => {
    const cur = auth.currentUser;
    if (!cur) return false;
    await reload(cur);
    // Force refresh ID token so email_verified claim updates immediately for Firestore rules
    await cur.getIdToken(true);
    setFirebaseUser(cur);
    if (cur.emailVerified) {
      setNeedsEmailVerification(false);
      const profile = await loadOrCreateUserProfile(cur, pendingMetaRef.current ?? undefined);
      pendingMetaRef.current = null;
      setUser(profile);
      setActiveModeState(profile.preferredMode);
      return true;
    }
    return false;
  }, []);

  const resendVerificationEmail = useCallback(async (): Promise<void> => {
    const cur = auth.currentUser;
    if (!cur) throw new Error('No pending user session found.');
    await sendEmailVerification(cur);
  }, []);

  const enterDemoSandbox = useCallback((mode: OperatingMode): UserProfile => {
    const sandbox = startDemoSandbox(mode);
    setNeedsEmailVerification(false);
    setUser(sandbox.user);
    setActiveModeState(mode);
    return sandbox.user;
  }, []);

  const refreshUser = useCallback(async (): Promise<UserProfile | null> => {
    const sandbox = getDemoSandbox();
    if (sandbox) {
      setUser({ ...sandbox.user });
      return sandbox.user;
    }
    const cur = auth.currentUser;
    if (!cur || !cur.emailVerified) {
      setUser(null);
      return null;
    }
    const profile = await loadOrCreateUserProfile(cur);
    setUser(profile);
    return profile;
  }, []);

  const setActiveMode = useCallback((mode: OperatingMode) => {
    const currentUser = userRef.current;
    if (activeModeRef.current !== mode) {
      activeModeRef.current = mode;
      setActiveModeState(mode);
    }
    if (currentUser && currentUser.preferredMode !== mode) {
      setUser((prev) => (prev && prev.preferredMode !== mode ? { ...prev, preferredMode: mode } : prev));
      void updateUserProfile(currentUser.uid, { preferredMode: mode }).catch(() => undefined);
    }
  }, []);

  const updateAppearance = useCallback(
    async (prefs: { theme?: ThemeMode; accentColor?: string; fontSize?: FontSizePref }) => {
      const nextTheme = prefs.theme ?? theme;
      let nextAccent = prefs.accentColor ?? accentColor;
      if (prefs.theme && !prefs.accentColor) {
        if (prefs.theme === 'dark' && accentColor.toUpperCase() === DEFAULT_LIGHT_ACCENT) {
          nextAccent = DEFAULT_DARK_ACCENT;
        } else if (prefs.theme === 'light' && accentColor.toUpperCase() === DEFAULT_DARK_ACCENT) {
          nextAccent = DEFAULT_LIGHT_ACCENT;
        }
      }
      const nextFont = prefs.fontSize ?? fontSize;

      const updatedGuest: GuestPrefs = {
        theme: nextTheme,
        accentColor: nextAccent,
        fontSize: nextFont,
      };
      setGuestPrefs(updatedGuest);
      try {
        localStorage.setItem(LOCAL_PREFS_KEY, JSON.stringify(updatedGuest));
      } catch {
        // ignore storage errors
      }

      if (user) {
        setUser((prev) =>
          prev
            ? {
                ...prev,
                theme: nextTheme,
                accentColor: nextAccent,
                fontSize: nextFont,
              }
            : prev
        );
        try {
          const updated = await updateUserProfile(user.uid, {
            theme: nextTheme,
            accentColor: nextAccent,
            fontSize: nextFont,
          });
          setUser(updated);
        } catch {
          // Keep optimistic local preference on transient error
        }
      }
    },
    [theme, accentColor, fontSize, user]
  );

  const resetAppearance = useCallback(async () => {
    await updateAppearance({
      theme: 'light',
      accentColor: DEFAULT_LIGHT_ACCENT,
      fontSize: 'medium',
    });
  }, [updateAppearance]);

  const logout = useCallback(async () => {
    clearDemoSandbox();
    setNeedsEmailVerification(false);
    setUser(null);
    if (auth.currentUser) {
      await signOut(auth);
    }
  }, []);

  return (
    <AuthThemeContext.Provider
      value={{
        user,
        firebaseUser,
        needsEmailVerification,
        loadingAuth,
        theme,
        accentColor,
        fontSize,
        activeMode,
        accentPalette,
        setPendingRegistrationMeta,
        refreshVerificationStatus,
        resendVerificationEmail,
        enterDemoSandbox,
        refreshUser,
        setUser,
        setActiveMode,
        updateAppearance,
        resetAppearance,
        logout,
      }}
    >
      {children}
    </AuthThemeContext.Provider>
  );
};

export function useAuthTheme(): AuthThemeContextValue {
  const ctx = useContext(AuthThemeContext);
  if (!ctx) {
    throw new Error('useAuthTheme must be used inside AuthThemeProvider');
  }
  return ctx;
}
