import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppShell, type AppRoute } from './components/AppShell.tsx';
import { AtmosphericFoodBackdrop } from './components/BrandMark.tsx';
import { AuthThemeProvider, useAuthTheme } from './context/AuthThemeContext.tsx';
import {
  EmailVerificationGatePage,
  ForgotPasswordPage,
  LoginPage,
  RegisterPage,
} from './pages/AuthPages.tsx';
import {
  HouseholdDashboardPage,
  HouseholdProductDetailsPage,
  HouseholdProductFormPage,
  HouseholdProductsPage,
  HouseholdRemindersPage,
  type HouseholdDataBundle,
} from './pages/HouseholdPages.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { NotificationPreferencesPage, SettingsPage } from './pages/SettingsPages.tsx';
import {
  SupermarketBatchManagementPage,
  SupermarketDashboardPage,
  SupermarketProductDetailsPage,
  SupermarketProductFormPage,
  SupermarketProductsPage,
  SupermarketRemindersPage,
  type SupermarketDataBundle,
} from './pages/SupermarketPages.tsx';
import {
  createNotificationRecord,
  fetchHouseholdData,
  fetchNotifications,
  fetchSupermarketData,
} from './services/dataService.ts';
import type {
  HouseholdProduct,
  NotificationHistoryItem,
  ProductActionLog,
  ReminderStateRecord,
  SupermarketBatch,
  SupermarketCategory,
  SupermarketProduct,
} from './types/index.ts';
import { computeExpiryStatus, getTodayIso } from './utils/expiry.ts';
import {
  dispatchLockscreenNotification,
  registerFcmDeviceToken,
  scheduleLockscreenNotification,
  syncBackgroundReminderSnapshot,
} from './utils/notifications.ts';

function parseHashRoute(): AppRoute {
  const hash = window.location.hash.replace(/^#/, '');
  if (!hash || hash === '/') return { name: 'landing' };
  const parts = hash.split('/').filter(Boolean);
  const [a, b, c] = parts;

  if (a === 'login')
    return {
      name: 'login',
      initialMode: b === 'supermarket' ? 'supermarket' : b === 'household' ? 'household' : undefined,
    };
  if (a === 'register')
    return {
      name: 'register',
      initialMode: b === 'supermarket' ? 'supermarket' : b === 'household' ? 'household' : undefined,
    };
  if (a === 'forgot-password') return { name: 'forgot-password' };
  if (a === 'settings') return { name: 'settings' };
  if (a === 'notifications') return { name: 'notifications' };

  if (a === 'household') {
    if (b === 'products' && c) return { name: 'household-details', id: decodeURIComponent(c) };
    if (b === 'edit' && c) return { name: 'household-edit', id: decodeURIComponent(c) };
    if (b === 'products') return { name: 'household-products' };
    if (b === 'add') return { name: 'household-add' };
    if (b === 'reminders') return { name: 'household-reminders' };
    return { name: 'household-dashboard' };
  }

  if (a === 'supermarket') {
    if (b === 'products' && c) return { name: 'supermarket-details', id: decodeURIComponent(c) };
    if (b === 'edit' && c) return { name: 'supermarket-edit', id: decodeURIComponent(c) };
    if (b === 'products') return { name: 'supermarket-products' };
    if (b === 'add') return { name: 'supermarket-add' };
    if (b === 'batches') return { name: 'supermarket-batches' };
    if (b === 'reminders') return { name: 'supermarket-reminders' };
    return { name: 'supermarket-dashboard' };
  }

  return { name: 'landing' };
}

function routeToHash(route: AppRoute): string {
  switch (route.name) {
    case 'landing':
      return '#/';
    case 'login':
      return route.initialMode ? `#/login/${route.initialMode}` : '#/login';
    case 'register':
      return route.initialMode ? `#/register/${route.initialMode}` : '#/register';
    case 'forgot-password':
      return '#/forgot-password';
    case 'household-dashboard':
      return '#/household/dashboard';
    case 'household-products':
      return '#/household/products';
    case 'household-add':
      return '#/household/add';
    case 'household-edit':
      return `#/household/edit/${encodeURIComponent(route.id)}`;
    case 'household-details':
      return `#/household/products/${encodeURIComponent(route.id)}`;
    case 'household-reminders':
      return '#/household/reminders';
    case 'supermarket-dashboard':
      return '#/supermarket/dashboard';
    case 'supermarket-products':
      return '#/supermarket/products';
    case 'supermarket-add':
      return '#/supermarket/add';
    case 'supermarket-edit':
      return `#/supermarket/edit/${encodeURIComponent(route.id)}`;
    case 'supermarket-details':
      return `#/supermarket/products/${encodeURIComponent(route.id)}`;
    case 'supermarket-batches':
      return '#/supermarket/batches';
    case 'supermarket-reminders':
      return '#/supermarket/reminders';
    case 'settings':
      return '#/settings';
    case 'notifications':
      return '#/notifications';
  }
}

function getCurrentTimeHHMM(): string {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

const AppContent: React.FC = () => {
  const { user, needsEmailVerification, loadingAuth, activeMode, setActiveMode } = useAuthTheme();
  const userId = user?.uid ?? null;
  const [route, setRoute] = useState<AppRoute>(() => parseHashRoute());

  // Household state
  const [hProducts, setHProducts] = useState<HouseholdProduct[]>([]);
  const [hActions, setHActions] = useState<ProductActionLog[]>([]);
  const [hReminderStates, setHReminderStates] = useState<ReminderStateRecord[]>([]);
  const [hLoading, setHLoading] = useState(false);

  // Supermarket state
  const [sCategories, setSCategories] = useState<SupermarketCategory[]>([]);
  const [sProducts, setSProducts] = useState<SupermarketProduct[]>([]);
  const [sBatches, setSBatches] = useState<SupermarketBatch[]>([]);
  const [sActions, setSActions] = useState<ProductActionLog[]>([]);
  const [sReminderStates, setSReminderStates] = useState<ReminderStateRecord[]>([]);
  const [sLoading, setSLoading] = useState(false);

  // Notification history & active day/minute tick
  const [notifications, setNotifications] = useState<NotificationHistoryItem[]>([]);
  const [activeDay, setActiveDay] = useState<string>(() => getTodayIso());
  const [clockHHMM, setClockHHMM] = useState<string>(() => getCurrentTimeHHMM());
  const notifiedKeyRef = useRef<string | null>(null);
  const fcmRegisteredUidRef = useRef<string | null>(null);

  const navigate = useCallback((next: AppRoute) => {
    window.location.hash = routeToHash(next);
    setRoute(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onHashChange = () => setRoute(parseHashRoute());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const loadHousehold = useCallback(async () => {
    if (!userId) return;
    setHLoading(true);
    try {
      const res = await fetchHouseholdData(userId);
      setHProducts(res.products);
      setHActions(res.actions);
      setHReminderStates(res.reminderStates);
    } finally {
      setHLoading(false);
    }
  }, [userId]);

  const loadSupermarket = useCallback(async () => {
    if (!userId) return;
    setSLoading(true);
    try {
      const res = await fetchSupermarketData(userId);
      setSCategories(res.categories);
      setSProducts(res.products);
      setSBatches(res.batches);
      setSActions(res.actions);
      setSReminderStates(res.reminderStates);
    } finally {
      setSLoading(false);
    }
  }, [userId]);

  const loadNotifications = useCallback(async () => {
    if (!userId) return;
    const items = await fetchNotifications(userId);
    setNotifications(items);
  }, [userId]);

  const reloadAll = useCallback(async () => {
    if (!userId) return;
    try {
      await Promise.all([loadHousehold(), loadSupermarket(), loadNotifications()]);
    } catch {
      // Prevent unhandled promise rejections on transient offline/network blips
    }
  }, [userId, loadHousehold, loadSupermarket, loadNotifications]);

  useEffect(() => {
    if (userId) {
      void reloadAll();
    } else {
      fcmRegisteredUidRef.current = null;
      setHProducts([]);
      setHActions([]);
      setHReminderStates([]);
      setSCategories([]);
      setSProducts([]);
      setSBatches([]);
      setSActions([]);
      setSReminderStates([]);
      setNotifications([]);
    }
  }, [userId, reloadAll]);

  // Register FCM device push token & foreground handler for verified cloud accounts
  useEffect(() => {
    if (!user || user.isDemoSession || !user.notificationsEnabled) return;
    if (fcmRegisteredUidRef.current === user.uid) return;
    fcmRegisteredUidRef.current = user.uid;

    void registerFcmDeviceToken(user.uid, (payload) => {
      void dispatchLockscreenNotification(payload);
      void createNotificationRecord(user.uid, {
        mode: payload.url?.includes('supermarket') ? 'supermarket' : 'household',
        title: payload.title,
        message: payload.body,
        channel: 'fcm',
      })
        .then(() => loadNotifications())
        .catch(() => undefined);
    });
  }, [user, loadNotifications]);

  // Sync activeDay & current HH:MM on focus/visibility regain or periodic interval
  useEffect(() => {
    const syncClock = () => {
      const currentDay = getTodayIso();
      setActiveDay((prev) => (prev === currentDay ? prev : currentDay));
      setClockHHMM(getCurrentTimeHHMM());
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncClock();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    const interval = window.setInterval(syncClock, 60 * 1000);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.clearInterval(interval);
    };
  }, []);

  // Compute due items, sync Service Worker background reminder snapshot, and fire scheduled daily alert
  useEffect(() => {
    if (!user || hLoading || sLoading) return;

    const defaultDays = user.defaultReminderDays ?? 5;
    const hDue = hProducts.filter((p) => {
      if (p.quantity <= 0) return false;
      const calc = computeExpiryStatus(p.expiryDate, p.reminderDays ?? defaultDays);
      return calc.daysRemaining <= (p.reminderDays ?? defaultDays);
    });
    const sDue = sBatches.filter((b) => {
      if (b.remainingQuantity <= 0) return false;
      const prod = sProducts.find((p) => p.id === b.productId);
      const thresh = prod?.reminderDays ?? defaultDays;
      const calc = computeExpiryStatus(b.expiryDate, thresh);
      return calc.daysRemaining <= thresh;
    });

    const householdSummary =
      hDue.length > 0
        ? `${hDue
            .slice(0, 3)
            .map((i) => i.name)
            .join(', ')}${hDue.length > 3 ? ' and more' : ''} approaching or past expiry.`
        : '';
    const supermarketSummary =
      sDue.length > 0
        ? `${sDue
            .slice(0, 3)
            .map((b) => `${b.productName} (${b.batchNumber})`)
            .join(', ')}${sDue.length > 3 ? ' and more' : ''} approaching or past expiry.`
        : '';

    void syncBackgroundReminderSnapshot({
      uid: user.uid,
      notificationsEnabled: user.notificationsEnabled,
      scheduleTime: user.reminderScheduleTime || '09:00',
      dueHouseholdCount: user.accountType === 'supermarket' ? 0 : hDue.length,
      dueSupermarketCount: user.accountType === 'household' ? 0 : sDue.length,
      householdSummary,
      supermarketSummary,
      updatedAt: new Date().toISOString(),
    });

    if (!user.notificationsEnabled) return;
    if (hDue.length === 0 && sDue.length === 0) return;

    const scheduleHHMM = user.reminderScheduleTime || '09:00';
    if (clockHHMM < scheduleHHMM) return;

    const storageKey = `ea_notified_${user.uid}_${activeDay}`;
    if (notifiedKeyRef.current === storageKey) return;
    try {
      if (localStorage.getItem(storageKey)) {
        notifiedKeyRef.current = storageKey;
        return;
      }
    } catch {
      // ignore
    }

    notifiedKeyRef.current = storageKey;
    try {
      localStorage.setItem(storageKey, '1');
    } catch {
      // ignore
    }

    (async () => {
      if (hDue.length > 0 && (user.accountType === 'household' || user.accountType === 'both')) {
        const title = `Household: ${hDue.length} item(s) need attention`;
        const channel = await dispatchLockscreenNotification({
          title,
          body: householdSummary,
          url: '/#/household/reminders',
          tag: `ea-household-due-${activeDay}`,
        });
        await createNotificationRecord(user.uid, {
          mode: 'household',
          title,
          message: householdSummary,
          channel,
        }).catch(() => undefined);
      }
      if (sDue.length > 0 && (user.accountType === 'supermarket' || user.accountType === 'both')) {
        const title = `Supermarket: ${sDue.length} batch(es) need attention`;
        const channel = await dispatchLockscreenNotification({
          title,
          body: supermarketSummary,
          url: '/#/supermarket/reminders',
          tag: `ea-supermarket-due-${activeDay}`,
        });
        await createNotificationRecord(user.uid, {
          mode: 'supermarket',
          title,
          message: supermarketSummary,
          channel,
        }).catch(() => undefined);
      }
      await loadNotifications();
    })();
  }, [
    user,
    activeDay,
    clockHHMM,
    hProducts,
    sBatches,
    sProducts,
    hLoading,
    sLoading,
    loadNotifications,
  ]);

  // Keep activeMode synced with permitted route
  useEffect(() => {
    if (!user) return;
    if (
      route.name.startsWith('supermarket-') &&
      activeMode !== 'supermarket' &&
      (user.accountType === 'supermarket' || user.accountType === 'both')
    ) {
      setActiveMode('supermarket');
    } else if (
      route.name.startsWith('household-') &&
      activeMode !== 'household' &&
      (user.accountType === 'household' || user.accountType === 'both')
    ) {
      setActiveMode('household');
    }
  }, [route.name, activeMode, setActiveMode, user]);

  const householdBundle: HouseholdDataBundle = useMemo(
    () => ({
      products: hProducts,
      actions: hActions,
      reminderStates: hReminderStates,
      loading: hLoading,
      reload: loadHousehold,
    }),
    [hProducts, hActions, hReminderStates, hLoading, loadHousehold]
  );

  const supermarketBundle: SupermarketDataBundle = useMemo(
    () => ({
      categories: sCategories,
      products: sProducts,
      batches: sBatches,
      actions: sActions,
      reminderStates: sReminderStates,
      loading: sLoading,
      reload: loadSupermarket,
    }),
    [sCategories, sProducts, sBatches, sActions, sReminderStates, sLoading, loadSupermarket]
  );

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.isRead).length,
    [notifications]
  );

  const handleSendTestNotification = async (delayMs = 0) => {
    if (!user) return;
    const mode =
      route.name.startsWith('supermarket-') || activeMode === 'supermarket'
        ? 'supermarket'
        : 'household';
    const defaultDays = user.defaultReminderDays ?? 5;

    let msg = 'Your lock-screen and device expiry reminders are active.';
    if (mode === 'household') {
      const hDue = hProducts.filter((p) => {
        if (p.quantity <= 0) return false;
        const calc = computeExpiryStatus(p.expiryDate, p.reminderDays ?? defaultDays);
        return calc.daysRemaining <= (p.reminderDays ?? defaultDays);
      });
      if (hDue.length > 0) {
        msg = `${hDue.length} item(s) need attention (${hDue
          .slice(0, 2)
          .map((p) => p.name)
          .join(', ')}${hDue.length > 2 ? ', ...' : ''}). Tap to view reminders.`;
      }
    } else {
      const sDue = sBatches.filter((b) => {
        if (b.remainingQuantity <= 0) return false;
        const prod = sProducts.find((p) => p.id === b.productId);
        const thresh = prod?.reminderDays ?? defaultDays;
        const calc = computeExpiryStatus(b.expiryDate, thresh);
        return calc.daysRemaining <= thresh;
      });
      if (sDue.length > 0) {
        msg = `${sDue.length} batch(es) need attention (${sDue
          .slice(0, 2)
          .map((b) => `${b.productName} ${b.batchNumber}`)
          .join(', ')}${sDue.length > 2 ? ', ...' : ''}). Tap to view reminders.`;
      }
    }

    const title = delayMs > 0 ? 'ExpiryAlert Lock-Screen Alert' : 'ExpiryAlert Test Alert';
    const payload = {
      title,
      body: msg,
      url: mode === 'supermarket' ? '/#/supermarket/reminders' : '/#/household/reminders',
      tag: `ea-test-${Date.now()}`,
      requireInteraction: true,
    };

    let channel: 'browser' | 'in_app' = 'in_app';
    if (delayMs > 0) {
      const scheduled = await scheduleLockscreenNotification(payload, delayMs);
      channel = scheduled === 'in_app' ? 'in_app' : 'browser';
    } else {
      channel = await dispatchLockscreenNotification(payload);
    }

    await createNotificationRecord(user.uid, {
      mode,
      title,
      message: msg,
      channel,
    });
    await loadNotifications();
  };

  if (loadingAuth) {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="ea-glass rounded-2xl px-6 py-4 text-sm font-medium">
            Loading ExpiryAlert...
          </div>
        </div>
      </>
    );
  }

  // Public routes
  if (route.name === 'landing') {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <LandingPage navigate={navigate} />
      </>
    );
  }
  if (route.name === 'forgot-password') {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <ForgotPasswordPage navigate={navigate} />
      </>
    );
  }

  // Email verification gate blocks app workspace & post-signup auth screens until verified
  if (needsEmailVerification) {
    const modeHint =
      'initialMode' in route && route.initialMode
        ? route.initialMode
        : route.name.startsWith('supermarket-')
        ? 'supermarket'
        : 'household';
    return (
      <>
        <AtmosphericFoodBackdrop />
        <EmailVerificationGatePage initialMode={modeHint} navigate={navigate} />
      </>
    );
  }

  if (route.name === 'login') {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <LoginPage initialMode={route.initialMode} navigate={navigate} />
      </>
    );
  }
  if (route.name === 'register') {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <RegisterPage initialMode={route.initialMode} navigate={navigate} />
      </>
    );
  }

  // Protected routes: redirect to login if unauthenticated
  if (!user) {
    return (
      <>
        <AtmosphericFoodBackdrop />
        <LoginPage
          initialMode={route.name.startsWith('supermarket-') ? 'supermarket' : 'household'}
          navigate={navigate}
        />
      </>
    );
  }

  const supermarketDenied =
    route.name.startsWith('supermarket-') && user.accountType === 'household';
  const householdDenied =
    route.name.startsWith('household-') && user.accountType === 'supermarket';

  let pageView: React.ReactNode = null;
  if (supermarketDenied || householdDenied) {
    const allowedRoute: AppRoute =
      user.accountType === 'supermarket'
        ? { name: 'supermarket-dashboard' }
        : { name: 'household-dashboard' };
    const allowedLabel =
      user.accountType === 'supermarket' ? 'Supermarket Dashboard' : 'Household Dashboard';
    const requestedLabel = supermarketDenied ? 'Supermarket Mode' : 'Household Mode';

    pageView = (
      <div className="max-w-lg mx-auto ea-glass rounded-3xl p-7 sm:p-8 text-center space-y-4 mt-8">
        <h1 className="font-display text-xl font-bold">{requestedLabel} Not Enabled</h1>
        <p className="text-sm text-[var(--text-secondary)]">
          Your account is currently configured for{' '}
          <strong className="text-[var(--text-primary)]">
            {user.accountType === 'supermarket' ? 'Supermarket only' : 'Household only'}
          </strong>
          . You can switch to both modes anytime in Settings.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate(allowedRoute)}
            className="ea-btn-accent rounded-xl px-4 py-2.5 text-sm font-semibold cursor-pointer"
          >
            Open {allowedLabel}
          </button>
          <button
            type="button"
            onClick={() => navigate({ name: 'settings' })}
            className="ea-surface rounded-xl px-4 py-2.5 text-sm font-medium cursor-pointer"
          >
            Update in Settings
          </button>
        </div>
      </div>
    );
  } else {
    switch (route.name) {
      case 'household-dashboard':
        pageView = <HouseholdDashboardPage data={householdBundle} navigate={navigate} />;
        break;
      case 'household-products':
        pageView = <HouseholdProductsPage data={householdBundle} navigate={navigate} />;
        break;
      case 'household-add':
        pageView = <HouseholdProductFormPage data={householdBundle} navigate={navigate} />;
        break;
      case 'household-edit': {
        const target = hProducts.find((p) => p.id === route.id) ?? null;
        pageView = (
          <HouseholdProductFormPage
            editingProduct={target}
            data={householdBundle}
            navigate={navigate}
          />
        );
        break;
      }
      case 'household-details':
        pageView = (
          <HouseholdProductDetailsPage
            productId={route.id}
            data={householdBundle}
            navigate={navigate}
          />
        );
        break;
      case 'household-reminders':
        pageView = <HouseholdRemindersPage data={householdBundle} navigate={navigate} />;
        break;

      case 'supermarket-dashboard':
        pageView = <SupermarketDashboardPage data={supermarketBundle} navigate={navigate} />;
        break;
      case 'supermarket-products':
        pageView = <SupermarketProductsPage data={supermarketBundle} navigate={navigate} />;
        break;
      case 'supermarket-add':
        pageView = <SupermarketProductFormPage data={supermarketBundle} navigate={navigate} />;
        break;
      case 'supermarket-edit': {
        const target = sProducts.find((p) => p.id === route.id) ?? null;
        pageView = (
          <SupermarketProductFormPage
            editingProduct={target}
            data={supermarketBundle}
            navigate={navigate}
          />
        );
        break;
      }
      case 'supermarket-details':
        pageView = (
          <SupermarketProductDetailsPage
            productId={route.id}
            data={supermarketBundle}
            navigate={navigate}
          />
        );
        break;
      case 'supermarket-batches':
        pageView = <SupermarketBatchManagementPage data={supermarketBundle} navigate={navigate} />;
        break;
      case 'supermarket-reminders':
        pageView = <SupermarketRemindersPage data={supermarketBundle} navigate={navigate} />;
        break;

      case 'settings':
        pageView = (
          <SettingsPage
            navigate={navigate}
            onDemoChanged={reloadAll}
            householdProducts={hProducts}
            supermarketProducts={sProducts}
          />
        );
        break;
      case 'notifications':
        pageView = (
          <NotificationPreferencesPage
            notifications={notifications}
            onRefreshNotifications={loadNotifications}
            onSendTestNotification={handleSendTestNotification}
            navigate={navigate}
          />
        );
        break;
    }
  }

  return (
    <>
      <AtmosphericFoodBackdrop />
      <AppShell route={route} navigate={navigate} unreadNotificationsCount={unreadCount}>
        {pageView}
      </AppShell>
    </>
  );
};

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error?.message || 'Unexpected rendering error.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="ea-glass max-w-md w-full rounded-3xl p-6 space-y-3 text-center">
            <h1 className="font-display text-lg font-bold">Something went wrong</h1>
            <p className="text-xs text-[var(--text-secondary)]">{this.state.message}</p>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, message: '' });
                window.location.hash = '#/';
              }}
              className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-semibold cursor-pointer"
            >
              Return Home
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AuthThemeProvider>
        <AppContent />
      </AuthThemeProvider>
    </AppErrorBoundary>
  );
}
