import type { SupermarketProduct } from '../types/index.ts';
import { addDaysIso, getTodayIso } from './expiry.ts';
import { downloadCsvFile } from './csvExport.ts';

export interface ParsedCsvBatchRow {
  rowNumber: number;
  productId: string | null;
  productName: string;
  batchNumber: string;
  initialQuantity: number;
  remainingQuantity: number;
  purchaseDate: string;
  expiryDate: string;
  notes: string;
  errors: string[];
  valid: boolean;
}

export interface CsvBatchParseResult {
  headerError: string | null;
  rows: ParsedCsvBatchRow[];
  validCount: number;
  invalidCount: number;
}

export function parseCsvMatrix(text: string): string[][] {
  const clean = text.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentCell = '';
  let inQuotes = false;

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (inQuotes) {
      if (ch === '"') {
        if (clean[i + 1] === '"') {
          currentCell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        currentCell += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        currentRow.push(currentCell);
        currentCell = '';
      } else if (ch === '\r') {
        if (clean[i + 1] === '\n') {
          i++;
        }
        currentRow.push(currentCell);
        rows.push(currentRow);
        currentRow = [];
        currentCell = '';
      } else if (ch === '\n') {
        currentRow.push(currentCell);
        rows.push(currentRow);
        currentRow = [];
        currentCell = '';
      } else {
        currentCell += ch;
      }
    }
  }

  if (currentCell.length > 0 || currentRow.length > 0) {
    currentRow.push(currentCell);
    rows.push(currentRow);
  }

  return rows.filter((r) => r.some((cell) => cell.trim() !== ''));
}

function normalizeHeader(h: string): string {
  return h.trim().toLowerCase().replace(/[\s_-]+/g, '');
}

function isValidCalendarDate(iso: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

export function parseAndValidateBatchCsv(
  csvText: string,
  existingProducts: SupermarketProduct[]
): CsvBatchParseResult {
  const matrix = parseCsvMatrix(csvText);
  if (matrix.length === 0) {
    return {
      headerError: 'The selected CSV file is empty.',
      rows: [],
      validCount: 0,
      invalidCount: 0,
    };
  }

  const rawHeaders = matrix[0];
  const headerMap = new Map<string, number>();
  rawHeaders.forEach((h, idx) => {
    const norm = normalizeHeader(h);
    if (norm && !headerMap.has(norm)) {
      headerMap.set(norm, idx);
    }
  });

  const findCol = (aliases: string[]): number | undefined => {
    for (const a of aliases) {
      const idx = headerMap.get(a);
      if (idx !== undefined) return idx;
    }
    return undefined;
  };

  const productIdCol = findCol(['productid']);
  const productNameCol = findCol(['productname', 'product']);
  const batchNumberCol = findCol(['batchnumber', 'batchno', 'batch']);
  const initialQtyCol = findCol(['initialquantity', 'quantity', 'qty', 'initialqty']);
  const remainingQtyCol = findCol(['remainingquantity', 'remainingqty']);
  const purchaseDateCol = findCol(['purchasedate', 'stockdate']);
  const expiryDateCol = findCol(['expirydate', 'expirationdate']);
  const notesCol = findCol(['notes', 'batchnotes', 'note']);

  const missingCols: string[] = [];
  if (productIdCol === undefined && productNameCol === undefined) {
    missingCols.push('Product Name (or Product ID)');
  }
  if (batchNumberCol === undefined) missingCols.push('Batch Number');
  if (initialQtyCol === undefined) missingCols.push('Initial Quantity (or Quantity)');
  if (purchaseDateCol === undefined) missingCols.push('Purchase Date');
  if (expiryDateCol === undefined) missingCols.push('Expiry Date');

  if (missingCols.length > 0) {
    return {
      headerError: `Missing required CSV column(s): ${missingCols.join(', ')}.`,
      rows: [],
      validCount: 0,
      invalidCount: 0,
    };
  }

  const dataRows = matrix.slice(1);
  if (dataRows.length === 0) {
    return {
      headerError: 'The CSV file contains headers but no batch data rows.',
      rows: [],
      validCount: 0,
      invalidCount: 0,
    };
  }

  if (dataRows.length > 200) {
    return {
      headerError: 'Please split imports into 200 batch rows or fewer per file.',
      rows: [],
      validCount: 0,
      invalidCount: 0,
    };
  }

  const byId = new Map<string, SupermarketProduct>();
  const byName = new Map<string, SupermarketProduct>();
  for (const p of existingProducts) {
    byId.set(p.id, p);
    byName.set(p.name.trim().toLowerCase(), p);
  }

  const parsedRows: ParsedCsvBatchRow[] = dataRows.map((cells, idx) => {
    const rowNumber = idx + 2;
    const getCell = (colIdx: number | undefined): string =>
      colIdx !== undefined && colIdx < cells.length ? cells[colIdx].trim() : '';

    const rawProductId = getCell(productIdCol);
    const rawProductName = getCell(productNameCol);
    const batchNumber = getCell(batchNumberCol);
    const rawInitialQty = getCell(initialQtyCol);
    const rawRemainingQty = getCell(remainingQtyCol);
    const purchaseDate = getCell(purchaseDateCol);
    const expiryDate = getCell(expiryDateCol);
    const notes = getCell(notesCol);

    const errors: string[] = [];

    let matchedProduct: SupermarketProduct | undefined;
    if (rawProductId !== '') {
      matchedProduct = byId.get(rawProductId);
      if (!matchedProduct) {
        errors.push(`Product ID "${rawProductId}" does not match any existing product.`);
      } else if (
        rawProductName !== '' &&
        matchedProduct.name.trim().toLowerCase() !== rawProductName.toLowerCase()
      ) {
        errors.push(
          `Product ID "${rawProductId}" ("${matchedProduct.name}") conflicts with Product Name "${rawProductName}".`
        );
      }
    } else if (rawProductName !== '') {
      matchedProduct = byName.get(rawProductName.toLowerCase());
      if (!matchedProduct) {
        errors.push(`Product "${rawProductName}" does not match any existing product.`);
      }
    } else {
      errors.push('Product Name or Product ID is required.');
    }

    if (!batchNumber) {
      errors.push('Batch Number is required.');
    }

    const initialQuantity = Number(rawInitialQty);
    if (rawInitialQty === '' || !Number.isFinite(initialQuantity) || initialQuantity <= 0) {
      errors.push('Initial Quantity must be a number greater than 0.');
    }

    let remainingQuantity = Number.isFinite(initialQuantity) ? initialQuantity : 0;
    if (rawRemainingQty !== '') {
      const parsedRem = Number(rawRemainingQty);
      if (!Number.isFinite(parsedRem) || parsedRem < 0) {
        errors.push('Remaining Quantity must be 0 or greater.');
      } else if (Number.isFinite(initialQuantity) && parsedRem > initialQuantity) {
        errors.push('Remaining Quantity cannot exceed Initial Quantity.');
      } else {
        remainingQuantity = parsedRem;
      }
    }

    if (!isValidCalendarDate(purchaseDate)) {
      errors.push('Purchase Date must be a valid YYYY-MM-DD date.');
    }
    if (!isValidCalendarDate(expiryDate)) {
      errors.push('Expiry Date must be a valid YYYY-MM-DD date.');
    }

    return {
      rowNumber,
      productId: matchedProduct ? matchedProduct.id : null,
      productName: matchedProduct ? matchedProduct.name : rawProductName || rawProductId || '—',
      batchNumber,
      initialQuantity: Number.isFinite(initialQuantity) ? initialQuantity : 0,
      remainingQuantity,
      purchaseDate,
      expiryDate,
      notes,
      errors,
      valid: errors.length === 0,
    };
  });

  const validCount = parsedRows.filter((r) => r.valid).length;
  return {
    headerError: null,
    rows: parsedRows,
    validCount,
    invalidCount: parsedRows.length - validCount,
  };
}

export function downloadSupermarketBatchTemplateCsv(products: SupermarketProduct[]): void {
  const today = getTodayIso();
  const headers = [
    'Product Name',
    'Batch Number',
    'Initial Quantity',
    'Remaining Quantity',
    'Purchase Date',
    'Expiry Date',
    'Notes',
  ];

  const sampleRows =
    products.length > 0
      ? products.slice(0, 2).map((p, index) => [
          p.name,
          `IMP-${today.replace(/-/g, '').slice(2)}-${index + 1}`,
          24,
          24,
          today,
          addDaysIso(today, 14 + index * 7),
          'Imported batch',
        ])
      : [
          [
            'Existing Product Name',
            'IMP-261120-1',
            24,
            24,
            today,
            addDaysIso(today, 14),
            'Replace with exact existing product name',
          ],
        ];

  downloadCsvFile(`expiryalert-batch-import-template.csv`, headers, sampleRows);
}
