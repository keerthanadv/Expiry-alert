import type {
  ExpiryStatus,
  HouseholdProduct,
  SupermarketBatch,
  SupermarketProduct,
} from '../types/index.ts';
import { computeExpiryStatus, getTodayIso } from './expiry.ts';

function escapeCsvCell(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function downloadCsvFile(filename: string, headers: string[], rows: Array<Array<string | number | boolean | null | undefined>>): void {
  const lines = [
    headers.map(escapeCsvCell).join(','),
    ...rows.map((row) => row.map(escapeCsvCell).join(',')),
  ];
  // UTF-8 BOM ensures Excel and spreadsheet apps render symbols/accents properly
  const csvContent = '\uFEFF' + lines.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportHouseholdInventoryCsv(
  products: HouseholdProduct[],
  defaultReminderDays: number
): void {
  const today = getTodayIso();
  const headers = [
    'ID',
    'Product Name',
    'Category',
    'Quantity',
    'Unit',
    'Purchase Date',
    'Expiry Date',
    'Status',
    'Days Remaining',
    'Reminder Window (Days)',
    'Sample Data',
    'Notes',
  ];

  const sorted = [...products].sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
  const rows = sorted.map((p) => {
    const threshold = p.reminderDays ?? defaultReminderDays;
    const { status, daysRemaining } = computeExpiryStatus(p.expiryDate, threshold, today);
    return [
      p.id,
      p.name,
      p.category,
      p.quantity,
      p.unit,
      p.purchaseDate,
      p.expiryDate,
      status,
      daysRemaining,
      threshold,
      p.isDemo ? 'Yes' : 'No',
      p.notes,
    ];
  });

  downloadCsvFile(`expiryalert-household-inventory-${today}.csv`, headers, rows);
}

export function exportSupermarketInventoryCsv(
  products: SupermarketProduct[],
  defaultReminderDays: number
): void {
  const today = getTodayIso();
  const headers = [
    'Product ID',
    'Product Name',
    'Category',
    'Unit',
    'Low-Stock Threshold',
    'Batch Number',
    'Initial Quantity',
    'Remaining Quantity',
    'Purchase Date',
    'Expiry Date',
    'Status',
    'Days Remaining',
    'Reminder Window (Days)',
    'Sample Data',
    'Product Notes',
    'Batch Notes',
  ];

  const rows: Array<Array<string | number | boolean | null | undefined>> = [];
  const sortedProducts = [...products].sort((a, b) => a.name.localeCompare(b.name));

  for (const p of sortedProducts) {
    const threshold = p.reminderDays ?? defaultReminderDays;
    const sortedBatches = [...p.batches].sort((a, b) =>
      a.expiryDate.localeCompare(b.expiryDate)
    );

    if (sortedBatches.length === 0) {
      rows.push([
        p.id,
        p.name,
        p.categoryName,
        p.unit,
        p.lowStockThreshold,
        '',
        0,
        0,
        '',
        '',
        'No Batches',
        '',
        threshold,
        p.isDemo ? 'Yes' : 'No',
        p.notes,
        '',
      ]);
      continue;
    }

    for (const b of sortedBatches) {
      const { status, daysRemaining } = computeExpiryStatus(b.expiryDate, threshold, today);
      rows.push([
        p.id,
        p.name,
        p.categoryName,
        p.unit,
        p.lowStockThreshold,
        b.batchNumber,
        b.initialQuantity,
        b.remainingQuantity,
        b.purchaseDate,
        b.expiryDate,
        status,
        daysRemaining,
        threshold,
        b.isDemo || p.isDemo ? 'Yes' : 'No',
        p.notes,
        b.notes,
      ]);
    }
  }

  downloadCsvFile(`expiryalert-supermarket-inventory-${today}.csv`, headers, rows);
}

export interface VisibleSupermarketBatchRow extends SupermarketBatch {
  status: ExpiryStatus;
  daysRemaining: number;
}

export function exportSupermarketBatchesCsv(batches: VisibleSupermarketBatchRow[]): void {
  const today = getTodayIso();
  const headers = [
    'Batch ID',
    'Product ID',
    'Product Name',
    'Category',
    'Batch Number',
    'Remaining Quantity',
    'Initial Quantity',
    'Unit',
    'Purchase Date',
    'Expiry Date',
    'Status',
    'Days Remaining',
    'Sample Data',
    'Notes',
  ];

  const rows = batches.map((b) => [
    b.id,
    b.productId,
    b.productName ?? '',
    b.categoryName ?? '',
    b.batchNumber,
    b.remainingQuantity,
    b.initialQuantity,
    b.productUnit ?? '',
    b.purchaseDate,
    b.expiryDate,
    b.status,
    b.daysRemaining,
    b.isDemo ? 'Yes' : 'No',
    b.notes,
  ]);

  downloadCsvFile(`expiryalert-supermarket-batches-${today}.csv`, headers, rows);
}
