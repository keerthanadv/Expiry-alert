export interface AccentPreset {
  id: string;
  label: string;
  hex: string;
}

export const DEFAULT_LIGHT_ACCENT = '#2E6F4E';
export const DEFAULT_DARK_ACCENT = '#D97706';

export const ACCENT_PRESETS: AccentPreset[] = [
  { id: 'forest', label: 'Forest Green', hex: '#2E6F4E' },
  { id: 'amber', label: 'Warm Amber', hex: '#D97706' },
  { id: 'orange', label: 'Harvest Orange', hex: '#EA580C' },
  { id: 'teal', label: 'Sage Teal', hex: '#0F766E' },
  { id: 'rose', label: 'Berry Rose', hex: '#BE123C' },
];

export function normalizeHex(hex: string): string {
  const cleaned = hex.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(cleaned)) {
    return cleaned.toUpperCase();
  }
  return DEFAULT_LIGHT_ACCENT;
}

function hexToRgb(hex: string): [number, number, number] {
  const n = normalizeHex(hex).slice(1);
  return [
    parseInt(n.slice(0, 2), 16),
    parseInt(n.slice(2, 4), 16),
    parseInt(n.slice(4, 6), 16),
  ];
}

function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return (
    '#' +
    [clamp(r), clamp(g), clamp(b)]
      .map((v) => v.toString(16).padStart(2, '0'))
      .join('')
      .toUpperCase()
  );
}

export function getRelativeLuminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map((channel) => {
    const s = channel / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function getContrastRatio(hexA: string, hexB: string): number {
  const lumA = getRelativeLuminance(hexA);
  const lumB = getRelativeLuminance(hexB);
  const lighter = Math.max(lumA, lumB);
  const darker = Math.min(lumA, lumB);
  return (lighter + 0.05) / (darker + 0.05);
}

function mixColors(hexA: string, hexB: string, weightB: number): string {
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  return rgbToHex(
    r1 * (1 - weightB) + r2 * weightB,
    g1 * (1 - weightB) + g2 * weightB,
    b1 * (1 - weightB) + b2 * weightB
  );
}

export interface ComputedAccentPalette {
  accent: string;
  accentFg: string;
  accentText: string;
  accentSoft: string;
  accentRing: string;
  buttonContrast: number;
  textContrast: number;
  adjustedForReadability: boolean;
}

export function computeAccessibleAccent(
  rawHex: string,
  theme: 'light' | 'dark'
): ComputedAccentPalette {
  const accent = normalizeHex(rawHex);
  const surfaceBg = theme === 'light' ? '#FFFDF7' : '#241A15';

  // Choose black or dark espresso vs white foreground for solid accent buttons
  const whiteContrast = getContrastRatio(accent, '#FFFFFF');
  const darkContrast = getContrastRatio(accent, '#17110E');
  const accentFg = whiteContrast >= darkContrast ? '#FFFFFF' : '#17110E';
  const buttonContrast = Math.max(whiteContrast, darkContrast);

  // Ensure accent text used on glass surface meets >= 4.5:1 WCAG AA contrast
  let accentText = accent;
  let adjustedForReadability = false;
  if (getContrastRatio(accentText, surfaceBg) < 4.5) {
    adjustedForReadability = true;
    const target = theme === 'light' ? '#101D16' : '#FFFDF7';
    for (let step = 1; step <= 12; step++) {
      const candidate = mixColors(accent, target, step / 12);
      if (getContrastRatio(candidate, surfaceBg) >= 4.6) {
        accentText = candidate;
        break;
      }
      accentText = candidate;
    }
  }

  const [r, g, b] = hexToRgb(accent);
  const alphaSoft = theme === 'light' ? 0.12 : 0.2;
  const alphaRing = theme === 'light' ? 0.3 : 0.38;

  return {
    accent,
    accentFg,
    accentText,
    accentSoft: `rgba(${r}, ${g}, ${b}, ${alphaSoft})`,
    accentRing: `rgba(${r}, ${g}, ${b}, ${alphaRing})`,
    buttonContrast: Number(buttonContrast.toFixed(2)),
    textContrast: Number(getContrastRatio(accentText, surfaceBg).toFixed(2)),
    adjustedForReadability,
  };
}
