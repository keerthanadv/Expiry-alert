import { getToken, onMessage } from 'firebase/messaging';
import { getFirebaseMessagingSafe } from '../firebase/config.ts';
import { saveFcmToken } from '../services/dataService.ts';

export interface LockscreenNotificationPayload {
  title: string;
  body: string;
  url?: string;
  tag?: string;
  requireInteraction?: boolean;
}

export interface BackgroundReminderSnapshot {
  uid: string;
  notificationsEnabled: boolean;
  scheduleTime: string;
  dueHouseholdCount: number;
  dueSupermarketCount: number;
  householdSummary: string;
  supermarketSummary: string;
  updatedAt: string;
}

interface ExtendedNotificationOptions extends NotificationOptions {
  renotify?: boolean;
  vibrate?: number[];
  timestamp?: number;
  actions?: Array<{
    action: string;
    title: string;
  }>;
}

export type NotificationPermissionState = NotificationPermission | 'unsupported';
export type FcmStatus = 'active' | 'vapid_missing' | 'permission_needed' | 'unsupported' | 'unavailable';

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && typeof Notification !== 'undefined';
}

export function getNotificationPermission(): NotificationPermissionState {
  if (!isNotificationSupported()) return 'unsupported';
  return Notification.permission;
}

export async function requestLockscreenPermission(): Promise<NotificationPermissionState> {
  if (!isNotificationSupported()) return 'unsupported';
  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    await getReadyServiceWorkerRegistration();
  }
  return permission;
}

export async function getReadyServiceWorkerRegistration(
  timeoutMs = 2500
): Promise<ServiceWorkerRegistration | null> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) {
    return null;
  }

  try {
    let existing =
      (await navigator.serviceWorker.getRegistration('/sw.js')) ??
      (await navigator.serviceWorker.getRegistration());

    if (!existing) {
      existing = await navigator.serviceWorker.register('/sw.js').catch(() => undefined);
    }

    const readyPromise = navigator.serviceWorker.ready;
    const timeoutPromise = new Promise<null>((resolve) => {
      window.setTimeout(() => resolve(null), timeoutMs);
    });

    const readyReg = await Promise.race([readyPromise, timeoutPromise]);
    return readyReg ?? existing ?? null;
  } catch {
    return null;
  }
}

export async function registerFcmDeviceToken(
  uid: string,
  onForegroundPayload?: (payload: LockscreenNotificationPayload) => void
): Promise<{ status: FcmStatus; token?: string }> {
  const messaging = await getFirebaseMessagingSafe();
  if (!messaging) {
    return { status: 'unsupported' };
  }

  const perm = getNotificationPermission();
  if (perm !== 'granted') {
    return { status: perm === 'unsupported' ? 'unsupported' : 'permission_needed' };
  }

  const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;
  const swReg = await getReadyServiceWorkerRegistration();

  if (onForegroundPayload) {
    onMessage(messaging, (payload) => {
      const title =
        payload.notification?.title ??
        (typeof payload.data?.title === 'string' ? payload.data.title : 'ExpiryAlert Reminder');
      const body =
        payload.notification?.body ??
        (typeof payload.data?.body === 'string'
          ? payload.data.body
          : 'You have food items approaching expiry.');
      const url =
        typeof payload.data?.url === 'string' ? payload.data.url : '/#/household/reminders';
      onForegroundPayload({ title, body, url, tag: `ea-fcm-${Date.now()}` });
    });
  }

  if (!vapidKey || !vapidKey.trim()) {
    return { status: 'vapid_missing' };
  }

  try {
    const token = await getToken(messaging, {
      vapidKey: vapidKey.trim(),
      serviceWorkerRegistration: swReg ?? undefined,
    });
    if (token) {
      await saveFcmToken(uid, token, navigator.userAgent.slice(0, 60) || 'web-pwa');
      return { status: 'active', token };
    }
    return { status: 'unavailable' };
  } catch {
    return { status: 'unavailable' };
  }
}

export async function syncBackgroundReminderSnapshot(
  snapshot: BackgroundReminderSnapshot
): Promise<void> {
  try {
    const reg = await getReadyServiceWorkerRegistration();
    const targetWorker = reg?.active ?? navigator.serviceWorker?.controller ?? null;
    if (targetWorker) {
      targetWorker.postMessage({
        type: 'SYNC_REMINDER_SNAPSHOT',
        snapshot,
      });
    }
    // Attempt Periodic Background Sync registration when supported (installed Chromium PWAs)
    if (reg && 'periodicSync' in reg) {
      const periodicSync = (reg as ServiceWorkerRegistration & {
        periodicSync?: { register: (tag: string, opts: { minInterval: number }) => Promise<void> };
      }).periodicSync;
      await periodicSync?.register('expiryalert-daily-check', {
        minInterval: 12 * 60 * 60 * 1000,
      }).catch(() => undefined);
    }
  } catch {
    // Non-fatal fallback if periodicSync or SW messaging is unavailable
  }
}

function buildNotificationOptions(
  payload: LockscreenNotificationPayload
): ExtendedNotificationOptions {
  return {
    body: payload.body,
    icon: '/pwa-192x192.png',
    badge: '/pwa-192x192.png',
    tag: payload.tag || 'expiryalert-reminder',
    renotify: true,
    requireInteraction: payload.requireInteraction ?? true,
    vibrate: [200, 100, 200],
    timestamp: Date.now(),
    data: {
      url: payload.url || '/#/household/reminders',
    },
    actions: [
      { action: 'open', title: 'View Reminders' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
  };
}

export async function dispatchLockscreenNotification(
  payload: LockscreenNotificationPayload
): Promise<'browser' | 'in_app'> {
  if (getNotificationPermission() !== 'granted') {
    return 'in_app';
  }

  try {
    const reg = await getReadyServiceWorkerRegistration();
    const options = buildNotificationOptions(payload);

    if (reg) {
      if (typeof reg.showNotification === 'function') {
        await reg.showNotification(payload.title, options as NotificationOptions);
        return 'browser';
      }
      const worker = reg.active ?? navigator.serviceWorker?.controller ?? null;
      if (worker) {
        worker.postMessage({
          type: 'SHOW_EXPIRY_NOTIFICATION',
          payload,
        });
        return 'browser';
      }
    }

    new Notification(payload.title, {
      body: payload.body,
      icon: '/pwa-192x192.png',
      tag: options.tag,
    });
    return 'browser';
  } catch {
    return 'in_app';
  }
}

export async function scheduleLockscreenNotification(
  payload: LockscreenNotificationPayload,
  delayMs = 5000
): Promise<'scheduled_sw' | 'scheduled_page' | 'in_app'> {
  if (getNotificationPermission() !== 'granted') {
    return 'in_app';
  }

  const safeDelay = Math.max(0, Math.min(60000, Math.round(delayMs)));

  try {
    const reg = await getReadyServiceWorkerRegistration();
    const targetWorker = reg?.active ?? navigator.serviceWorker?.controller ?? null;
    if (targetWorker) {
      targetWorker.postMessage({
        type: 'SCHEDULE_EXPIRY_NOTIFICATION',
        delayMs: safeDelay,
        payload,
      });
      return 'scheduled_sw';
    }
  } catch {
    // Fall back to page timer below
  }

  window.setTimeout(() => {
    void dispatchLockscreenNotification(payload);
  }, safeDelay);
  return 'scheduled_page';
}
