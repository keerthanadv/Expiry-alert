import type { ExpiryStatus } from '../types/index.ts';

export function getTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDaysIso(baseIso: string, days: number): string {
  const [y, m, d] = baseIso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  const ry = dt.getUTCFullYear();
  const rm = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const rd = String(dt.getUTCDate()).padStart(2, '0');
  return `${ry}-${rm}-${rd}`;
}

export function diffInDays(targetIso: string, fromIso: string = getTodayIso()): number {
  const [ty, tm, td] = targetIso.split('-').map(Number);
  const [fy, fm, fd] = fromIso.split('-').map(Number);
  if (!ty || !tm || !td || !fy || !fm || !fd) return 0;
  const targetMs = Date.UTC(ty, tm - 1, td);
  const fromMs = Date.UTC(fy, fm - 1, fd);
  return Math.round((targetMs - fromMs) / 86400000);
}

export function computeExpiryStatus(
  expiryDate: string,
  reminderThresholdDays: number = 5,
  referenceDate: string = getTodayIso()
): { status: ExpiryStatus; daysRemaining: number } {
  const daysRemaining = diffInDays(expiryDate, referenceDate);
  if (daysRemaining < 0) {
    return { status: 'Expired', daysRemaining };
  }
  if (daysRemaining <= reminderThresholdDays) {
    return { status: 'Near Expiry', daysRemaining };
  }
  const goodCeiling = Math.max(reminderThresholdDays * 2, 14);
  if (daysRemaining <= goodCeiling) {
    return { status: 'Good', daysRemaining };
  }
  return { status: 'Fresh', daysRemaining };
}

export function formatDaysRemaining(daysRemaining: number): string {
  if (daysRemaining < -1) return `Expired ${Math.abs(daysRemaining)} days ago`;
  if (daysRemaining === -1) return 'Expired yesterday';
  if (daysRemaining === 0) return 'Expires today';
  if (daysRemaining === 1) return 'Expires tomorrow';
  return `${daysRemaining} days left`;
}

export function formatShortDate(isoDate: string): string {
  if (!isoDate) return '—';
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}
