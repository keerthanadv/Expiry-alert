import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="ea-btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="h-4 w-4" />
        <span>{compact ? 'Install' : 'Install ExpiryAlert App'}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium whitespace-nowrap shrink-0 hover:opacity-90 cursor-pointer"
        >
          <Smartphone className="h-4 w-4" />
          <span>Install on iPhone / iPad</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
            <div className="ea-glass w-full max-w-sm rounded-2xl p-6">
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-lg font-semibold">Install on iOS Safari</h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  aria-label="Close installation guide"
                  className="rounded-lg p-1.5 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <ol className="mt-3 space-y-2 text-sm text-[var(--text-secondary)]">
                <li>1. Tap the <strong>Share</strong> icon in Safari's toolbar.</li>
                <li>2. Scroll down and select <strong>Add to Home Screen</strong>.</li>
                <li>3. Open ExpiryAlert from your Home Screen and allow notifications.</li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="ea-btn-accent mt-5 w-full rounded-xl py-2.5 text-sm font-medium cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <p className="text-xs text-[var(--text-secondary)]">
      Use your browser's address bar menu ("Install app" or "Add to Home Screen") to install ExpiryAlert as a PWA on supported devices.
    </p>
  );
};
