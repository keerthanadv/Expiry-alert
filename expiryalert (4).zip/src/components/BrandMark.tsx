import React from 'react';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';

export const BrandLogoIcon: React.FC<{ className?: string }> = ({ className = 'h-8 w-8' }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="40" height="40" rx="11" fill="var(--accent)" />
    <circle cx="20" cy="21" r="10.5" stroke="var(--accent-fg)" strokeWidth="2.4" />
    <path
      d="M20 15.5V21.2L23.8 23.4"
      stroke="var(--accent-fg)"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M25.5 7.5C28.8 7.5 31.2 9.4 32 12.2C28.8 12.7 26.5 11.2 25.5 7.5Z"
      fill="#F59E0B"
    />
  </svg>
);

export const AtmosphericFoodBackdrop: React.FC = () => {
  const { theme } = useAuthTheme();
  const imgSrc =
    theme === 'dark'
      ? '/src/assets/images/bg_food_dark_1795166952011.jpg'
      : '/src/assets/images/bg_food_light_1795166952202.jpg';

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
      <img
        src={imgSrc}
        alt=""
        referrerPolicy="no-referrer"
        className="h-full w-full scale-105 object-cover blur-[6px] transition-opacity duration-300"
        style={{ opacity: theme === 'dark' ? 0.28 : 0.24 }}
      />
      <div
        className="absolute inset-0 transition-colors duration-300"
        style={{
          background:
            theme === 'dark'
              ? 'linear-gradient(155deg, rgba(22,16,13,0.88) 0%, rgba(30,21,17,0.82) 55%, rgba(20,14,11,0.92) 100%)'
              : 'linear-gradient(155deg, rgba(246,243,234,0.86) 0%, rgba(239,243,234,0.78) 55%, rgba(245,241,230,0.90) 100%)',
        }}
      />
    </div>
  );
};
