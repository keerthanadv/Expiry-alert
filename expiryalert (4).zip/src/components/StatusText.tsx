import React from 'react';
import { AlertTriangle, CheckCircle2, Clock, XCircle } from 'lucide-react';
import type { ExpiryStatus } from '../types/index.ts';

export const StatusText: React.FC<{ status: ExpiryStatus; className?: string }> = ({
  status,
  className = '',
}) => {
  if (status === 'Expired') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 text-xs font-semibold text-red-700 dark:text-red-400 whitespace-nowrap ${className}`}
      >
        <XCircle className="h-3.5 w-3.5 shrink-0" />
        <span>Expired</span>
      </span>
    );
  }
  if (status === 'Near Expiry') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400 whitespace-nowrap ${className}`}
      >
        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
        <span>Near Expiry</span>
      </span>
    );
  }
  if (status === 'Good') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 whitespace-nowrap ${className}`}
      >
        <Clock className="h-3.5 w-3.5 shrink-0" />
        <span>Good</span>
      </span>
    );
  }
  return (
    <span
      className={`inline-flex items-center gap-1.5 text-xs font-semibold text-green-800 dark:text-lime-400 whitespace-nowrap ${className}`}
    >
      <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
      <span>Fresh</span>
    </span>
  );
};
