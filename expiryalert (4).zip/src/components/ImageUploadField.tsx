import React, { useRef, useState } from 'react';
import { Camera, ImagePlus, Replace, Trash2, Utensils } from 'lucide-react';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import { uploadProductImage } from '../services/dataService.ts';

interface ImageUploadFieldProps {
  label?: string;
  imageUrl: string | null;
  onChange: (url: string | null) => void;
}

export const ImageUploadField: React.FC<ImageUploadFieldProps> = ({
  label = 'Product Image (Optional)',
  imageUrl,
  onChange,
}) => {
  const { user } = useAuthTheme();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!user) {
      setError('Please sign in first to upload images.');
      return;
    }
    setError(null);
    setUploading(true);
    try {
      const url = await uploadProductImage(user.uid, file);
      onChange(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium mb-2">{label}</label>
      <div className="ea-surface rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center gap-4">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt="Uploaded preview"
            referrerPolicy="no-referrer"
            className="h-24 w-24 shrink-0 rounded-xl object-cover border border-[var(--border-subtle)]"
          />
        ) : (
          <div
            className="h-24 w-24 shrink-0 rounded-xl flex flex-col items-center justify-center border border-dashed border-[var(--border-strong)]"
            style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent-text)' }}
          >
            <Utensils className="h-7 w-7" />
            <span className="text-[11px] mt-1 font-medium">Default icon</span>
          </div>
        )}

        <div className="flex-1 space-y-2">
          <p className="text-xs text-[var(--text-secondary)]">
            Optional photo stored permanently in Firebase Storage. Supports JPG, PNG, or WebP up to 2 MB.
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={uploading}
              onClick={() => fileInputRef.current?.click()}
              className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium hover:opacity-90 cursor-pointer disabled:opacity-50"
            >
              {imageUrl ? <Replace className="h-3.5 w-3.5" /> : <ImagePlus className="h-3.5 w-3.5" />}
              <span>{uploading ? 'Uploading...' : imageUrl ? 'Replace Photo' : 'Choose File'}</span>
            </button>

            <button
              type="button"
              disabled={uploading}
              onClick={() => cameraInputRef.current?.click()}
              className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium hover:opacity-90 cursor-pointer disabled:opacity-50"
            >
              <Camera className="h-3.5 w-3.5" />
              <span>Use Camera</span>
            </button>

            {imageUrl && (
              <button
                type="button"
                disabled={uploading}
                onClick={() => {
                  setError(null);
                  onChange(null);
                }}
                className="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium text-red-700 dark:text-red-400 hover:bg-red-500/10 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Remove</span>
              </button>
            )}
          </div>
          {error && <p className="text-xs font-medium text-red-600 dark:text-red-400">{error}</p>}
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={handleFile}
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        capture="environment"
        className="hidden"
        onChange={handleFile}
      />
    </div>
  );
};
