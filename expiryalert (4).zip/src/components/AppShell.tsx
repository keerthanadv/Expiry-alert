import React, { useEffect, useState } from 'react';
import {
  Bell,
  Boxes,
  Home,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Package,
  PlusCircle,
  Settings,
  Store,
  Sun,
  WifiOff,
  X,
} from 'lucide-react';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import { useOnlineStatus } from '../hooks/usePWAInstall.ts';
import type { OperatingMode } from '../types/index.ts';
import { BrandLogoIcon } from './BrandMark.tsx';

export type AppRoute =
  | { name: 'landing' }
  | { name: 'login'; initialMode?: OperatingMode }
  | { name: 'register'; initialMode?: OperatingMode }
  | { name: 'forgot-password' }
  | { name: 'household-dashboard' }
  | { name: 'household-products' }
  | { name: 'household-add' }
  | { name: 'household-edit'; id: string }
  | { name: 'household-details'; id: string }
  | { name: 'household-reminders' }
  | { name: 'supermarket-dashboard' }
  | { name: 'supermarket-products' }
  | { name: 'supermarket-add' }
  | { name: 'supermarket-edit'; id: string }
  | { name: 'supermarket-details'; id: string }
  | { name: 'supermarket-batches' }
  | { name: 'supermarket-reminders' }
  | { name: 'settings' }
  | { name: 'notifications' };

interface AppShellProps {
  route: AppRoute;
  navigate: (route: AppRoute) => void;
  unreadNotificationsCount: number;
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({
  route,
  navigate,
  unreadNotificationsCount,
  children,
}) => {
  const { user, theme, activeMode, setActiveMode, updateAppearance, logout } = useAuthTheme();
  const isOnline = useOnlineStatus();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (!mobileMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileMenuOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mobileMenuOpen]);

  const isSupermarketRoute =
    route.name.startsWith('supermarket-') ||
    (route.name === 'settings' || route.name === 'notifications'
      ? activeMode === 'supermarket'
      : false);
  const currentMode: OperatingMode = isSupermarketRoute ? 'supermarket' : 'household';
  const canSwitchMode = user?.accountType === 'both';

  const navItems: {
    key: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    target: AppRoute;
    active: boolean;
  }[] =
    currentMode === 'household'
      ? [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: LayoutDashboard,
            target: { name: 'household-dashboard' },
            active: route.name === 'household-dashboard',
          },
          {
            key: 'products',
            label: 'My Products',
            icon: Package,
            target: { name: 'household-products' },
            active:
              route.name === 'household-products' ||
              route.name === 'household-details' ||
              route.name === 'household-edit',
          },
          {
            key: 'add',
            label: 'Add Product',
            icon: PlusCircle,
            target: { name: 'household-add' },
            active: route.name === 'household-add',
          },
          {
            key: 'reminders',
            label: 'Reminders',
            icon: Bell,
            target: { name: 'household-reminders' },
            active: route.name === 'household-reminders',
          },
          {
            key: 'settings',
            label: 'Settings',
            icon: Settings,
            target: { name: 'settings' },
            active: route.name === 'settings' || route.name === 'notifications',
          },
        ]
      : [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: LayoutDashboard,
            target: { name: 'supermarket-dashboard' },
            active: route.name === 'supermarket-dashboard',
          },
          {
            key: 'products',
            label: 'My Products',
            icon: Package,
            target: { name: 'supermarket-products' },
            active:
              route.name === 'supermarket-products' ||
              route.name === 'supermarket-details' ||
              route.name === 'supermarket-edit',
          },
          {
            key: 'add',
            label: 'Add Product',
            icon: PlusCircle,
            target: { name: 'supermarket-add' },
            active: route.name === 'supermarket-add',
          },
          {
            key: 'batches',
            label: 'Batch Management',
            icon: Boxes,
            target: { name: 'supermarket-batches' },
            active: route.name === 'supermarket-batches',
          },
          {
            key: 'reminders',
            label: 'Reminders',
            icon: Bell,
            target: { name: 'supermarket-reminders' },
            active: route.name === 'supermarket-reminders',
          },
          {
            key: 'settings',
            label: 'Settings',
            icon: Settings,
            target: { name: 'settings' },
            active: route.name === 'settings' || route.name === 'notifications',
          },
        ];

  const handleModeSwitch = (mode: OperatingMode) => {
    setActiveMode(mode);
    setMobileMenuOpen(false);
    navigate({ name: mode === 'supermarket' ? 'supermarket-dashboard' : 'household-dashboard' });
  };

  const handleNavClick = (target: AppRoute) => {
    setMobileMenuOpen(false);
    navigate(target);
  };

  const handleLogout = async () => {
    setMobileMenuOpen(false);
    await logout();
    navigate({ name: 'landing' });
  };

  const SidebarContent = () => (
    <div className="flex h-full flex-col justify-between p-4">
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => handleNavClick({ name: 'landing' })}
          className="flex items-center gap-2.5 px-2 py-1 text-left cursor-pointer"
        >
          <BrandLogoIcon className="h-8 w-8 shrink-0" />
          <span className="font-display text-lg font-bold tracking-tight">ExpiryAlert</span>
        </button>

        {canSwitchMode ? (
          <div className="ea-surface rounded-xl p-1 grid grid-cols-2 gap-1">
            <button
              type="button"
              onClick={() => handleModeSwitch('household')}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                currentMode === 'household'
                  ? 'ea-btn-accent shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <Home className="h-3.5 w-3.5 shrink-0" />
              <span>Household</span>
            </button>
            <button
              type="button"
              onClick={() => handleModeSwitch('supermarket')}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                currentMode === 'supermarket'
                  ? 'ea-btn-accent shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <Store className="h-3.5 w-3.5 shrink-0" />
              <span>Supermarket</span>
            </button>
          </div>
        ) : (
          <div className="px-2 text-xs font-medium text-[var(--text-secondary)] flex items-center gap-2">
            {currentMode === 'supermarket' ? (
              <Store className="h-3.5 w-3.5" />
            ) : (
              <Home className="h-3.5 w-3.5" />
            )}
            <span>{currentMode === 'supermarket' ? 'Supermarket Mode' : 'Household Mode'}</span>
          </div>
        )}

        <nav className="space-y-1" aria-label="Workspace navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleNavClick(item.target)}
                className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  item.active
                    ? 'ea-btn-accent'
                    : 'text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[var(--text-primary)]'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="space-y-2 border-t border-[var(--border-subtle)] pt-4">
        <button
          type="button"
          onClick={() => handleNavClick({ name: 'notifications' })}
          className={`w-full flex items-center justify-between rounded-xl px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
            route.name === 'notifications'
              ? 'ea-btn-accent'
              : 'text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[var(--text-primary)]'
          }`}
        >
          <span className="flex items-center gap-2.5">
            <Bell className="h-4 w-4 shrink-0" />
            <span>Notifications</span>
          </span>
          {unreadNotificationsCount > 0 && (
            <span className="font-mono text-xs font-semibold tabular-nums">
              {unreadNotificationsCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => updateAppearance({ theme: theme === 'light' ? 'dark' : 'light' })}
          className="w-full flex items-center justify-between rounded-xl px-3 py-2 text-sm font-medium text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/5 hover:text-[var(--text-primary)] cursor-pointer"
        >
          <span className="flex items-center gap-2.5">
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            <span>{theme === 'light' ? 'Coffee Dark' : 'Cream Light'}</span>
          </span>
        </button>

        <div className="flex items-center gap-2.5 px-3 py-2">
          {user?.profileImageUrl ? (
            <img
              src={user.profileImageUrl}
              alt={user.fullName}
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-full object-cover border border-[var(--border-subtle)]"
            />
          ) : (
            <div
              className="h-8 w-8 rounded-full flex items-center justify-center text-xs font-semibold shrink-0"
              style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent-text)' }}
            >
              {(user?.fullName || 'U').slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold truncate">{user?.fullName}</p>
            <p className="text-[11px] text-[var(--text-muted)] truncate">{user?.email}</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-medium text-red-700 dark:text-red-400 hover:bg-red-500/10 cursor-pointer"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          <span>{user?.isDemoSession ? 'Exit Demo' : 'Logout'}</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-[var(--border-subtle)] ea-glass sticky top-0 h-screen overflow-y-auto">
        <SidebarContent />
      </aside>

      {/* Mobile Compact Header */}
      <header className="lg:hidden sticky top-0 z-30 ea-glass border-b border-[var(--border-subtle)] px-4 py-3 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => handleNavClick({ name: 'landing' })}
          className="flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <BrandLogoIcon className="h-7 w-7 shrink-0" />
          <span className="font-display text-base font-bold">ExpiryAlert</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => updateAppearance({ theme: theme === 'light' ? 'dark' : 'light' })}
            aria-label="Toggle theme"
            className="rounded-xl p-2.5 ea-surface cursor-pointer"
          >
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>
          <button
            type="button"
            onClick={() => handleNavClick({ name: 'notifications' })}
            aria-label="Notification preferences"
            className="relative rounded-xl p-2.5 ea-surface cursor-pointer flex items-center gap-1.5"
          >
            <Bell className="h-4 w-4" />
            {unreadNotificationsCount > 0 && (
              <span
                className="font-mono text-[11px] font-bold tabular-nums"
                style={{ color: 'var(--accent-text)' }}
              >
                {unreadNotificationsCount}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
            className="rounded-xl p-2.5 ea-surface cursor-pointer"
          >
            <Menu className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 w-72 max-w-[85vw] h-full ea-glass border-r border-[var(--border-subtle)] overflow-y-auto">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              aria-label="Close navigation menu"
              className="absolute top-3 right-3 rounded-lg p-2 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {user?.isDemoSession && (
          <div className="ea-surface border-b border-[var(--border-subtle)] px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-2">
            <span className="text-[var(--text-secondary)]">
              Demonstration Sandbox (local preview session). Create a free verified account to persist records to the cloud.
            </span>
            <button
              type="button"
              onClick={async () => {
                await logout();
                navigate({ name: 'register', initialMode: currentMode });
              }}
              className="font-semibold hover:underline cursor-pointer"
              style={{ color: 'var(--accent-text)' }}
            >
              Create Cloud Account →
            </button>
          </div>
        )}
        {!isOnline && (
          <div className="bg-amber-600 text-white px-4 py-2 text-xs font-medium flex items-center justify-center gap-2">
            <WifiOff className="h-3.5 w-3.5" />
            <span>You are currently offline. Cached screens remain viewable until connection returns.</span>
          </div>
        )}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-6xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
