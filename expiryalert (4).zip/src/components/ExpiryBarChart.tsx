import React from 'react';

export interface BarDatum {
  label: string;
  value: number;
  color: string;
  sublabel?: string;
}

export const ExpiryBarChart: React.FC<{
  title: string;
  subtitle?: string;
  data: BarDatum[];
  unitLabel?: string;
}> = ({ title, subtitle, data, unitLabel = '' }) => {
  const maxVal = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="ea-glass rounded-2xl p-6 h-full flex flex-col justify-between">
      <div className="mb-5">
        <h3 className="text-base font-semibold">{title}</h3>
        {subtitle && <p className="text-xs text-[var(--text-secondary)] mt-0.5">{subtitle}</p>}
      </div>

      <div className="grid grid-cols-4 gap-3 sm:gap-5 items-end h-44 pt-4">
        {data.map((item) => {
          const pct = item.value === 0 ? 4 : Math.max(10, Math.round((item.value / maxVal) * 100));
          return (
            <div key={item.label} className="flex flex-col items-center h-full justify-end gap-2">
              <span className="font-mono text-sm font-semibold tabular-nums">
                {item.value}
                {unitLabel ? ` ${unitLabel}` : ''}
              </span>
              <div className="w-full max-w-[54px] flex-1 flex items-end justify-center bg-[var(--surface-subtle)] rounded-xl p-1.5 border border-[var(--border-subtle)]">
                <div
                  className="w-full rounded-lg transition-all duration-300"
                  style={{
                    height: `${pct}%`,
                    backgroundColor: item.color,
                    opacity: item.value === 0 ? 0.22 : 0.94,
                  }}
                  title={`${item.label}: ${item.value}${unitLabel ? ' ' + unitLabel : ''}`}
                />
              </div>
              <div className="text-center">
                <p className="text-xs font-medium leading-tight whitespace-nowrap">{item.label}</p>
                {item.sublabel && (
                  <p className="text-[11px] text-[var(--text-muted)]">{item.sublabel}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const HorizontalStockChart: React.FC<{
  title: string;
  subtitle?: string;
  data: BarDatum[];
  unitLabel?: string;
}> = ({ title, subtitle, data, unitLabel = '' }) => {
  const maxVal = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="ea-glass rounded-2xl p-6">
      <div className="mb-5">
        <h3 className="text-base font-semibold">{title}</h3>
        {subtitle && <p className="text-xs text-[var(--text-secondary)] mt-0.5">{subtitle}</p>}
      </div>

      {data.length === 0 ? (
        <p className="text-sm text-[var(--text-secondary)] py-8 text-center">
          No stock records yet.
        </p>
      ) : (
        <div className="space-y-4">
          {data.map((item) => {
            const pct = Math.max(item.value > 0 ? 6 : 0, Math.round((item.value / maxVal) * 100));
            return (
              <div key={item.label} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs gap-2">
                  <span className="font-medium truncate">{item.label}</span>
                  <span className="font-mono font-semibold tabular-nums shrink-0">
                    {item.value}
                    {unitLabel ? ` ${unitLabel}` : ''}
                  </span>
                </div>
                <div className="h-2.5 w-full rounded-full bg-[var(--surface-subtle)] overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${pct}%`,
                      backgroundColor: item.color,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
