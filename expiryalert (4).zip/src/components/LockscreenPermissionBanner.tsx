import React, { useState } from 'react';
import { BellRing } from 'lucide-react';
import type { AppRoute } from './AppShell.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import {
  getNotificationPermission,
  requestLockscreenPermission,
  type NotificationPermissionState,
} from '../utils/notifications.ts';

export const LockscreenPermissionBanner: React.FC<{
  navigate: (route: AppRoute) => void;
}> = ({ navigate }) => {
  const { user } = useAuthTheme();
  const [permission, setPermission] = useState<NotificationPermissionState>(() =>
    getNotificationPermission()
  );
  const [justEnabled, setJustEnabled] = useState(false);

  if (!user?.notificationsEnabled) return null;
  if (permission === 'unsupported' || permission === 'denied') return null;
  if (permission === 'granted' && !justEnabled) return null;

  const handleEnable = async () => {
    try {
      const next = await requestLockscreenPermission();
      setPermission(next);
      if (next === 'granted') {
        setJustEnabled(true);
      }
    } catch {
      // Ignore blocked prompt errors cleanly
    }
  };

  return (
    <div className="ea-glass rounded-2xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div className="flex items-center gap-2.5 text-xs">
        <BellRing className="h-4 w-4 shrink-0" style={{ color: 'var(--accent-text)' }} />
        <span className="text-[var(--text-secondary)]">
          {justEnabled
            ? 'Lock-screen expiry notifications are now enabled on this device.'
            : 'Turn on device notifications so expiry alerts appear on your lock screen.'}
        </span>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {justEnabled ? (
          <button
            type="button"
            onClick={() => navigate({ name: 'notifications' })}
            className="ea-surface rounded-xl px-3 py-1.5 text-xs font-semibold cursor-pointer"
          >
            Test on Lock Screen
          </button>
        ) : (
          <>
            <button
              type="button"
              onClick={handleEnable}
              className="ea-btn-accent rounded-xl px-3.5 py-1.5 text-xs font-semibold cursor-pointer"
            >
              Enable Lock-Screen Alerts
            </button>
            <button
              type="button"
              onClick={() => navigate({ name: 'notifications' })}
              className="ea-surface rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
            >
              Preferences
            </button>
          </>
        )}
      </div>
    </div>
  );
};
