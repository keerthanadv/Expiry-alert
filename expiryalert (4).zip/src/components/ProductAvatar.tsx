import React, { useEffect, useState } from 'react';
import {
  Apple,
  Coffee,
  Cookie,
  Croissant,
  Milk,
  Package,
  Snowflake,
  Utensils,
} from 'lucide-react';

function pickCategoryIcon(category?: string) {
  const c = (category || '').toLowerCase();
  if (c.includes('dairy') || c.includes('milk') || c.includes('yogurt')) return Milk;
  if (c.includes('bakery') || c.includes('bread')) return Croissant;
  if (c.includes('beverage') || c.includes('drink') || c.includes('juice') || c.includes('coffee'))
    return Coffee;
  if (c.includes('snack') || c.includes('confectionery') || c.includes('biscuit')) return Cookie;
  if (c.includes('frozen')) return Snowflake;
  if (c.includes('produce') || c.includes('fruit')) return Apple;
  if (c.includes('ready') || c.includes('instant') || c.includes('condiment')) return Utensils;
  return Package;
}

export const ProductAvatar: React.FC<{
  imageUrl?: string | null;
  name: string;
  category?: string;
  sizeClass?: string;
}> = ({ imageUrl, name, category, sizeClass = 'h-11 w-11' }) => {
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setFailed(false);
  }, [imageUrl]);
  const Icon = pickCategoryIcon(category);

  if (imageUrl && !failed) {
    return (
      <img
        src={imageUrl}
        alt={name}
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        className={`${sizeClass} shrink-0 rounded-xl object-cover border border-[var(--border-subtle)]`}
      />
    );
  }

  return (
    <div
      className={`${sizeClass} shrink-0 rounded-xl flex items-center justify-center border border-[var(--border-subtle)]`}
      style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent-text)' }}
      aria-hidden="true"
    >
      <Icon className="h-5 w-5" />
    </div>
  );
};
