import React, { useEffect, useMemo, useState } from 'react';
import {
  AlarmClock,
  ArrowLeft,
  BellOff,
  Check,
  CheckCircle2,
  Download,
  Edit3,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from 'lucide-react';
import {
  createHouseholdProduct,
  deleteHouseholdProduct,
  logHouseholdAction,
  setReminderState,
  updateHouseholdProduct,
  updateUserProfile,
} from '../services/dataService.ts';
import type { AppRoute } from '../components/AppShell.tsx';
import { ExpiryBarChart } from '../components/ExpiryBarChart.tsx';
import { ImageUploadField } from '../components/ImageUploadField.tsx';
import { LockscreenPermissionBanner } from '../components/LockscreenPermissionBanner.tsx';
import { ProductAvatar } from '../components/ProductAvatar.tsx';
import { StatusText } from '../components/StatusText.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import type {
  ExpiryStatus,
  HouseholdProduct,
  ProductActionLog,
  ReminderStateRecord,
} from '../types/index.ts';
import {
  addDaysIso,
  computeExpiryStatus,
  formatDaysRemaining,
  formatShortDate,
  getTodayIso,
} from '../utils/expiry.ts';
import { exportHouseholdInventoryCsv } from '../utils/csvExport.ts';

export interface HouseholdDataBundle {
  products: HouseholdProduct[];
  actions: ProductActionLog[];
  reminderStates: ReminderStateRecord[];
  loading: boolean;
  reload: () => Promise<void>;
}

const HOUSEHOLD_CATEGORIES = [
  'Dairy',
  'Bakery',
  'Beverages',
  'Snacks',
  'Breakfast & Grains',
  'Fresh Produce',
  'Frozen',
  'Condiments & Sauces',
  'Canned Goods',
  'Pantry',
];

const REMINDER_DAY_OPTIONS = [15, 7, 5, 3, 1, 0];

export const HouseholdDashboardPage: React.FC<{
  data: HouseholdDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user, accentPalette } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;

  const activeProducts = useMemo(
    () => data.products.filter((p) => p.quantity > 0),
    [data.products]
  );

  const enriched = useMemo(() => {
    return activeProducts.map((p) => {
      const threshold = p.reminderDays ?? defaultDays;
      const calc = computeExpiryStatus(p.expiryDate, threshold);
      return { ...p, ...calc };
    });
  }, [activeProducts, defaultDays]);

  const counts = useMemo(() => {
    let fresh = 0;
    let good = 0;
    let near = 0;
    let expired = 0;
    for (const item of enriched) {
      if (item.status === 'Fresh') fresh++;
      else if (item.status === 'Good') good++;
      else if (item.status === 'Near Expiry') near++;
      else expired++;
    }
    return {
      total: enriched.length,
      fresh,
      good,
      freshAndGood: fresh + good,
      near,
      expired,
    };
  }, [enriched]);

  const upcomingList = useMemo(
    () =>
      [...enriched]
        .filter((i) => i.daysRemaining >= 0)
        .sort((a, b) => a.daysRemaining - b.daysRemaining)
        .slice(0, 6),
    [enriched]
  );

  if (data.loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-56 rounded-xl bg-[var(--surface-subtle)]" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 rounded-2xl ea-glass" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Household Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Pantry Dashboard
          </h1>
        </div>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-add' })}
          className="ea-btn-accent inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Add Product</span>
        </button>
      </div>

      {/* 4 KPI Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => navigate({ name: 'household-products' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-[var(--text-secondary)]">Total Products</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2">{counts.total}</p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Active items in pantry</p>
        </button>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-reminders' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-amber-700 dark:text-amber-400">Expiring Soon</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-amber-700 dark:text-amber-400">
            {counts.near}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">
            Within {defaultDays} days or custom alert
          </p>
        </button>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-reminders' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-red-700 dark:text-red-400">Already Expired</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-red-700 dark:text-red-400">
            {counts.expired}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Check and clear items</p>
        </button>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-products' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400">Fresh / Good</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-emerald-700 dark:text-emerald-400">
            {counts.freshAndGood}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Safe for regular use</p>
        </button>
      </div>

      {/* Chart + Upcoming Expiry List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6">
          <ExpiryBarChart
            title="Expiry Overview"
            subtitle="Live breakdown of active pantry products by expiry status"
            data={[
              { label: 'Fresh', value: counts.fresh, color: accentPalette.accent },
              { label: 'Good', value: counts.good, color: '#16A34A' },
              { label: 'Near Expiry', value: counts.near, color: '#D97706' },
              { label: 'Expired', value: counts.expired, color: '#DC2626' },
            ]}
          />
        </div>

        <div className="lg:col-span-6 ea-glass rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-base font-semibold">Upcoming Expiries</h3>
                <p className="text-xs text-[var(--text-secondary)]">
                  Items sorted by nearest expiry date
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate({ name: 'household-products' })}
                className="text-xs font-semibold hover:underline cursor-pointer"
                style={{ color: 'var(--accent-text)' }}
              >
                View all
              </button>
            </div>

            {upcomingList.length === 0 ? (
              <div className="py-8 text-center space-y-2">
                <p className="text-sm text-[var(--text-secondary)]">
                  No upcoming items recorded yet.
                </p>
                <button
                  type="button"
                  onClick={() => navigate({ name: 'household-add' })}
                  className="text-xs font-semibold hover:underline cursor-pointer"
                  style={{ color: 'var(--accent-text)' }}
                >
                  Add your first pantry product
                </button>
              </div>
            ) : (
              <div className="divide-y divide-[var(--border-subtle)]">
                {upcomingList.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigate({ name: 'household-details', id: item.id })}
                    className="w-full py-3 flex items-center justify-between gap-3 text-left hover:opacity-85 transition-opacity cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <ProductAvatar
                        imageUrl={item.imageUrl}
                        name={item.name}
                        category={item.category}
                        sizeClass="h-10 w-10"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{item.name}</p>
                        <p className="text-xs text-[var(--text-secondary)]">
                          {item.quantity} {item.unit} · {formatShortDate(item.expiryDate)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <StatusText status={item.status} />
                      <p className="text-[11px] font-mono text-[var(--text-muted)] mt-0.5">
                        {formatDaysRemaining(item.daysRemaining)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Product Overview + Recent Product Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 ea-glass rounded-2xl p-6">
          <h3 className="text-base font-semibold mb-1">Product Category Overview</h3>
          <p className="text-xs text-[var(--text-secondary)] mb-4">
            Active pantry items grouped by food category
          </p>
          {enriched.length === 0 ? (
            <p className="text-sm text-[var(--text-secondary)] py-6">No active products yet.</p>
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {Object.entries(
                enriched.reduce<Record<string, number>>((acc, item) => {
                  acc[item.category] = (acc[item.category] ?? 0) + 1;
                  return acc;
                }, {})
              )
                .sort((a, b) => b[1] - a[1])
                .map(([cat, count]) => (
                  <div key={cat} className="py-2.5 flex items-center justify-between text-sm">
                    <span>{cat}</span>
                    <span className="font-mono font-semibold tabular-nums">{count}</span>
                  </div>
                ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-6 ea-glass rounded-2xl p-6">
          <h3 className="text-base font-semibold mb-1">Recent Product Activity</h3>
          <p className="text-xs text-[var(--text-secondary)] mb-4">
            Latest pantry additions, uses, and waste logs
          </p>
          {data.actions.length === 0 ? (
            <p className="text-sm text-[var(--text-secondary)] py-6">No activity recorded yet.</p>
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {data.actions.slice(0, 6).map((act) => (
                <div key={act.id} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{act.productName}</p>
                    <p className="text-xs text-[var(--text-secondary)] truncate">
                      {act.actionType.toUpperCase()} · {act.note}
                    </p>
                  </div>
                  {act.quantityDelta > 0 && (
                    <span className="font-mono text-xs font-semibold tabular-nums shrink-0">
                      {act.actionType === 'used' || act.actionType === 'wasted' ? '-' : '+'}
                      {act.quantityDelta} {act.unit}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const HouseholdProductsPage: React.FC<{
  data: HouseholdDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | ExpiryStatus>('All');
  const [sortBy, setSortBy] = useState<'expiry_asc' | 'expiry_desc' | 'name' | 'quantity'>(
    'expiry_asc'
  );
  const [showDepleted, setShowDepleted] = useState(false);

  const [actionModal, setActionModal] = useState<{
    product: HouseholdProduct;
    actionType: 'used' | 'wasted';
    qty: string;
    note: string;
  } | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);

  useEffect(() => {
    if (!actionModal) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setModalError(null);
        setActionModal(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [actionModal]);

  const enriched = useMemo(() => {
    return data.products
      .filter((p) => (showDepleted ? true : p.quantity > 0))
      .map((p) => {
        const calc = computeExpiryStatus(p.expiryDate, p.reminderDays ?? defaultDays);
        return { ...p, ...calc };
      })
      .filter((p) => {
        if (statusFilter !== 'All' && p.status !== statusFilter) return false;
        if (search.trim()) {
          const q = search.trim().toLowerCase();
          return (
            p.name.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q) ||
            p.notes.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'expiry_asc') return a.expiryDate.localeCompare(b.expiryDate);
        if (sortBy === 'expiry_desc') return b.expiryDate.localeCompare(a.expiryDate);
        if (sortBy === 'name') return a.name.localeCompare(b.name);
        return b.quantity - a.quantity;
      });
  }, [data.products, defaultDays, showDepleted, statusFilter, search, sortBy]);

  const openActionModal = (
    product: HouseholdProduct,
    actionType: 'used' | 'wasted'
  ) => {
    setModalError(null);
    setActionModal({
      product,
      actionType,
      qty: String(product.quantity),
      note: '',
    });
  };

  const handleConfirmAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionModal || !user) return;
    setModalError(null);
    setBusyId(actionModal.product.id);
    try {
      await logHouseholdAction(
        user.uid,
        actionModal.product.id,
        actionModal.actionType,
        Number(actionModal.qty),
        actionModal.note
      );
      await data.reload();
      setActionModal(null);
    } catch (err) {
      setModalError(err instanceof Error ? err.message : 'Unable to update item quantity.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    setActionError(null);
    setBusyId(id);
    try {
      await deleteHouseholdProduct(user.uid, id);
      await data.reload();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to delete item.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Household Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">My Products</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={data.products.length === 0}
            onClick={() => exportHouseholdInventoryCsv(data.products, defaultDays)}
            className="ea-surface inline-flex items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            onClick={() => navigate({ name: 'household-add' })}
            className="ea-btn-accent inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="ea-glass rounded-2xl p-4 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="h-4 w-4 absolute left-3.5 top-3 text-[var(--text-muted)]" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products, categories, or notes..."
              className="ea-input w-full rounded-xl pl-10 pr-3.5 py-2 text-sm"
            />
          </div>

          <div className="md:col-span-3">
            <select
              aria-label="Sort products"
              value={sortBy}
              onChange={(e) =>
                setSortBy(e.target.value as 'expiry_asc' | 'expiry_desc' | 'name' | 'quantity')
              }
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
            >
              <option value="expiry_asc">Expiry: Soonest first</option>
              <option value="expiry_desc">Expiry: Latest first</option>
              <option value="name">Name: A to Z</option>
              <option value="quantity">Quantity: Highest</option>
            </select>
          </div>

          <div className="md:col-span-3 flex items-center justify-end">
            <label className="inline-flex items-center gap-2 text-xs font-medium text-[var(--text-secondary)] cursor-pointer">
              <input
                type="checkbox"
                checked={showDepleted}
                onChange={(e) => setShowDepleted(e.target.checked)}
                className="rounded"
              />
              <span>Show zero-quantity items</span>
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {(['All', 'Fresh', 'Good', 'Near Expiry', 'Expired'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                statusFilter === status
                  ? 'ea-btn-accent'
                  : 'ea-surface text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {actionError && (
        <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-4 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
          {actionError}
        </p>
      )}

      {/* Empty State */}
      {enriched.length === 0 ? (
        <div className="ea-glass rounded-2xl p-10 text-center space-y-3">
          <p className="text-base font-semibold">No matching pantry products</p>
          <p className="text-sm text-[var(--text-secondary)]">
            Try clearing your search filter or add a new packaged food product.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
            {(search.trim() !== '' || statusFilter !== 'All' || showDepleted) && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setStatusFilter('All');
                  setShowDepleted(false);
                }}
                className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Reset Filters</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => navigate({ name: 'household-add' })}
              className="ea-btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Add Product</span>
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block ea-glass rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--border-subtle)] text-xs text-[var(--text-secondary)]">
                    <th className="py-3.5 px-5 font-semibold">Product</th>
                    <th className="py-3.5 px-4 font-semibold">Quantity</th>
                    <th className="py-3.5 px-4 font-semibold">Expiry Date</th>
                    <th className="py-3.5 px-4 font-semibold">Status</th>
                    <th className="py-3.5 px-5 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border-subtle)] text-sm">
                  {enriched.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                    >
                      <td className="py-3.5 px-5">
                        <button
                          type="button"
                          onClick={() => navigate({ name: 'household-details', id: item.id })}
                          className="flex items-center gap-3 text-left cursor-pointer group"
                        >
                          <ProductAvatar
                            imageUrl={item.imageUrl}
                            name={item.name}
                            category={item.category}
                          />
                          <div>
                            <p className="font-semibold group-hover:underline">{item.name}</p>
                            <p className="text-xs text-[var(--text-secondary)]">
                              {item.category}
                              {item.isDemo ? ' · Sample data' : ''}
                            </p>
                          </div>
                        </button>
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums whitespace-nowrap">
                        {item.quantity} {item.unit}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <p className="font-mono text-xs">{formatShortDate(item.expiryDate)}</p>
                        <p className="text-[11px] text-[var(--text-muted)]">
                          {formatDaysRemaining(item.daysRemaining)}
                        </p>
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusText status={item.status} />
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {item.quantity > 0 && (
                            <>
                              <button
                                type="button"
                                disabled={busyId === item.id}
                                onClick={() => openActionModal(item, 'used')}
                                className="ea-surface rounded-lg px-2.5 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:border-emerald-500/40 cursor-pointer"
                              >
                                Used
                              </button>
                              <button
                                type="button"
                                disabled={busyId === item.id}
                                onClick={() => openActionModal(item, 'wasted')}
                                className="ea-surface rounded-lg px-2.5 py-1.5 text-xs font-medium text-amber-700 dark:text-amber-400 hover:border-amber-500/40 cursor-pointer"
                              >
                                Wasted
                              </button>
                            </>
                          )}
                          <button
                            type="button"
                            onClick={() => navigate({ name: 'household-edit', id: item.id })}
                            aria-label={`Edit ${item.name}`}
                            className="rounded-lg p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                          >
                            <Edit3 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            disabled={busyId === item.id}
                            onClick={() => handleDelete(item.id)}
                            aria-label={`Delete ${item.name}`}
                            className="rounded-lg p-1.5 text-red-700 dark:text-red-400 hover:bg-red-500/10 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Card Layout */}
          <div className="md:hidden space-y-3">
            {enriched.map((item) => (
              <div key={item.id} className="ea-glass rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => navigate({ name: 'household-details', id: item.id })}
                    className="flex items-center gap-3 text-left min-w-0 cursor-pointer"
                  >
                    <ProductAvatar
                      imageUrl={item.imageUrl}
                      name={item.name}
                      category={item.category}
                    />
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{item.name}</p>
                      <p className="text-xs text-[var(--text-secondary)]">
                        {item.category} · <span className="font-mono">{item.quantity} {item.unit}</span>
                        {item.isDemo ? ' · Sample data' : ''}
                      </p>
                    </div>
                  </button>
                  <StatusText status={item.status} />
                </div>

                <div className="flex items-center justify-between text-xs text-[var(--text-secondary)] border-t border-[var(--border-subtle)] pt-2.5">
                  <span>Expires {formatShortDate(item.expiryDate)}</span>
                  <span className="font-mono">{formatDaysRemaining(item.daysRemaining)}</span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {item.quantity > 0 && (
                    <>
                      <button
                        type="button"
                        onClick={() => openActionModal(item, 'used')}
                        className="ea-surface flex-1 rounded-xl py-2.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 cursor-pointer"
                      >
                        Used
                      </button>
                      <button
                        type="button"
                        onClick={() => openActionModal(item, 'wasted')}
                        className="ea-surface flex-1 rounded-xl py-2.5 text-xs font-semibold text-amber-700 dark:text-amber-400 cursor-pointer"
                      >
                        Wasted
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => navigate({ name: 'household-edit', id: item.id })}
                    className="ea-surface rounded-xl px-3.5 py-2.5 text-xs font-medium cursor-pointer"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="ea-surface rounded-xl px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400 cursor-pointer"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Used / Wasted Quantity Modal */}
      {actionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <form
            onSubmit={handleConfirmAction}
            className="ea-glass w-full max-w-sm rounded-2xl p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-bold">
              {actionModal.actionType === 'used' ? 'Mark as Used' : 'Mark as Wasted'}
            </h3>
            <p className="text-sm text-[var(--text-secondary)]">
              {actionModal.product.name} ({actionModal.product.quantity} {actionModal.product.unit} available)
            </p>
            <div>
              <label className="block text-xs font-medium mb-1">
                Quantity ({actionModal.product.unit})
              </label>
              <input
                type="number"
                step="any"
                min="0.01"
                max={actionModal.product.quantity}
                required
                value={actionModal.qty}
                onChange={(e) => setActionModal({ ...actionModal, qty: e.target.value })}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Note (optional)</label>
              <input
                type="text"
                value={actionModal.note}
                onChange={(e) => setActionModal({ ...actionModal, note: e.target.value })}
                placeholder={
                  actionModal.actionType === 'used'
                    ? 'e.g. Finished for breakfast'
                    : 'e.g. Spoiled before finishing'
                }
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
            {modalError && (
              <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs font-medium text-red-700 dark:text-red-400">
                {modalError}
              </p>
            )}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setModalError(null);
                  setActionModal(null);
                }}
                className="ea-surface flex-1 rounded-xl py-2.5 text-sm font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busyId === actionModal.product.id}
                className="ea-btn-accent flex-1 rounded-xl py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
              >
                Confirm
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export const HouseholdProductFormPage: React.FC<{
  editingProduct?: HouseholdProduct | null;
  data: HouseholdDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ editingProduct, data, navigate }) => {
  const { user } = useAuthTheme();
  const today = getTodayIso();
  const [name, setName] = useState(editingProduct?.name ?? '');
  const [quantity, setQuantity] = useState(
    editingProduct ? String(editingProduct.quantity) : '1'
  );
  const [unit, setUnit] = useState(editingProduct?.unit ?? 'pcs');
  const [purchaseDate, setPurchaseDate] = useState(editingProduct?.purchaseDate ?? today);
  const [expiryDate, setExpiryDate] = useState(
    editingProduct?.expiryDate ?? addDaysIso(today, 7)
  );
  const [category, setCategory] = useState(editingProduct?.category ?? 'Dairy');
  const [reminderDays, setReminderDays] = useState(
    editingProduct?.reminderDays !== null && editingProduct?.reminderDays !== undefined
      ? String(editingProduct.reminderDays)
      : ''
  );
  const [notes, setNotes] = useState(editingProduct?.notes ?? '');
  const [imageUrl, setImageUrl] = useState<string | null>(editingProduct?.imageUrl ?? null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!editingProduct) return;
    setName(editingProduct.name);
    setQuantity(String(editingProduct.quantity));
    setUnit(editingProduct.unit);
    setPurchaseDate(editingProduct.purchaseDate);
    setExpiryDate(editingProduct.expiryDate);
    setCategory(editingProduct.category);
    setReminderDays(
      editingProduct.reminderDays !== null && editingProduct.reminderDays !== undefined
        ? String(editingProduct.reminderDays)
        : ''
    );
    setNotes(editingProduct.notes);
    setImageUrl(editingProduct.imageUrl ?? null);
  }, [editingProduct?.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError('Please enter a product name.');
      return;
    }
    const numQty = Number(quantity);
    if (!Number.isFinite(numQty) || numQty < 0) {
      setError('Quantity must be zero or greater.');
      return;
    }
    if (!purchaseDate || !expiryDate) {
      setError('Both purchase date and expiry date are required.');
      return;
    }

    if (!user) return;
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        quantity: numQty,
        unit: unit.trim() || 'pcs',
        purchaseDate,
        expiryDate,
        category,
        reminderDays: reminderDays === '' ? null : Number(reminderDays),
        notes: notes.trim(),
        imageUrl,
      };
      if (editingProduct) {
        await updateHouseholdProduct(user.uid, editingProduct.id, payload);
      } else {
        await createHouseholdProduct(user.uid, payload);
      }
      await data.reload();
      navigate({ name: 'household-products' });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save product.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-products' })}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] mb-2 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to My Products</span>
        </button>
        <h1 className="font-display text-2xl sm:text-3xl font-bold">
          {editingProduct ? 'Edit Product' : 'Add Product'}
        </h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">
          Manual entry for your household pantry and refrigerator.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="ea-glass rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="hp-name" className="block text-sm font-medium mb-1.5">
              Product name
            </label>
            <input
              id="hp-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Organic Whole Milk"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label htmlFor="hp-qty" className="block text-sm font-medium mb-1.5">
              Quantity
            </label>
            <input
              id="hp-qty"
              type="number"
              step="any"
              min="0"
              required
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
            />
          </div>

          <div>
            <label htmlFor="hp-unit" className="block text-sm font-medium mb-1.5">
              Unit
            </label>
            <input
              id="hp-unit"
              type="text"
              required
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="e.g. L, kg, pcs, pack"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label htmlFor="hp-purchase" className="block text-sm font-medium mb-1.5">
              Purchase date
            </label>
            <input
              id="hp-purchase"
              type="date"
              required
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
            />
          </div>

          <div>
            <label htmlFor="hp-expiry" className="block text-sm font-medium mb-1.5">
              Expiry date
            </label>
            <input
              id="hp-expiry"
              type="date"
              required
              value={expiryDate}
              onChange={(e) => setExpiryDate(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
            />
          </div>

          <div>
            <label htmlFor="hp-category" className="block text-sm font-medium mb-1.5">
              Category
            </label>
            <select
              id="hp-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              {HOUSEHOLD_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="hp-rem" className="block text-sm font-medium mb-1.5">
              Custom reminder (days before)
            </label>
            <select
              id="hp-rem"
              value={reminderDays}
              onChange={(e) => setReminderDays(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              <option value="">Use default setting</option>
              {REMINDER_DAY_OPTIONS.map((d) => (
                <option key={d} value={String(d)}>
                  {d === 0 ? 'On expiry date (0 days)' : `${d} days before`}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="hp-notes" className="block text-sm font-medium mb-1.5">
              Notes
            </label>
            <textarea
              id="hp-notes"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Storage notes or meal plans..."
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>
        </div>

        <ImageUploadField imageUrl={imageUrl} onChange={setImageUrl} />

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate({ name: 'household-products' })}
            className="ea-surface rounded-xl px-5 py-2.5 text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="ea-btn-accent rounded-xl px-6 py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
          >
            {saving ? 'Saving...' : 'Save Product'}
          </button>
        </div>
      </form>
    </div>
  );
};

export const HouseholdProductDetailsPage: React.FC<{
  productId: string;
  data: HouseholdDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ productId, data, navigate }) => {
  const { user } = useAuthTheme();
  const product = data.products.find((p) => p.id === productId);
  const [busy, setBusy] = useState(false);
  const [detailErr, setDetailErr] = useState<string | null>(null);

  if (!product) {
    return (
      <div className="ea-glass rounded-2xl p-8 text-center space-y-3">
        <p className="font-semibold">Product not found</p>
        <button
          type="button"
          onClick={() => navigate({ name: 'household-products' })}
          className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
        >
          Back to My Products
        </button>
      </div>
    );
  }

  const threshold = product.reminderDays ?? user?.defaultReminderDays ?? 5;
  const { status, daysRemaining } = computeExpiryStatus(product.expiryDate, threshold);
  const productActions = data.actions.filter((a) => a.productId === product.id);

  const quickConsume = async (actionType: 'used' | 'wasted') => {
    if (!user || product.quantity <= 0) return;
    setDetailErr(null);
    setBusy(true);
    try {
      await logHouseholdAction(user.uid, product.id, actionType, product.quantity);
      await data.reload();
    } catch (err) {
      setDetailErr(err instanceof Error ? err.message : 'Unable to update product.');
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async () => {
    if (!user) return;
    setDetailErr(null);
    setBusy(true);
    try {
      await deleteHouseholdProduct(user.uid, product.id);
      await data.reload();
      navigate({ name: 'household-products' });
    } catch (err) {
      setDetailErr(err instanceof Error ? err.message : 'Unable to delete product.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <button
        type="button"
        onClick={() => navigate({ name: 'household-products' })}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        <span>Back to My Products</span>
      </button>

      <div className="ea-glass rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-5">
          <div className="flex items-start gap-4">
            <ProductAvatar
              imageUrl={product.imageUrl}
              name={product.name}
              category={product.category}
              sizeClass="h-20 w-20"
            />
            <div className="space-y-1">
              <p className="text-xs text-[var(--text-secondary)]">
                {product.category}
                {product.isDemo ? ' · Sample data' : ''}
              </p>
              <h1 className="font-display text-2xl font-bold">{product.name}</h1>
              <div className="flex items-center gap-3 pt-1">
                <StatusText status={status} />
                <span className="text-xs font-mono text-[var(--text-muted)]">
                  {formatDaysRemaining(daysRemaining)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => navigate({ name: 'household-edit', id: product.id })}
              className="ea-surface rounded-xl px-3.5 py-2 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>Edit</span>
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={handleDelete}
              className="ea-surface rounded-xl px-3.5 py-2 text-xs font-semibold text-red-700 dark:text-red-400 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Delete</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2 border-t border-[var(--border-subtle)]">
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Quantity</p>
            <p className="font-mono font-semibold text-base mt-0.5 tabular-nums">
              {product.quantity} {product.unit}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Purchase Date</p>
            <p className="font-mono font-semibold text-sm mt-0.5">
              {formatShortDate(product.purchaseDate)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Expiry Date</p>
            <p className="font-mono font-semibold text-sm mt-0.5">
              {formatShortDate(product.expiryDate)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Reminder Window</p>
            <p className="font-mono font-semibold text-sm mt-0.5">
              {product.reminderDays !== null
                ? `${product.reminderDays} days (custom)`
                : `${threshold} days (default)`}
            </p>
          </div>
        </div>

        {product.notes && (
          <div className="pt-2 border-t border-[var(--border-subtle)]">
            <p className="text-xs text-[var(--text-secondary)] mb-1">Notes</p>
            <p className="text-sm leading-relaxed">{product.notes}</p>
          </div>
        )}

        {product.quantity > 0 && (
          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-[var(--border-subtle)]">
            <button
              type="button"
              disabled={busy}
              onClick={() => quickConsume('used')}
              className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-semibold cursor-pointer"
            >
              Mark All Used
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => quickConsume('wasted')}
              className="ea-surface rounded-xl px-4 py-2 text-sm font-semibold text-amber-700 dark:text-amber-400 cursor-pointer"
            >
              Mark All Wasted
            </button>
          </div>
        )}
        {detailErr && (
          <p className="text-xs font-medium text-red-700 dark:text-red-400">{detailErr}</p>
        )}
      </div>

      <div className="ea-glass rounded-2xl p-6">
        <h2 className="text-base font-semibold mb-3">Product Activity History</h2>
        {productActions.length === 0 ? (
          <p className="text-sm text-[var(--text-secondary)]">No activity recorded for this item.</p>
        ) : (
          <div className="divide-y divide-[var(--border-subtle)] text-sm">
            {productActions.map((act) => (
              <div key={act.id} className="py-2.5 flex items-center justify-between gap-4">
                <div>
                  <span className="font-semibold uppercase text-xs">{act.actionType}</span>
                  <span className="text-[var(--text-secondary)] text-xs ml-2">{act.note}</span>
                </div>
                <span className="font-mono text-xs text-[var(--text-muted)]">
                  {act.quantityDelta > 0 ? `${act.quantityDelta} ${act.unit}` : ''}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export const HouseholdRemindersPage: React.FC<{
  data: HouseholdDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user, setUser } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [tab, setTab] = useState<'active' | 'expired' | 'snoozed' | 'resolved'>('active');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [reminderErr, setReminderErr] = useState<string | null>(null);

  const stateMap = useMemo(() => {
    const map = new Map<string, ReminderStateRecord>();
    for (const st of data.reminderStates) {
      if (st.targetType === 'household_product') {
        map.set(st.targetId, st);
      }
    }
    return map;
  }, [data.reminderStates]);

  const today = getTodayIso();

  const items = useMemo(() => {
    return data.products
      .filter((p) => p.quantity > 0)
      .map((p) => {
        const threshold = p.reminderDays ?? defaultDays;
        const { status, daysRemaining } = computeExpiryStatus(p.expiryDate, threshold);
        const st = stateMap.get(p.id);
        const isSnoozed =
          st?.status === 'snoozed' && st.snoozedUntil && st.snoozedUntil >= today;
        const isResolved = st?.status === 'resolved';
        return {
          product: p,
          threshold,
          status,
          daysRemaining,
          state: st,
          isSnoozed,
          isResolved,
        };
      });
  }, [data.products, defaultDays, stateMap, today]);

  const expiringToday = items.filter(
    (i) => !i.isResolved && !i.isSnoozed && i.daysRemaining === 0
  );
  const upcoming = items.filter(
    (i) =>
      !i.isResolved &&
      !i.isSnoozed &&
      i.daysRemaining > 0 &&
      i.daysRemaining <= i.threshold
  );
  const expired = items.filter((i) => !i.isResolved && !i.isSnoozed && i.daysRemaining < 0);
  const snoozed = items.filter((i) => i.isSnoozed);
  const resolved = items.filter((i) => i.isResolved);

  const updateDefaultDays = async (days: number) => {
    if (!user) return;
    setReminderErr(null);
    try {
      const updated = await updateUserProfile(user.uid, { defaultReminderDays: days });
      setUser(updated);
    } catch (err) {
      setReminderErr(err instanceof Error ? err.message : 'Unable to update default reminder window.');
    }
  };

  const updateProductInterval = async (productId: string, val: string) => {
    if (!user) return;
    setReminderErr(null);
    setBusyId(productId);
    try {
      await updateHouseholdProduct(user.uid, productId, {
        reminderDays: val === '' ? null : Number(val),
      });
      await data.reload();
    } catch (err) {
      setReminderErr(err instanceof Error ? err.message : 'Unable to update product reminder.');
    } finally {
      setBusyId(null);
    }
  };

  const updateReminderState = async (
    productId: string,
    status: 'active' | 'snoozed' | 'resolved',
    snoozeDays = 2
  ) => {
    if (!user) return;
    setReminderErr(null);
    setBusyId(productId);
    try {
      await setReminderState(user.uid, {
        mode: 'household',
        targetType: 'household_product',
        targetId: productId,
        status,
        snoozeDays,
      });
      await data.reload();
    } catch (err) {
      setReminderErr(err instanceof Error ? err.message : 'Unable to update reminder state.');
    } finally {
      setBusyId(null);
    }
  };

  const renderReminderCard = (entry: (typeof items)[number], showRestore = false) => (
    <div key={entry.product.id} className="ea-glass rounded-2xl p-4 sm:p-5 space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate({ name: 'household-details', id: entry.product.id })}
          className="flex items-center gap-3 text-left cursor-pointer"
        >
          <ProductAvatar
            imageUrl={entry.product.imageUrl}
            name={entry.product.name}
            category={entry.product.category}
          />
          <div>
            <p className="font-semibold text-sm">{entry.product.name}</p>
            <p className="text-xs text-[var(--text-secondary)]">
              {entry.product.quantity} {entry.product.unit} · Expires{' '}
              {formatShortDate(entry.product.expiryDate)} ({formatDaysRemaining(entry.daysRemaining)})
            </p>
          </div>
        </button>

        <StatusText status={entry.status} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[var(--border-subtle)]">
        <div className="flex items-center gap-2 text-xs">
          <label
            htmlFor={`rem-int-${entry.product.id}`}
            className="text-[var(--text-secondary)]"
          >
            Product reminder:
          </label>
          <select
            id={`rem-int-${entry.product.id}`}
            disabled={busyId === entry.product.id}
            value={entry.product.reminderDays ?? ''}
            onChange={(e) => updateProductInterval(entry.product.id, e.target.value)}
            className="ea-input rounded-lg px-2.5 py-1 text-xs"
          >
            <option value="">Default ({defaultDays}d)</option>
            {REMINDER_DAY_OPTIONS.map((d) => (
              <option key={d} value={String(d)}>
                {d === 0 ? 'On expiry day' : `${d} days before`}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          {showRestore ? (
            <button
              type="button"
              disabled={busyId === entry.product.id}
              onClick={() => updateReminderState(entry.product.id, 'active')}
              className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Restore Alert</span>
            </button>
          ) : (
            <>
              <button
                type="button"
                disabled={busyId === entry.product.id}
                onClick={() => updateReminderState(entry.product.id, 'snoozed', 2)}
                className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
              >
                <AlarmClock className="h-3.5 w-3.5" />
                <span>Snooze 2d</span>
              </button>
              <button
                type="button"
                disabled={busyId === entry.product.id}
                onClick={() => updateReminderState(entry.product.id, 'resolved')}
                className="ea-btn-accent inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold cursor-pointer"
              >
                <Check className="h-3.5 w-3.5" />
                <span>Mark Resolved</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Household Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">Reminders</h1>
        </div>

        <div className="ea-glass rounded-2xl px-4 py-2.5 flex items-center gap-3">
          <span className="text-xs font-medium text-[var(--text-secondary)]">
            Default alert window:
          </span>
          <select
            aria-label="Default reminder threshold"
            value={defaultDays}
            onChange={(e) => updateDefaultDays(Number(e.target.value))}
            className="ea-input rounded-lg px-2.5 py-1 text-xs font-medium"
          >
            {REMINDER_DAY_OPTIONS.map((d) => (
              <option key={d} value={d}>
                {d === 0 ? 'On expiry date' : `${d} days before`}
              </option>
            ))}
          </select>
        </div>
      </div>

      <LockscreenPermissionBanner navigate={navigate} />

      {/* Category Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setTab('active')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'active' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Today & Upcoming ({expiringToday.length + upcoming.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('expired')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'expired' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Already Expired ({expired.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('snoozed')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'snoozed' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Snoozed ({snoozed.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('resolved')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'resolved' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Resolved ({resolved.length})
        </button>
      </div>

      {reminderErr && (
        <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-4 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
          {reminderErr}
        </p>
      )}

      {tab === 'active' && (
        <div className="space-y-6">
          {expiringToday.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-amber-700 dark:text-amber-400">
                Expiring Today ({expiringToday.length})
              </h2>
              {expiringToday.map((e) => renderReminderCard(e))}
            </div>
          )}

          <div className="space-y-3">
            <h2 className="text-sm font-semibold">
              Upcoming Reminders ({upcoming.length})
            </h2>
            {upcoming.length === 0 && expiringToday.length === 0 ? (
              <div className="ea-glass rounded-2xl p-8 text-center space-y-2">
                <CheckCircle2
                  className="h-7 w-7 mx-auto"
                  style={{ color: 'var(--accent-text)' }}
                />
                <p className="text-sm font-semibold">No upcoming expiry alerts right now</p>
                <p className="text-xs text-[var(--text-secondary)]">
                  Items within your configured reminder window will appear here automatically.
                </p>
              </div>
            ) : (
              upcoming.map((e) => renderReminderCard(e))
            )}
          </div>
        </div>
      )}

      {tab === 'expired' && (
        <div className="space-y-3">
          {expired.length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)]">
              No expired pantry items.
            </div>
          ) : (
            expired.map((e) => renderReminderCard(e))
          )}
        </div>
      )}

      {tab === 'snoozed' && (
        <div className="space-y-3">
          {snoozed.length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)] space-y-2">
              <BellOff className="h-6 w-6 mx-auto opacity-60" />
              <p>No snoozed reminders.</p>
            </div>
          ) : (
            snoozed.map((e) => renderReminderCard(e, true))
          )}
        </div>
      )}

      {tab === 'resolved' && (
        <div className="space-y-3">
          {resolved.length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)]">
              No resolved reminders yet.
            </div>
          ) : (
            resolved.map((e) => renderReminderCard(e, true))
          )}
        </div>
      )}
    </div>
  );
};
