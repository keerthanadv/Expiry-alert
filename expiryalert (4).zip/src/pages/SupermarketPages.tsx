import React, { useEffect, useMemo, useState } from 'react';
import {
  AlarmClock,
  AlertCircle,
  ArrowLeft,
  Boxes,
  Check,
  CheckCircle2,
  Download,
  Edit3,
  FileSpreadsheet,
  FolderCog,
  Plus,
  RotateCcw,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  bulkImportSupermarketBatches,
  createCategory,
  createSupermarketBatch,
  createSupermarketProduct,
  deleteCategory,
  deleteSupermarketProduct,
  logBatchAction,
  renameCategory,
  setReminderState as saveReminderState,
  updateSupermarketProduct,
  updateUserProfile,
} from '../services/dataService.ts';
import type { AppRoute } from '../components/AppShell.tsx';
import { ExpiryBarChart, HorizontalStockChart } from '../components/ExpiryBarChart.tsx';
import { ImageUploadField } from '../components/ImageUploadField.tsx';
import { LockscreenPermissionBanner } from '../components/LockscreenPermissionBanner.tsx';
import { ProductAvatar } from '../components/ProductAvatar.tsx';
import { StatusText } from '../components/StatusText.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import type {
  ExpiryStatus,
  ProductActionLog,
  ReminderStateRecord,
  SupermarketBatch,
  SupermarketCategory,
  SupermarketProduct,
} from '../types/index.ts';
import {
  addDaysIso,
  computeExpiryStatus,
  formatDaysRemaining,
  formatShortDate,
  getTodayIso,
} from '../utils/expiry.ts';
import {
  exportSupermarketBatchesCsv,
  exportSupermarketInventoryCsv,
} from '../utils/csvExport.ts';
import {
  downloadSupermarketBatchTemplateCsv,
  parseAndValidateBatchCsv,
  type CsvBatchParseResult,
} from '../utils/csvImport.ts';

export interface SupermarketDataBundle {
  categories: SupermarketCategory[];
  products: SupermarketProduct[];
  batches: SupermarketBatch[];
  actions: ProductActionLog[];
  reminderStates: ReminderStateRecord[];
  loading: boolean;
  reload: () => Promise<void>;
}

const REMINDER_DAY_OPTIONS = [15, 7, 5, 3, 1, 0];

function getProductSummary(product: SupermarketProduct, defaultDays: number) {
  const threshold = product.reminderDays ?? defaultDays;
  const activeBatches = [...product.batches]
    .filter((b) => b.remainingQuantity > 0)
    .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
  const totalRemaining = activeBatches.reduce((sum, b) => sum + b.remainingQuantity, 0);
  const availableNonExpired = activeBatches.reduce((sum, b) => {
    const { daysRemaining } = computeExpiryStatus(b.expiryDate, threshold);
    return daysRemaining >= 0 ? sum + b.remainingQuantity : sum;
  }, 0);

  const earliestBatch = activeBatches[0] ?? product.batches[0] ?? null;
  const expiryCalc = earliestBatch
    ? computeExpiryStatus(earliestBatch.expiryDate, threshold)
    : { status: 'Fresh' as ExpiryStatus, daysRemaining: 999 };
  const isLowStock = availableNonExpired <= product.lowStockThreshold;

  return {
    threshold,
    activeBatches,
    totalRemaining,
    availableNonExpired,
    earliestBatch,
    status: expiryCalc.status,
    daysRemaining: expiryCalc.daysRemaining,
    isLowStock,
  };
}

// ---------------- CATEGORY MANAGER MODAL ----------------

const CategoryManagerModal: React.FC<{
  categories: SupermarketCategory[];
  onClose: () => void;
  onChanged: () => Promise<void>;
}> = ({ categories, onClose, onChanged }) => {
  const { user } = useAuthTheme();
  const [newName, setNewName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !user) return;
    setError(null);
    setBusy(true);
    try {
      await createCategory(user.uid, newName.trim());
      setNewName('');
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to add category.');
    } finally {
      setBusy(false);
    }
  };

  const handleRename = async (id: string) => {
    if (!editingName.trim() || !user) return;
    setError(null);
    setBusy(true);
    try {
      await renameCategory(user.uid, id, editingName.trim());
      setEditingId(null);
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to rename category.');
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    setError(null);
    setBusy(true);
    try {
      await deleteCategory(user.uid, id);
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete category.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="ea-glass w-full max-w-lg rounded-3xl p-6 space-y-4 max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg font-bold">Manage Product Categories</h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close category manager"
            className="rounded-lg p-1.5 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleAdd} className="flex gap-2">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="New custom category name..."
            className="ea-input flex-1 rounded-xl px-3.5 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={busy}
            className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-semibold whitespace-nowrap cursor-pointer"
          >
            Add
          </button>
        </form>

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <div className="overflow-y-auto divide-y divide-[var(--border-subtle)] pr-1">
          {categories.map((cat) => (
            <div key={cat.id} className="py-2.5 flex items-center justify-between gap-2 text-sm">
              {editingId === cat.id ? (
                <div className="flex-1 flex items-center gap-2">
                  <input
                    type="text"
                    value={editingName}
                    onChange={(e) => setEditingName(e.target.value)}
                    className="ea-input flex-1 rounded-lg px-2.5 py-1 text-sm"
                  />
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => handleRename(cat.id)}
                    className="ea-btn-accent rounded-lg px-2.5 py-1 text-xs font-medium cursor-pointer"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingId(null)}
                    className="ea-surface rounded-lg px-2.5 py-1 text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <>
                  <div>
                    <span className="font-medium">{cat.name}</span>
                    {!cat.isDefault && (
                      <span className="ml-2 text-[11px] text-[var(--text-muted)]">Custom</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingId(cat.id);
                        setEditingName(cat.name);
                      }}
                      className="rounded-lg p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                      aria-label={`Rename ${cat.name}`}
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                    </button>
                    {!cat.isDefault && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => handleDelete(cat.id)}
                        className="rounded-lg p-1.5 text-red-700 dark:text-red-400 hover:bg-red-500/10 cursor-pointer"
                        aria-label={`Delete ${cat.name}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ---------------- SUPERMARKET DASHBOARD ----------------

export const SupermarketDashboardPage: React.FC<{
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user, accentPalette } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [showCatManager, setShowCatManager] = useState(false);

  const productSummaries = useMemo(
    () => data.products.map((p) => ({ product: p, ...getProductSummary(p, defaultDays) })),
    [data.products, defaultDays]
  );

  const activeBatches = useMemo(
    () =>
      data.batches
        .filter((b) => b.remainingQuantity > 0)
        .map((b) => {
          const prod = data.products.find((p) => p.id === b.productId);
          const threshold = prod?.reminderDays ?? defaultDays;
          const calc = computeExpiryStatus(b.expiryDate, threshold);
          return { ...b, ...calc };
        })
        .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate)),
    [data.batches, data.products, defaultDays]
  );

  const metrics = useMemo(() => {
    let totalStockQty = 0;
    let availableStockQty = 0;
    let freshBatches = 0;
    let goodBatches = 0;
    let expiringSoonBatches = 0;
    let expiredBatches = 0;

    for (const b of activeBatches) {
      totalStockQty += b.remainingQuantity;
      if (b.daysRemaining >= 0) {
        availableStockQty += b.remainingQuantity;
      }
      if (b.status === 'Fresh') freshBatches++;
      else if (b.status === 'Good') goodBatches++;
      else if (b.status === 'Near Expiry') expiringSoonBatches++;
      else expiredBatches++;
    }

    const lowStockProducts = productSummaries.filter((ps) => ps.isLowStock).length;

    return {
      totalProducts: data.products.length,
      totalStockQty: Number(totalStockQty.toFixed(1)),
      availableStockQty: Number(availableStockQty.toFixed(1)),
      expiringSoonBatches,
      expiredBatches,
      freshBatches,
      goodBatches,
      lowStockProducts,
    };
  }, [activeBatches, productSummaries, data.products.length]);

  const categoryStockData = useMemo(() => {
    const map = new Map<string, number>();
    for (const b of activeBatches) {
      const cat = b.categoryName || 'Uncategorized';
      map.set(cat, (map.get(cat) ?? 0) + b.remainingQuantity);
    }
    return Array.from(map.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([label, value]) => ({
        label,
        value: Number(value.toFixed(1)),
        color: accentPalette.accent,
      }));
  }, [activeBatches, accentPalette.accent]);

  const batchAlerts = useMemo(
    () => activeBatches.filter((b) => b.status === 'Near Expiry' || b.status === 'Expired').slice(0, 6),
    [activeBatches]
  );

  if (data.loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-64 rounded-xl bg-[var(--surface-subtle)]" />
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-28 rounded-2xl ea-glass" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Supermarket Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Inventory Dashboard
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setShowCatManager(true)}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer"
          >
            <FolderCog className="h-4 w-4" />
            <span>Categories</span>
          </button>
          <button
            type="button"
            onClick={() => navigate({ name: 'supermarket-add' })}
            className="ea-btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* 6 Supermarket KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-products' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-[var(--text-secondary)]">Total Products</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2">{metrics.totalProducts}</p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Catalog items tracked</p>
        </button>

        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-batches' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-[var(--text-secondary)]">Total Stock Quantity</p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2">{metrics.totalStockQty}</p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Units across all active batches</p>
        </button>

        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-products' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
            Available Stock
          </p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-emerald-700 dark:text-emerald-400">
            {metrics.availableStockQty}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Non-expired units ready for sale</p>
        </button>

        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-batches' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-amber-700 dark:text-amber-400">
            Expiring Soon Batches
          </p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-amber-700 dark:text-amber-400">
            {metrics.expiringSoonBatches}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Priority shelf rotation needed</p>
        </button>

        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-batches' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-red-700 dark:text-red-400">
            Already Expired Batches
          </p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-red-700 dark:text-red-400">
            {metrics.expiredBatches}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">Remove from retail shelf</p>
        </button>

        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-reminders' })}
          className="ea-glass ea-card-interactive rounded-2xl p-5 text-left cursor-pointer"
        >
          <p className="text-xs font-medium text-amber-700 dark:text-amber-400">
            Low-Stock Products
          </p>
          <p className="font-mono text-3xl font-bold tabular-nums mt-2 text-amber-700 dark:text-amber-400">
            {metrics.lowStockProducts}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1">At or below reorder threshold</p>
        </button>
      </div>

      {/* Expiry Overview Graph + Stock Overview Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6">
          <ExpiryBarChart
            title="Expiry Overview (By Batch)"
            subtitle="Active stock batches grouped by expiry status"
            data={[
              { label: 'Fresh', value: metrics.freshBatches, color: accentPalette.accent },
              { label: 'Good', value: metrics.goodBatches, color: '#16A34A' },
              {
                label: 'Near Expiry',
                value: metrics.expiringSoonBatches,
                color: '#D97706',
              },
              { label: 'Expired', value: metrics.expiredBatches, color: '#DC2626' },
            ]}
          />
        </div>

        <div className="lg:col-span-6">
          <HorizontalStockChart
            title="Stock Overview by Category"
            subtitle="Remaining units grouped across top retail categories"
            data={categoryStockData}
            unitLabel="units"
          />
        </div>
      </div>

      {/* Batch Alerts + Category Overview + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 ea-glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-semibold">Batch Alerts</h3>
              <p className="text-xs text-[var(--text-secondary)]">
                Prioritised by earliest expiry date
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate({ name: 'supermarket-batches' })}
              className="text-xs font-semibold hover:underline cursor-pointer"
              style={{ color: 'var(--accent-text)' }}
            >
              Manage batches
            </button>
          </div>
          {batchAlerts.length === 0 ? (
            <p className="text-sm text-[var(--text-secondary)] py-6">
              All active batches are currently within safe shelf-life windows.
            </p>
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {batchAlerts.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => navigate({ name: 'supermarket-details', id: b.productId })}
                  className="w-full py-3 flex items-center justify-between gap-3 text-left hover:opacity-85 cursor-pointer"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold truncate">{b.productName}</p>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Batch <span className="font-mono">{b.batchNumber}</span> ·{' '}
                      <span className="font-mono">
                        {b.remainingQuantity} {b.productUnit}
                      </span>
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <StatusText status={b.status} />
                    <p className="text-[11px] font-mono text-[var(--text-muted)] mt-0.5">
                      {formatDaysRemaining(b.daysRemaining)}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-6 ea-glass rounded-2xl p-6">
          <h3 className="text-base font-semibold mb-1">Recent Inventory Activity</h3>
          <p className="text-xs text-[var(--text-secondary)] mb-4">
            Sales, waste logs, restocks, and batch updates
          </p>
          {data.actions.length === 0 ? (
            <p className="text-sm text-[var(--text-secondary)] py-6">No inventory activity yet.</p>
          ) : (
            <div className="divide-y divide-[var(--border-subtle)]">
              {data.actions.slice(0, 6).map((act) => (
                <div key={act.id} className="py-2.5 flex items-center justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{act.productName}</p>
                    <p className="text-xs text-[var(--text-secondary)] truncate">
                      {act.actionType.toUpperCase()} · {act.note}
                    </p>
                  </div>
                  {act.quantityDelta > 0 && (
                    <span className="font-mono text-xs font-semibold tabular-nums shrink-0">
                      {act.actionType === 'sold' || act.actionType === 'wasted' ? '-' : '+'}
                      {act.quantityDelta} {act.unit}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showCatManager && (
        <CategoryManagerModal
          categories={data.categories}
          onClose={() => setShowCatManager(false)}
          onChanged={data.reload}
        />
      )}
    </div>
  );
};

// ---------------- SUPERMARKET MY PRODUCTS ----------------

export const SupermarketProductsPage: React.FC<{
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'All' | ExpiryStatus>('All');
  const [sortBy, setSortBy] = useState<'expiry_asc' | 'name' | 'stock_asc' | 'stock_desc'>(
    'expiry_asc'
  );
  const [showCatManager, setShowCatManager] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [listError, setListError] = useState<string | null>(null);

  const enriched = useMemo(() => {
    return data.products
      .map((p) => ({ product: p, ...getProductSummary(p, defaultDays) }))
      .filter((entry) => {
        if (categoryFilter !== 'All' && entry.product.categoryName !== categoryFilter) {
          return false;
        }
        if (statusFilter !== 'All' && entry.status !== statusFilter) {
          return false;
        }
        if (search.trim()) {
          const q = search.trim().toLowerCase();
          const batchMatch = entry.product.batches.some((b) =>
            b.batchNumber.toLowerCase().includes(q)
          );
          return (
            entry.product.name.toLowerCase().includes(q) ||
            entry.product.categoryName.toLowerCase().includes(q) ||
            batchMatch
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'expiry_asc') {
          const ea = a.earliestBatch?.expiryDate ?? '9999-12-31';
          const eb = b.earliestBatch?.expiryDate ?? '9999-12-31';
          return ea.localeCompare(eb);
        }
        if (sortBy === 'name') return a.product.name.localeCompare(b.product.name);
        if (sortBy === 'stock_asc') return a.totalRemaining - b.totalRemaining;
        return b.totalRemaining - a.totalRemaining;
      });
  }, [data.products, defaultDays, categoryFilter, statusFilter, search, sortBy]);

  const handleDeleteProduct = async (id: string) => {
    if (!user) return;
    setListError(null);
    setBusyId(id);
    try {
      await deleteSupermarketProduct(user.uid, id);
      await data.reload();
    } catch (err) {
      setListError(err instanceof Error ? err.message : 'Unable to delete product.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Supermarket Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">My Products</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={data.products.length === 0}
            onClick={() => exportSupermarketInventoryCsv(data.products, defaultDays)}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            onClick={() => setShowCatManager(true)}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer"
          >
            <FolderCog className="h-4 w-4" />
            <span>Manage Categories</span>
          </button>
          <button
            type="button"
            onClick={() => navigate({ name: 'supermarket-add' })}
            className="ea-btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="ea-glass rounded-2xl p-4 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-5 relative">
            <Search className="h-4 w-4 absolute left-3.5 top-3 text-[var(--text-muted)]" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search product, category, or batch number..."
              className="ea-input w-full rounded-xl pl-10 pr-3.5 py-2 text-sm"
            />
          </div>

          <div className="md:col-span-4">
            <select
              aria-label="Filter by category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
            >
              <option value="All">All categories</option>
              {data.categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-3">
            <select
              aria-label="Sort products"
              value={sortBy}
              onChange={(e) =>
                setSortBy(e.target.value as 'expiry_asc' | 'name' | 'stock_asc' | 'stock_desc')
              }
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
            >
              <option value="expiry_asc">Earliest Expiry</option>
              <option value="name">Name: A to Z</option>
              <option value="stock_asc">Stock: Lowest first</option>
              <option value="stock_desc">Stock: Highest first</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {(['All', 'Fresh', 'Good', 'Near Expiry', 'Expired'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-medium cursor-pointer ${
                statusFilter === status
                  ? 'ea-btn-accent'
                  : 'ea-surface text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {listError && (
        <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-4 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
          {listError}
        </p>
      )}

      {enriched.length === 0 ? (
        <div className="ea-glass rounded-2xl p-10 text-center space-y-3">
          <p className="text-base font-semibold">No matching supermarket products</p>
          <p className="text-sm text-[var(--text-secondary)]">
            Adjust your filters or add a new product with a compulsory batch number.
          </p>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block ea-glass rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--border-subtle)] text-xs text-[var(--text-secondary)]">
                    <th className="py-3.5 px-5 font-semibold">Product</th>
                    <th className="py-3.5 px-4 font-semibold">Category</th>
                    <th className="py-3.5 px-4 font-semibold">Priority Batch</th>
                    <th className="py-3.5 px-4 font-semibold">Total Stock</th>
                    <th className="py-3.5 px-4 font-semibold">Earliest Expiry</th>
                    <th className="py-3.5 px-4 font-semibold">Status</th>
                    <th className="py-3.5 px-5 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border-subtle)] text-sm">
                  {enriched.map((entry) => (
                    <tr
                      key={entry.product.id}
                      className="hover:bg-black/[0.02] dark:hover:bg-white/[0.02]"
                    >
                      <td className="py-3.5 px-5">
                        <button
                          type="button"
                          onClick={() =>
                            navigate({ name: 'supermarket-details', id: entry.product.id })
                          }
                          className="flex items-center gap-3 text-left cursor-pointer group"
                        >
                          <ProductAvatar
                            imageUrl={entry.product.imageUrl}
                            name={entry.product.name}
                            category={entry.product.categoryName}
                          />
                          <div>
                            <p className="font-semibold group-hover:underline">
                              {entry.product.name}
                            </p>
                            <p className="text-xs text-[var(--text-secondary)]">
                              {entry.activeBatches.length} active batch(es)
                              {entry.product.isDemo ? ' · Sample data' : ''}
                            </p>
                          </div>
                        </button>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-[var(--text-secondary)]">
                        {entry.product.categoryName}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs">
                        {entry.earliestBatch ? entry.earliestBatch.batchNumber : '—'}
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums whitespace-nowrap">
                        <span>
                          {entry.totalRemaining} {entry.product.unit}
                        </span>
                        {entry.isLowStock && (
                          <span className="block text-[11px] font-sans font-medium text-amber-700 dark:text-amber-400">
                            Low stock
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {entry.earliestBatch ? (
                          <>
                            <p className="font-mono text-xs">
                              {formatShortDate(entry.earliestBatch.expiryDate)}
                            </p>
                            <p className="text-[11px] text-[var(--text-muted)]">
                              {formatDaysRemaining(entry.daysRemaining)}
                            </p>
                          </>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusText status={entry.status} />
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              navigate({ name: 'supermarket-details', id: entry.product.id })
                            }
                            className="ea-surface rounded-lg px-2.5 py-1.5 text-xs font-medium cursor-pointer"
                          >
                            Batches
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              navigate({ name: 'supermarket-edit', id: entry.product.id })
                            }
                            aria-label={`Edit ${entry.product.name}`}
                            className="rounded-lg p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                          >
                            <Edit3 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            disabled={busyId === entry.product.id}
                            onClick={() => handleDeleteProduct(entry.product.id)}
                            aria-label={`Delete ${entry.product.name}`}
                            className="rounded-lg p-1.5 text-red-700 dark:text-red-400 hover:bg-red-500/10 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {enriched.map((entry) => (
              <div key={entry.product.id} className="ea-glass rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      navigate({ name: 'supermarket-details', id: entry.product.id })
                    }
                    className="flex items-center gap-3 text-left min-w-0 cursor-pointer"
                  >
                    <ProductAvatar
                      imageUrl={entry.product.imageUrl}
                      name={entry.product.name}
                      category={entry.product.categoryName}
                    />
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{entry.product.name}</p>
                      <p className="text-xs text-[var(--text-secondary)]">
                        {entry.product.categoryName} · Batch{' '}
                        <span className="font-mono">
                          {entry.earliestBatch?.batchNumber ?? '—'}
                        </span>
                      </p>
                    </div>
                  </button>
                  <StatusText status={entry.status} />
                </div>

                <div className="flex items-center justify-between text-xs text-[var(--text-secondary)] border-t border-[var(--border-subtle)] pt-2.5">
                  <span className="font-mono">
                    {entry.totalRemaining} {entry.product.unit}
                    {entry.isLowStock ? ' (Low stock)' : ''}
                  </span>
                  <span>
                    {entry.earliestBatch
                      ? `Earliest: ${formatShortDate(entry.earliestBatch.expiryDate)}`
                      : 'No batches'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      navigate({ name: 'supermarket-details', id: entry.product.id })
                    }
                    className="ea-btn-accent flex-1 rounded-xl py-2 text-xs font-semibold cursor-pointer"
                  >
                    View Batches
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate({ name: 'supermarket-edit', id: entry.product.id })}
                    className="ea-surface rounded-xl px-3.5 py-2 text-xs font-medium cursor-pointer"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteProduct(entry.product.id)}
                    className="ea-surface rounded-xl px-3.5 py-2 text-xs font-medium text-red-700 dark:text-red-400 cursor-pointer"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {showCatManager && (
        <CategoryManagerModal
          categories={data.categories}
          onClose={() => setShowCatManager(false)}
          onChanged={data.reload}
        />
      )}
    </div>
  );
};

// ---------------- SUPERMARKET ADD / EDIT PRODUCT ----------------

export const SupermarketProductFormPage: React.FC<{
  editingProduct?: SupermarketProduct | null;
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ editingProduct, data, navigate }) => {
  const { user } = useAuthTheme();
  const today = getTodayIso();
  const [name, setName] = useState(editingProduct?.name ?? '');
  const [categoryId, setCategoryId] = useState<string>(
    editingProduct ? String(editingProduct.categoryId) : String(data.categories[0]?.id ?? '')
  );
  const [unit, setUnit] = useState(editingProduct?.unit ?? 'units');
  const [lowStockThreshold, setLowStockThreshold] = useState(
    editingProduct ? String(editingProduct.lowStockThreshold) : '10'
  );
  const [reminderDays, setReminderDays] = useState(
    editingProduct?.reminderDays !== null && editingProduct?.reminderDays !== undefined
      ? String(editingProduct.reminderDays)
      : ''
  );
  const [notes, setNotes] = useState(editingProduct?.notes ?? '');
  const [imageUrl, setImageUrl] = useState<string | null>(editingProduct?.imageUrl ?? null);

  // Compulsory initial batch fields (for new product creation)
  const [batchNumber, setBatchNumber] = useState('');
  const [initialQuantity, setInitialQuantity] = useState('20');
  const [purchaseDate, setPurchaseDate] = useState(today);
  const [expiryDate, setExpiryDate] = useState(addDaysIso(today, 14));
  const [batchNotes, setBatchNotes] = useState('');

  // Inline custom category creation
  const [quickCatName, setQuickCatName] = useState('');
  const [showQuickCat, setShowQuickCat] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!editingProduct && !categoryId && data.categories.length > 0) {
      setCategoryId(String(data.categories[0].id));
    }
  }, [editingProduct, categoryId, data.categories]);

  useEffect(() => {
    if (!editingProduct) return;
    setName(editingProduct.name);
    setCategoryId(String(editingProduct.categoryId));
    setUnit(editingProduct.unit);
    setLowStockThreshold(String(editingProduct.lowStockThreshold));
    setReminderDays(
      editingProduct.reminderDays !== null && editingProduct.reminderDays !== undefined
        ? String(editingProduct.reminderDays)
        : ''
    );
    setNotes(editingProduct.notes);
    setImageUrl(editingProduct.imageUrl ?? null);
  }, [editingProduct?.id]);

  const handleCreateQuickCategory = async () => {
    if (!quickCatName.trim() || !user) return;
    try {
      const category = await createCategory(user.uid, quickCatName.trim());
      await data.reload();
      setCategoryId(category.id);
      setQuickCatName('');
      setShowQuickCat(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create category.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError('Product name is required.');
      return;
    }
    if (!categoryId) {
      setError('Please choose a product category.');
      return;
    }
    if (!editingProduct) {
      if (!batchNumber.trim()) {
        setError('Batch number is compulsory for supermarket products.');
        return;
      }
      if (!Number.isFinite(Number(initialQuantity)) || Number(initialQuantity) <= 0) {
        setError('Initial batch quantity must be greater than zero.');
        return;
      }
    }
    if (!user) return;

    setSaving(true);
    try {
      if (editingProduct) {
        await updateSupermarketProduct(user.uid, editingProduct.id, {
          name: name.trim(),
          categoryId,
          unit: unit.trim() || 'units',
          lowStockThreshold: Number(lowStockThreshold) || 0,
          reminderDays: reminderDays === '' ? null : Number(reminderDays),
          notes: notes.trim(),
          imageUrl,
        });
      } else {
        await createSupermarketProduct(user.uid, {
          name: name.trim(),
          categoryId,
          unit: unit.trim() || 'units',
          lowStockThreshold: Number(lowStockThreshold) || 0,
          reminderDays: reminderDays === '' ? null : Number(reminderDays),
          notes: notes.trim(),
          imageUrl,
          batchNumber: batchNumber.trim(),
          initialQuantity: Number(initialQuantity),
          purchaseDate,
          expiryDate,
          batchNotes: batchNotes.trim(),
        });
      }
      await data.reload();
      navigate({ name: 'supermarket-products' });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save product.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-products' })}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] mb-2 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to My Products</span>
        </button>
        <h1 className="font-display text-2xl sm:text-3xl font-bold">
          {editingProduct ? 'Edit Supermarket Product' : 'Add Supermarket Product'}
        </h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">
          {editingProduct
            ? 'Update product details. Batch quantities and expiry dates are managed separately per batch.'
            : 'Manual entry with compulsory initial batch tracking.'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="ea-glass rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="sp-name" className="block text-sm font-medium mb-1.5">
              Product name
            </label>
            <input
              id="sp-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Farmstead UHT Milk 1L"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>

          <div className="sm:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="sp-cat" className="block text-sm font-medium">
                Category
              </label>
              <button
                type="button"
                onClick={() => setShowQuickCat((s) => !s)}
                className="text-xs font-medium hover:underline cursor-pointer"
                style={{ color: 'var(--accent-text)' }}
              >
                {showQuickCat ? 'Cancel' : '+ New custom category'}
              </button>
            </div>
            <select
              id="sp-cat"
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              {data.categories.map((c) => (
                <option key={c.id} value={String(c.id)}>
                  {c.name}
                </option>
              ))}
            </select>
            {showQuickCat && (
              <div className="flex gap-2 mt-2">
                <input
                  type="text"
                  value={quickCatName}
                  onChange={(e) => setQuickCatName(e.target.value)}
                  placeholder="Enter custom category..."
                  className="ea-input flex-1 rounded-xl px-3 py-2 text-sm"
                />
                <button
                  type="button"
                  onClick={handleCreateQuickCategory}
                  className="ea-btn-accent rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
                >
                  Create
                </button>
              </div>
            )}
          </div>

          <div>
            <label htmlFor="sp-unit" className="block text-sm font-medium mb-1.5">
              Unit
            </label>
            <input
              id="sp-unit"
              type="text"
              required
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="e.g. cartons, packs, loaves"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label htmlFor="sp-low" className="block text-sm font-medium mb-1.5">
              Low-stock alert threshold
            </label>
            <input
              id="sp-low"
              type="number"
              min="0"
              step="any"
              value={lowStockThreshold}
              onChange={(e) => setLowStockThreshold(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
            />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="sp-rem" className="block text-sm font-medium mb-1.5">
              Custom reminder interval (days before expiry)
            </label>
            <select
              id="sp-rem"
              value={reminderDays}
              onChange={(e) => setReminderDays(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              <option value="">Use default setting</option>
              {REMINDER_DAY_OPTIONS.map((d) => (
                <option key={d} value={String(d)}>
                  {d === 0 ? 'On expiry date (0 days)' : `${d} days before`}
                </option>
              ))}
            </select>
          </div>
        </div>

        {!editingProduct && (
          <div className="pt-4 border-t border-[var(--border-subtle)] space-y-4">
            <div>
              <h2 className="text-sm font-semibold">Initial Batch Record (Compulsory)</h2>
              <p className="text-xs text-[var(--text-secondary)]">
                Each shipment with its own expiry date is tracked as a separate batch.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="sp-batch-num" className="block text-sm font-medium mb-1.5">
                  Batch number *
                </label>
                <input
                  id="sp-batch-num"
                  type="text"
                  required
                  value={batchNumber}
                  onChange={(e) => setBatchNumber(e.target.value)}
                  placeholder="e.g. DY-2408A"
                  className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
                />
              </div>
              <div>
                <label htmlFor="sp-batch-qty" className="block text-sm font-medium mb-1.5">
                  Initial quantity *
                </label>
                <input
                  id="sp-batch-qty"
                  type="number"
                  step="any"
                  min="0.01"
                  required
                  value={initialQuantity}
                  onChange={(e) => setInitialQuantity(e.target.value)}
                  className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
                />
              </div>
              <div>
                <label htmlFor="sp-batch-pur" className="block text-sm font-medium mb-1.5">
                  Purchase / stock date *
                </label>
                <input
                  id="sp-batch-pur"
                  type="date"
                  required
                  value={purchaseDate}
                  onChange={(e) => setPurchaseDate(e.target.value)}
                  className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
                />
              </div>
              <div>
                <label htmlFor="sp-batch-exp" className="block text-sm font-medium mb-1.5">
                  Expiry date *
                </label>
                <input
                  id="sp-batch-exp"
                  type="date"
                  required
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm font-mono"
                />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="sp-batch-notes" className="block text-sm font-medium mb-1.5">
                  Batch notes
                </label>
                <input
                  id="sp-batch-notes"
                  type="text"
                  value={batchNotes}
                  onChange={(e) => setBatchNotes(e.target.value)}
                  placeholder="e.g. Aisle 2 refrigerated shelf"
                  className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
                />
              </div>
            </div>
          </div>
        )}

        <div>
          <label htmlFor="sp-notes" className="block text-sm font-medium mb-1.5">
            Product notes
          </label>
          <textarea
            id="sp-notes"
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="General storage or supplier notes..."
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          />
        </div>

        <ImageUploadField imageUrl={imageUrl} onChange={setImageUrl} />

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate({ name: 'supermarket-products' })}
            className="ea-surface rounded-xl px-5 py-2.5 text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="ea-btn-accent rounded-xl px-6 py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
          >
            {saving ? 'Saving...' : 'Save Product'}
          </button>
        </div>
      </form>
    </div>
  );
};

// ---------------- BATCH ACTION & ADD MODALS ----------------

const AddBatchModal: React.FC<{
  products: SupermarketProduct[];
  defaultProductId?: string;
  onClose: () => void;
  onSaved: () => Promise<void>;
}> = ({ products, defaultProductId, onClose, onSaved }) => {
  const { user } = useAuthTheme();
  const today = getTodayIso();
  const [productId, setProductId] = useState<string>(
    String(defaultProductId ?? products[0]?.id ?? '')
  );
  const [batchNumber, setBatchNumber] = useState('');
  const [initialQuantity, setInitialQuantity] = useState('20');
  const [purchaseDate, setPurchaseDate] = useState(today);
  const [expiryDate, setExpiryDate] = useState(addDaysIso(today, 14));
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!productId && products.length > 0) {
      setProductId(String(defaultProductId ?? products[0].id));
    }
  }, [productId, products, defaultProductId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!batchNumber.trim()) {
      setError('Batch number is compulsory.');
      return;
    }
    if (!user) return;
    setSaving(true);
    try {
      await createSupermarketBatch(user.uid, {
        productId,
        batchNumber: batchNumber.trim(),
        initialQuantity: Number(initialQuantity),
        purchaseDate,
        expiryDate,
        notes: notes.trim(),
      });
      await onSaved();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to add batch.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <form
        onSubmit={handleSubmit}
        className="ea-glass w-full max-w-md rounded-3xl p-6 space-y-4"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg font-bold">Add Separate Batch</h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="rounded-lg p-1.5 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div>
          <label className="block text-xs font-medium mb-1">Product</label>
          <select
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            disabled={Boolean(defaultProductId)}
            className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
          >
            {products.map((p) => (
              <option key={p.id} value={String(p.id)}>
                {p.name} ({p.unit})
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium mb-1">Batch number *</label>
            <input
              type="text"
              required
              value={batchNumber}
              onChange={(e) => setBatchNumber(e.target.value)}
              placeholder="e.g. BT-302"
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Initial quantity *</label>
            <input
              type="number"
              step="any"
              min="0.01"
              required
              value={initialQuantity}
              onChange={(e) => setInitialQuantity(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Purchase date *</label>
            <input
              type="date"
              required
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Expiry date *</label>
            <input
              type="date"
              required
              value={expiryDate}
              onChange={(e) => setExpiryDate(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium mb-1">Notes</label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Shelf or pallet reference..."
            className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
          />
        </div>

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="ea-surface flex-1 rounded-xl py-2.5 text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="ea-btn-accent flex-1 rounded-xl py-2.5 text-sm font-semibold cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save Batch'}
          </button>
        </div>
      </form>
    </div>
  );
};

const CsvBatchImportModal: React.FC<{
  products: SupermarketProduct[];
  onClose: () => void;
  onImported: (count: number) => Promise<void>;
}> = ({ products, onClose, onImported }) => {
  const { user } = useAuthTheme();
  const [fileName, setFileName] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<CsvBatchParseResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setError(null);
    if (file.size > 2 * 1024 * 1024) {
      setParseResult(null);
      setFileName(file.name);
      setError('CSV file must be smaller than 2 MB.');
      return;
    }
    try {
      const text = await file.text();
      const result = parseAndValidateBatchCsv(text, products);
      setFileName(file.name);
      setParseResult(result);
    } catch {
      setParseResult(null);
      setError('Unable to read the selected CSV file.');
    }
  };

  const canImport =
    Boolean(parseResult) &&
    !parseResult!.headerError &&
    parseResult!.validCount > 0 &&
    parseResult!.invalidCount === 0 &&
    !importing;

  const handleImport = async () => {
    if (!canImport || !parseResult || !user) return;
    setError(null);
    setImporting(true);
    try {
      const validRows = parseResult.rows
        .filter((r): r is typeof r & { productId: string } => r.valid && Boolean(r.productId))
        .map((r) => ({
          rowNumber: r.rowNumber,
          productId: r.productId,
          batchNumber: r.batchNumber,
          initialQuantity: r.initialQuantity,
          remainingQuantity: r.remainingQuantity,
          purchaseDate: r.purchaseDate,
          expiryDate: r.expiryDate,
          notes: r.notes,
        }));
      const importedCount = await bulkImportSupermarketBatches(user.uid, validRows);
      await onImported(importedCount);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to import CSV batches.');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="ea-glass w-full max-w-3xl rounded-3xl p-6 space-y-4 max-h-[90vh] flex flex-col">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-bold">CSV Import — Bulk Add Batches</h3>
            <p className="text-xs text-[var(--text-secondary)] mt-0.5">
              Upload a CSV file matching existing supermarket products. Each row creates a separate
              batch record.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close CSV import modal"
            className="rounded-lg p-1.5 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer shrink-0"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {products.length === 0 ? (
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-800 dark:text-amber-300">
            You do not have any supermarket products yet. Add at least one product before importing
            batches via CSV, because every batch must match an existing product.
          </div>
        ) : (
          <>
            <div className="ea-surface rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1 text-xs">
                <p className="font-semibold flex items-center gap-1.5">
                  <FileSpreadsheet className="h-4 w-4" />
                  <span>Required CSV Columns</span>
                </p>
                <p className="text-[var(--text-secondary)]">
                  <span className="font-mono">Product Name</span> (or{' '}
                  <span className="font-mono">Product ID</span>),{' '}
                  <span className="font-mono">Batch Number</span>,{' '}
                  <span className="font-mono">Initial Quantity</span>,{' '}
                  <span className="font-mono">Purchase Date</span>,{' '}
                  <span className="font-mono">Expiry Date</span>{' '}
                  <span className="text-[var(--text-muted)]">
                    (YYYY-MM-DD; optional: Remaining Quantity, Notes)
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => downloadSupermarketBatchTemplateCsv(products)}
                className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold whitespace-nowrap cursor-pointer shrink-0"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Template</span>
              </button>
            </div>

            <div>
              <label
                htmlFor="csv-batch-upload"
                className="ea-surface flex flex-col items-center justify-center rounded-2xl border border-dashed border-[var(--border-strong)] px-4 py-5 text-center cursor-pointer hover:opacity-90"
              >
                <Upload className="h-5 w-5 mb-1.5 text-[var(--text-secondary)]" />
                <span className="text-sm font-semibold">
                  {fileName ? `Selected: ${fileName}` : 'Choose a .csv file to validate & preview'}
                </span>
                <span className="text-xs text-[var(--text-muted)] mt-0.5">
                  Supports files exported from Download CSV or the import template (max 200 rows per upload)
                </span>
                <input
                  id="csv-batch-upload"
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleFileSelected}
                  className="sr-only"
                />
              </label>
            </div>
          </>
        )}

        {parseResult?.headerError && (
          <div className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs text-red-700 dark:text-red-400 flex items-start gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{parseResult.headerError}</span>
          </div>
        )}

        {parseResult && !parseResult.headerError && (
          <div className="flex-1 min-h-0 flex flex-col space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{parseResult.validCount} valid row(s)</span>
                </span>
                {parseResult.invalidCount > 0 && (
                  <span className="inline-flex items-center gap-1.5 font-semibold text-red-700 dark:text-red-400">
                    <AlertCircle className="h-4 w-4" />
                    <span>{parseResult.invalidCount} row(s) with validation errors</span>
                  </span>
                )}
              </div>
              {parseResult.invalidCount > 0 && (
                <span className="text-[var(--text-secondary)]">
                  Fix validation errors in your CSV and re-upload to import.
                </span>
              )}
            </div>

            <div className="overflow-auto rounded-2xl border border-[var(--border-subtle)] flex-1">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="sticky top-0 bg-[var(--surface-elevated)] border-b border-[var(--border-subtle)] text-[var(--text-secondary)]">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Row</th>
                    <th className="py-2.5 px-3 font-semibold">Product</th>
                    <th className="py-2.5 px-3 font-semibold">Batch #</th>
                    <th className="py-2.5 px-3 font-semibold">Qty</th>
                    <th className="py-2.5 px-3 font-semibold">Purchase</th>
                    <th className="py-2.5 px-3 font-semibold">Expiry</th>
                    <th className="py-2.5 px-3 font-semibold">Validation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border-subtle)]">
                  {parseResult.rows.map((row) => (
                    <tr
                      key={row.rowNumber}
                      className={row.valid ? '' : 'bg-red-500/[0.06]'}
                    >
                      <td className="py-2 px-3 font-mono">{row.rowNumber}</td>
                      <td className="py-2 px-3 font-medium">{row.productName}</td>
                      <td className="py-2 px-3 font-mono">{row.batchNumber || '—'}</td>
                      <td className="py-2 px-3 font-mono tabular-nums">
                        {row.remainingQuantity}/{row.initialQuantity}
                      </td>
                      <td className="py-2 px-3 font-mono">{row.purchaseDate || '—'}</td>
                      <td className="py-2 px-3 font-mono">{row.expiryDate || '—'}</td>
                      <td className="py-2 px-3">
                        {row.valid ? (
                          <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                            <Check className="h-3.5 w-3.5" />
                            <span>Valid</span>
                          </span>
                        ) : (
                          <span className="text-red-700 dark:text-red-400 font-medium">
                            {row.errors.join(' ')}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="ea-surface rounded-xl px-4 py-2.5 text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!canImport}
            onClick={handleImport}
            className="ea-btn-accent rounded-xl px-5 py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-50"
          >
            {importing
              ? 'Importing...'
              : parseResult && parseResult.validCount > 0 && parseResult.invalidCount === 0
              ? `Import ${parseResult.validCount} Batch${parseResult.validCount === 1 ? '' : 'es'}`
              : 'Import Batches'}
          </button>
        </div>
      </div>
    </div>
  );
};

// ---------------- SUPERMARKET PRODUCT DETAILS ----------------

export const SupermarketProductDetailsPage: React.FC<{
  productId: string;
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ productId, data, navigate }) => {
  const { user } = useAuthTheme();
  const product = data.products.find((p) => p.id === productId);
  const [showAddBatch, setShowAddBatch] = useState(false);
  const [batchModal, setBatchModal] = useState<{
    batch: SupermarketBatch;
    actionType: 'sold' | 'wasted' | 'restocked';
    qty: string;
    note: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const [batchErr, setBatchErr] = useState<string | null>(null);

  useEffect(() => {
    if (!batchModal) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setBatchErr(null);
        setBatchModal(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [batchModal]);

  if (!product) {
    return (
      <div className="ea-glass rounded-2xl p-8 text-center space-y-3">
        <p className="font-semibold">Product not found</p>
        <button
          type="button"
          onClick={() => navigate({ name: 'supermarket-products' })}
          className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
        >
          Back to My Products
        </button>
      </div>
    );
  }

  const summary = getProductSummary(product, user?.defaultReminderDays ?? 5);
  const sortedBatches = [...product.batches].sort((a, b) =>
    a.expiryDate.localeCompare(b.expiryDate)
  );
  const productActions = data.actions.filter((a) => a.productId === product.id);

  const handleBatchAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchModal || !user) return;
    setBatchErr(null);
    setBusy(true);
    try {
      await logBatchAction(
        user.uid,
        batchModal.batch.id,
        batchModal.actionType,
        Number(batchModal.qty),
        batchModal.note
      );
      await data.reload();
      setBatchModal(null);
    } catch (err) {
      setBatchErr(err instanceof Error ? err.message : 'Unable to update batch stock.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <button
        type="button"
        onClick={() => navigate({ name: 'supermarket-products' })}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        <span>Back to My Products</span>
      </button>

      <div className="ea-glass rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <ProductAvatar
              imageUrl={product.imageUrl}
              name={product.name}
              category={product.categoryName}
              sizeClass="h-20 w-20"
            />
            <div>
              <p className="text-xs text-[var(--text-secondary)]">
                {product.categoryName}
                {product.isDemo ? ' · Sample data' : ''}
              </p>
              <h1 className="font-display text-2xl font-bold mt-0.5">{product.name}</h1>
              <div className="flex items-center gap-3 mt-1.5">
                <StatusText status={summary.status} />
                {summary.isLowStock && (
                  <span className="text-xs font-semibold text-amber-700 dark:text-amber-400">
                    Low stock alert
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => navigate({ name: 'supermarket-edit', id: product.id })}
              className="ea-surface rounded-xl px-3.5 py-2 text-xs font-semibold cursor-pointer"
            >
              Edit Product
            </button>
            <button
              type="button"
              onClick={() => setShowAddBatch(true)}
              className="ea-btn-accent inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Add Separate Batch</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3 border-t border-[var(--border-subtle)]">
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Total Remaining Stock</p>
            <p className="font-mono text-xl font-bold mt-0.5 tabular-nums">
              {summary.totalRemaining} {product.unit}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Available (Non-expired)</p>
            <p className="font-mono text-xl font-bold mt-0.5 tabular-nums">
              {summary.availableNonExpired} {product.unit}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Low-Stock Threshold</p>
            <p className="font-mono text-base font-semibold mt-1 tabular-nums">
              {product.lowStockThreshold} {product.unit}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-secondary)]">Active Batches</p>
            <p className="font-mono text-base font-semibold mt-1 tabular-nums">
              {summary.activeBatches.length}
            </p>
          </div>
        </div>
      </div>

      {/* Individual Batches Prioritised by Earliest Expiry Date */}
      <div className="ea-glass rounded-2xl p-6 space-y-4">
        <div>
          <h2 className="text-base font-semibold">Batch Records (Earliest Expiry First)</h2>
          <p className="text-xs text-[var(--text-secondary)]">
            Separate batch records preserve exact expiry dates without merging.
          </p>
        </div>

        <div className="divide-y divide-[var(--border-subtle)]">
          {sortedBatches.map((batch) => {
            const { status, daysRemaining } = computeExpiryStatus(
              batch.expiryDate,
              summary.threshold
            );
            return (
              <div
                key={batch.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-mono text-sm font-bold">{batch.batchNumber}</span>
                    <StatusText status={status} />
                    <span className="font-mono text-xs text-[var(--text-muted)]">
                      {formatDaysRemaining(daysRemaining)}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)]">
                    Remaining:{' '}
                    <strong className="font-mono text-[var(--text-primary)]">
                      {batch.remainingQuantity} / {batch.initialQuantity} {product.unit}
                    </strong>{' '}
                    · Purchased {formatShortDate(batch.purchaseDate)} · Expires{' '}
                    {formatShortDate(batch.expiryDate)}
                  </p>
                  {batch.notes && (
                    <p className="text-xs text-[var(--text-muted)]">{batch.notes}</p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  {batch.remainingQuantity > 0 && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          setBatchErr(null);
                          setBatchModal({
                            batch,
                            actionType: 'sold',
                            qty: '1',
                            note: '',
                          });
                        }}
                        className="ea-surface rounded-xl px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 cursor-pointer"
                      >
                        Sold
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setBatchErr(null);
                          setBatchModal({
                            batch,
                            actionType: 'wasted',
                            qty: String(batch.remainingQuantity),
                            note: '',
                          });
                        }}
                        className="ea-surface rounded-xl px-3 py-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400 cursor-pointer"
                      >
                        Wasted
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setBatchErr(null);
                      setBatchModal({
                        batch,
                        actionType: 'restocked',
                        qty: '10',
                        note: '',
                      });
                    }}
                    className="ea-surface rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
                  >
                    + Adjust Stock
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Product Activity */}
      <div className="ea-glass rounded-2xl p-6">
        <h2 className="text-base font-semibold mb-3">Batch & Inventory History</h2>
        {productActions.length === 0 ? (
          <p className="text-sm text-[var(--text-secondary)]">No recorded activity yet.</p>
        ) : (
          <div className="divide-y divide-[var(--border-subtle)] text-sm">
            {productActions.map((act) => (
              <div key={act.id} className="py-2.5 flex items-center justify-between gap-4">
                <div>
                  <span className="font-semibold uppercase text-xs">{act.actionType}</span>
                  <span className="text-xs text-[var(--text-secondary)] ml-2">
                    {act.productName} · {act.note}
                  </span>
                </div>
                {act.quantityDelta > 0 && (
                  <span className="font-mono text-xs tabular-nums">
                    {act.quantityDelta} {act.unit}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showAddBatch && (
        <AddBatchModal
          products={data.products}
          defaultProductId={product.id}
          onClose={() => setShowAddBatch(false)}
          onSaved={data.reload}
        />
      )}

      {batchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <form
            onSubmit={handleBatchAction}
            className="ea-glass w-full max-w-sm rounded-2xl p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-bold capitalize">
              Batch {batchModal.batch.batchNumber} · {batchModal.actionType}
            </h3>
            <p className="text-xs text-[var(--text-secondary)]">
              Current remaining: {batchModal.batch.remainingQuantity} {product.unit}
            </p>
            <div>
              <label className="block text-xs font-medium mb-1">
                Quantity ({product.unit})
              </label>
              <input
                type="number"
                step="any"
                min="0.01"
                max={
                  batchModal.actionType === 'restocked'
                    ? undefined
                    : batchModal.batch.remainingQuantity
                }
                required
                value={batchModal.qty}
                onChange={(e) => setBatchModal({ ...batchModal, qty: e.target.value })}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Note</label>
              <input
                type="text"
                value={batchModal.note}
                onChange={(e) => setBatchModal({ ...batchModal, note: e.target.value })}
                placeholder="Reason or shelf update..."
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
            {batchErr && (
              <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs text-red-700 dark:text-red-400">
                {batchErr}
              </p>
            )}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setBatchModal(null)}
                className="ea-surface flex-1 rounded-xl py-2.5 text-sm font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="ea-btn-accent flex-1 rounded-xl py-2.5 text-sm font-semibold cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// ---------------- SUPERMARKET BATCH MANAGEMENT ----------------

export const SupermarketBatchManagementPage: React.FC<{
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | ExpiryStatus>('All');
  const [showAddBatch, setShowAddBatch] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [importMessage, setImportMessage] = useState<string | null>(null);
  const [batchModal, setBatchModal] = useState<{
    batch: SupermarketBatch;
    actionType: 'sold' | 'wasted' | 'restocked';
    qty: string;
    note: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const [batchErr, setBatchErr] = useState<string | null>(null);

  useEffect(() => {
    if (!batchModal) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setBatchErr(null);
        setBatchModal(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [batchModal]);

  const enrichedBatches = useMemo(() => {
    return [...data.batches]
      .map((b) => {
        const prod = data.products.find((p) => p.id === b.productId);
        const threshold = prod?.reminderDays ?? defaultDays;
        const calc = computeExpiryStatus(b.expiryDate, threshold);
        return { ...b, ...calc };
      })
      .filter((b) => {
        if (statusFilter !== 'All' && b.status !== statusFilter) return false;
        if (search.trim()) {
          const q = search.trim().toLowerCase();
          return (
            b.batchNumber.toLowerCase().includes(q) ||
            (b.productName || '').toLowerCase().includes(q) ||
            (b.categoryName || '').toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
  }, [data.batches, data.products, defaultDays, search, statusFilter]);

  const handleBatchAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchModal || !user) return;
    setBatchErr(null);
    setBusy(true);
    try {
      await logBatchAction(
        user.uid,
        batchModal.batch.id,
        batchModal.actionType,
        Number(batchModal.qty),
        batchModal.note
      );
      await data.reload();
      setBatchModal(null);
    } catch (err) {
      setBatchErr(err instanceof Error ? err.message : 'Unable to update batch stock.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Supermarket Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Batch Management
          </h1>
          <p className="text-xs text-[var(--text-secondary)] mt-1">
            Prioritised by earliest expiry date. Separate expiry dates are never merged.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setShowCsvImport(true)}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer"
          >
            <Upload className="h-4 w-4" />
            <span>CSV Import</span>
          </button>
          <button
            type="button"
            disabled={enrichedBatches.length === 0}
            onClick={() => exportSupermarketBatchesCsv(enrichedBatches)}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-medium whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            <span>Download CSV</span>
          </button>
          {data.products.length > 0 && (
            <button
              type="button"
              onClick={() => setShowAddBatch(true)}
              className="ea-btn-accent inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap cursor-pointer"
            >
              <Boxes className="h-4 w-4" />
              <span>Add Batch</span>
            </button>
          )}
        </div>
      </div>

      {importMessage && (
        <div className="ea-glass rounded-2xl px-4 py-3 flex items-center justify-between gap-3 border border-emerald-500/30">
          <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{importMessage}</span>
          </p>
          <button
            type="button"
            onClick={() => setImportMessage(null)}
            aria-label="Dismiss import message"
            className="rounded-lg p-1 hover:bg-black/5 dark:hover:bg-white/10 cursor-pointer"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="ea-glass rounded-2xl p-4 space-y-3">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3.5 top-3 text-[var(--text-muted)]" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by product name or batch number..."
            className="ea-input w-full rounded-xl pl-10 pr-3.5 py-2 text-sm"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(['All', 'Fresh', 'Good', 'Near Expiry', 'Expired'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-medium cursor-pointer ${
                statusFilter === status
                  ? 'ea-btn-accent'
                  : 'ea-surface text-[var(--text-secondary)]'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {enrichedBatches.length === 0 ? (
        <div className="ea-glass rounded-2xl p-10 text-center space-y-3">
          <p className="font-semibold">No batch records match your filter</p>
          <p className="text-xs text-[var(--text-secondary)]">
            Add a product or new batch to begin tracking separate batch expiry dates.
          </p>
          {(search.trim() !== '' || statusFilter !== 'All') && (
            <button
              type="button"
              onClick={() => {
                setSearch('');
                setStatusFilter('All');
              }}
              className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {enrichedBatches.map((batch) => (
            <div
              key={batch.id}
              className="ea-glass rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                  <button
                    type="button"
                    onClick={() => navigate({ name: 'supermarket-details', id: batch.productId })}
                    className="font-semibold text-sm hover:underline cursor-pointer"
                  >
                    {batch.productName}
                  </button>
                  <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
                  <span className="font-mono text-xs font-semibold text-[var(--text-secondary)]">
                    Batch {batch.batchNumber}
                  </span>
                  <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
                  <StatusText status={batch.status} />
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[var(--text-secondary)]">
                  <span>
                    Remaining:{' '}
                    <strong className="font-mono tabular-nums text-[var(--text-primary)]">
                      {batch.remainingQuantity} / {batch.initialQuantity} {batch.productUnit}
                    </strong>
                  </span>
                  <span>Purchased: {formatShortDate(batch.purchaseDate)}</span>
                  <span>
                    Expires: <strong className="text-[var(--text-primary)]">{formatShortDate(batch.expiryDate)}</strong> (
                    {formatDaysRemaining(batch.daysRemaining)})
                  </span>
                </div>
                {batch.notes && (
                  <p className="text-xs text-[var(--text-muted)]">{batch.notes}</p>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {batch.remainingQuantity > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setBatchErr(null);
                        setBatchModal({ batch, actionType: 'sold', qty: '1', note: '' });
                      }}
                      className="ea-surface rounded-xl px-3 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 cursor-pointer"
                    >
                      Sold
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setBatchErr(null);
                        setBatchModal({
                          batch,
                          actionType: 'wasted',
                          qty: String(batch.remainingQuantity),
                          note: '',
                        });
                      }}
                      className="ea-surface rounded-xl px-3 py-2 text-xs font-semibold text-amber-700 dark:text-amber-400 cursor-pointer"
                    >
                      Wasted
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setBatchErr(null);
                    setBatchModal({ batch, actionType: 'restocked', qty: '10', note: '' });
                  }}
                  className="ea-surface rounded-xl px-3 py-2 text-xs font-medium cursor-pointer"
                >
                  Update Stock
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showAddBatch && (
        <AddBatchModal
          products={data.products}
          onClose={() => setShowAddBatch(false)}
          onSaved={data.reload}
        />
      )}

      {showCsvImport && (
        <CsvBatchImportModal
          products={data.products}
          onClose={() => setShowCsvImport(false)}
          onImported={async (count) => {
            await data.reload();
            setImportMessage(`Successfully imported ${count} batch record${count === 1 ? '' : 's'} from CSV.`);
          }}
        />
      )}

      {batchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
          <form
            onSubmit={handleBatchAction}
            className="ea-glass w-full max-w-sm rounded-2xl p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-bold">
              Batch {batchModal.batch.batchNumber} · {batchModal.actionType}
            </h3>
            <p className="text-xs text-[var(--text-secondary)]">
              {batchModal.batch.productName} ({batchModal.batch.remainingQuantity}{' '}
              {batchModal.batch.productUnit} remaining)
            </p>
            <div>
              <label className="block text-xs font-medium mb-1">
                Quantity ({batchModal.batch.productUnit})
              </label>
              <input
                type="number"
                step="any"
                min="0.01"
                max={
                  batchModal.actionType === 'restocked'
                    ? undefined
                    : batchModal.batch.remainingQuantity
                }
                required
                value={batchModal.qty}
                onChange={(e) => setBatchModal({ ...batchModal, qty: e.target.value })}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Note</label>
              <input
                type="text"
                value={batchModal.note}
                onChange={(e) => setBatchModal({ ...batchModal, note: e.target.value })}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
            {batchErr && (
              <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3 py-2 text-xs text-red-700 dark:text-red-400">
                {batchErr}
              </p>
            )}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setBatchModal(null)}
                className="ea-surface flex-1 rounded-xl py-2.5 text-sm font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="ea-btn-accent flex-1 rounded-xl py-2.5 text-sm font-semibold cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// ---------------- SUPERMARKET REMINDERS ----------------

export const SupermarketRemindersPage: React.FC<{
  data: SupermarketDataBundle;
  navigate: (route: AppRoute) => void;
}> = ({ data, navigate }) => {
  const { user, setUser } = useAuthTheme();
  const defaultDays = user?.defaultReminderDays ?? 5;
  const [tab, setTab] = useState<'expiry' | 'low_stock' | 'snoozed' | 'resolved'>('expiry');
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [reminderErr, setReminderErr] = useState<string | null>(null);

  const today = getTodayIso();

  const stateMap = useMemo(() => {
    const map = new Map<string, ReminderStateRecord>();
    for (const st of data.reminderStates) {
      map.set(`${st.targetType}:${st.targetId}`, st);
    }
    return map;
  }, [data.reminderStates]);

  const batchAlerts = useMemo(() => {
    return data.batches
      .filter((b) => b.remainingQuantity > 0)
      .map((b) => {
        const prod = data.products.find((p) => p.id === b.productId);
        const threshold = prod?.reminderDays ?? defaultDays;
        const { status, daysRemaining } = computeExpiryStatus(b.expiryDate, threshold);
        const st = stateMap.get(`supermarket_batch:${b.id}`);
        const isSnoozed =
          st?.status === 'snoozed' && st.snoozedUntil && st.snoozedUntil >= today;
        const isResolved = st?.status === 'resolved';
        return {
          batch: b,
          status,
          daysRemaining,
          threshold,
          isSnoozed,
          isResolved,
        };
      })
      .filter((x) => x.daysRemaining <= x.threshold)
      .sort((a, b) => a.daysRemaining - b.daysRemaining);
  }, [data.batches, data.products, defaultDays, stateMap, today]);

  const lowStockAlerts = useMemo(() => {
    return data.products
      .map((p) => {
        const summary = getProductSummary(p, defaultDays);
        const st = stateMap.get(`low_stock:${p.id}`);
        const isSnoozed =
          st?.status === 'snoozed' && st.snoozedUntil && st.snoozedUntil >= today;
        const isResolved = st?.status === 'resolved';
        return { product: p, summary, isSnoozed, isResolved };
      })
      .filter((x) => x.summary.isLowStock);
  }, [data.products, defaultDays, stateMap, today]);

  const activeBatchAlerts = batchAlerts.filter((x) => !x.isSnoozed && !x.isResolved);
  const activeLowStock = lowStockAlerts.filter((x) => !x.isSnoozed && !x.isResolved);
  const snoozedAll = [
    ...batchAlerts.filter((x) => x.isSnoozed).map((x) => ({ kind: 'batch' as const, item: x })),
    ...lowStockAlerts
      .filter((x) => x.isSnoozed)
      .map((x) => ({ kind: 'low_stock' as const, item: x })),
  ];
  const resolvedAll = [
    ...batchAlerts.filter((x) => x.isResolved).map((x) => ({ kind: 'batch' as const, item: x })),
    ...lowStockAlerts
      .filter((x) => x.isResolved)
      .map((x) => ({ kind: 'low_stock' as const, item: x })),
  ];

  const updateDefaultDays = async (days: number) => {
    if (!user) return;
    setReminderErr(null);
    try {
      const updated = await updateUserProfile(user.uid, { defaultReminderDays: days });
      setUser(updated);
    } catch (err) {
      setReminderErr(err instanceof Error ? err.message : 'Unable to update default expiry window.');
    }
  };

  const setReminderState = async (
    targetType: 'supermarket_batch' | 'low_stock',
    targetId: string,
    status: 'active' | 'snoozed' | 'resolved'
  ) => {
    if (!user) return;
    const key = `${targetType}:${targetId}`;
    setReminderErr(null);
    setBusyKey(key);
    try {
      await saveReminderState(user.uid, {
        mode: 'supermarket',
        targetType,
        targetId,
        status,
        snoozeDays: 2,
      });
      await data.reload();
    } catch (err) {
      setReminderErr(err instanceof Error ? err.message : 'Unable to update reminder state.');
    } finally {
      setBusyKey(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Supermarket Mode</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Inventory Reminders
          </h1>
        </div>

        <div className="ea-glass rounded-2xl px-4 py-2.5 flex items-center gap-3">
          <span className="text-xs font-medium text-[var(--text-secondary)]">
            Default expiry window:
          </span>
          <select
            aria-label="Default supermarket reminder interval"
            value={defaultDays}
            onChange={(e) => updateDefaultDays(Number(e.target.value))}
            className="ea-input rounded-lg px-2.5 py-1 text-xs font-medium"
          >
            {REMINDER_DAY_OPTIONS.map((d) => (
              <option key={d} value={d}>
                {d === 0 ? 'On expiry date' : `${d} days before`}
              </option>
            ))}
          </select>
        </div>
      </div>

      <LockscreenPermissionBanner navigate={navigate} />

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTab('expiry')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'expiry' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Batch Expiry Alerts ({activeBatchAlerts.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('low_stock')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'low_stock' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Low-Stock Alerts ({activeLowStock.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('snoozed')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'snoozed' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Snoozed ({snoozedAll.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('resolved')}
          className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
            tab === 'resolved' ? 'ea-btn-accent' : 'ea-surface text-[var(--text-secondary)]'
          }`}
        >
          Resolved ({resolvedAll.length})
        </button>
      </div>

      {reminderErr && (
        <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-4 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
          {reminderErr}
        </p>
      )}

      {tab === 'expiry' && (
        <div className="space-y-3">
          {activeBatchAlerts.length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)]">
              No approaching or expired batch alerts right now.
            </div>
          ) : (
            activeBatchAlerts.map((entry) => (
              <div
                key={entry.batch.id}
                className="ea-glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() =>
                        navigate({ name: 'supermarket-details', id: entry.batch.productId })
                      }
                      className="font-semibold text-sm hover:underline cursor-pointer"
                    >
                      {entry.batch.productName}
                    </button>
                    <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-[var(--surface-subtle)]">
                      Batch {entry.batch.batchNumber}
                    </span>
                    <StatusText status={entry.status} />
                  </div>
                  <p className="text-xs text-[var(--text-secondary)]">
                    {entry.batch.remainingQuantity} {entry.batch.productUnit} · Expires{' '}
                    {formatShortDate(entry.batch.expiryDate)} (
                    {formatDaysRemaining(entry.daysRemaining)})
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    disabled={busyKey === `supermarket_batch:${entry.batch.id}`}
                    onClick={() =>
                      setReminderState('supermarket_batch', entry.batch.id, 'snoozed')
                    }
                    className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
                  >
                    <AlarmClock className="h-3.5 w-3.5" />
                    <span>Snooze 2d</span>
                  </button>
                  <button
                    type="button"
                    disabled={busyKey === `supermarket_batch:${entry.batch.id}`}
                    onClick={() =>
                      setReminderState('supermarket_batch', entry.batch.id, 'resolved')
                    }
                    className="ea-btn-accent inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold cursor-pointer"
                  >
                    <Check className="h-3.5 w-3.5" />
                    <span>Resolve</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'low_stock' && (
        <div className="space-y-3">
          {activeLowStock.length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)]">
              All products are above their low-stock thresholds.
            </div>
          ) : (
            activeLowStock.map((entry) => (
              <div
                key={entry.product.id}
                className="ea-glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <button
                    type="button"
                    onClick={() =>
                      navigate({ name: 'supermarket-details', id: entry.product.id })
                    }
                    className="font-semibold text-sm hover:underline cursor-pointer"
                  >
                    {entry.product.name}
                  </button>
                  <p className="text-xs text-[var(--text-secondary)]">
                    Available stock:{' '}
                    <strong className="font-mono text-amber-700 dark:text-amber-400">
                      {entry.summary.availableNonExpired} {entry.product.unit}
                    </strong>{' '}
                    (Threshold: {entry.product.lowStockThreshold} {entry.product.unit})
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    disabled={busyKey === `low_stock:${entry.product.id}`}
                    onClick={() => setReminderState('low_stock', entry.product.id, 'snoozed')}
                    className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
                  >
                    <AlarmClock className="h-3.5 w-3.5" />
                    <span>Snooze 2d</span>
                  </button>
                  <button
                    type="button"
                    disabled={busyKey === `low_stock:${entry.product.id}`}
                    onClick={() => setReminderState('low_stock', entry.product.id, 'resolved')}
                    className="ea-btn-accent inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold cursor-pointer"
                  >
                    <Check className="h-3.5 w-3.5" />
                    <span>Resolve</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {(tab === 'snoozed' || tab === 'resolved') && (
        <div className="space-y-3">
          {(tab === 'snoozed' ? snoozedAll : resolvedAll).length === 0 ? (
            <div className="ea-glass rounded-2xl p-8 text-center text-sm text-[var(--text-secondary)]">
              No {tab} reminders.
            </div>
          ) : (
            (tab === 'snoozed' ? snoozedAll : resolvedAll).map((entry) =>
              entry.kind === 'batch' ? (
                <div
                  key={`b-${entry.item.batch.id}`}
                  className="ea-glass rounded-2xl p-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <p className="font-semibold text-sm">
                      {entry.item.batch.productName} (Batch {entry.item.batch.batchNumber})
                    </p>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Expires {formatShortDate(entry.item.batch.expiryDate)}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setReminderState('supermarket_batch', entry.item.batch.id, 'active')
                    }
                    className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Restore</span>
                  </button>
                </div>
              ) : (
                <div
                  key={`l-${entry.item.product.id}`}
                  className="ea-glass rounded-2xl p-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <p className="font-semibold text-sm">
                      Low stock: {entry.item.product.name}
                    </p>
                    <p className="text-xs text-[var(--text-secondary)]">
                      Available: {entry.item.summary.availableNonExpired}{' '}
                      {entry.item.product.unit}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setReminderState('low_stock', entry.item.product.id, 'active')
                    }
                    className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Restore</span>
                  </button>
                </div>
              )
            )
          )}
        </div>
      )}
    </div>
  );
};
