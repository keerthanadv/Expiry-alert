import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { ArrowLeft, CheckCircle2, Mail, Moon, RefreshCw, Sun } from 'lucide-react';
import type { AppRoute } from '../components/AppShell.tsx';
import { BrandLogoIcon } from '../components/BrandMark.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import { auth, googleProvider } from '../firebase/config.ts';
import type { AccountType, OperatingMode } from '../types/index.ts';

function friendlyAuthError(err: unknown, fallback: string): string {
  const code = (err as { code?: string })?.code ?? '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Invalid email address or password.';
    case 'auth/email-already-in-use':
      return 'An account with this email address already exists.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters long.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment before trying again.';
    case 'auth/popup-closed-by-user':
      return 'Google sign-in popup was closed before finishing.';
    case 'auth/operation-not-allowed':
      return 'Email/Password sign-in is not yet enabled in Firebase Console (Authentication -> Sign-in method -> Email/Password). Use Google Sign-In below or enable Email/Password in Firebase Console.';
    default:
      return err instanceof Error ? err.message : fallback;
  }
}

interface AuthShellProps {
  title: string;
  subtitle: string;
  navigate: (route: AppRoute) => void;
  children: React.ReactNode;
}

const AuthLayout: React.FC<AuthShellProps> = ({ title, subtitle, navigate, children }) => {
  const { theme, updateAppearance } = useAuthTheme();

  return (
    <div className="min-h-screen flex flex-col justify-center px-4 py-10">
      <div className="max-w-md w-full mx-auto space-y-5">
        <div className="flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => navigate({ name: 'landing' })}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to home</span>
          </button>

          <button
            type="button"
            onClick={() => updateAppearance({ theme: theme === 'light' ? 'dark' : 'light' })}
            className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
          >
            {theme === 'light' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
            <span>{theme === 'light' ? 'Dark' : 'Light'}</span>
          </button>
        </div>

        <div className="ea-glass rounded-3xl p-7 sm:p-8 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <BrandLogoIcon className="h-8 w-8" />
              <span className="font-display text-lg font-bold">ExpiryAlert</span>
            </div>
            <h1 className="font-display text-2xl font-bold pt-1">{title}</h1>
            <p className="text-sm text-[var(--text-secondary)]">{subtitle}</p>
          </div>
          {children}
        </div>
      </div>
    </div>
  );
};

export const EmailVerificationGatePage: React.FC<{
  initialMode?: OperatingMode;
  navigate: (route: AppRoute) => void;
}> = ({ initialMode, navigate }) => {
  const { firebaseUser, refreshVerificationStatus, resendVerificationEmail, logout } =
    useAuthTheme();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const handleCheckVerified = async () => {
    setErr(null);
    setMsg(null);
    setBusy(true);
    try {
      const ok = await refreshVerificationStatus();
      if (ok) {
        navigate({
          name: initialMode === 'supermarket' ? 'supermarket-dashboard' : 'household-dashboard',
        });
      } else {
        setErr('Your email is not verified yet. Open the verification link in your inbox, then tap check again.');
      }
    } catch (e) {
      setErr(friendlyAuthError(e, 'Unable to verify status.'));
    } finally {
      setBusy(false);
    }
  };

  const handleResend = async () => {
    setErr(null);
    setMsg(null);
    setBusy(true);
    try {
      await resendVerificationEmail();
      setMsg('Verification email sent. Please check your inbox and spam folder.');
    } catch (e) {
      setErr(friendlyAuthError(e, 'Unable to resend verification email right now.'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title="Verify your email address"
      subtitle="Email verification protects multi-user cloud workspaces before data access is unlocked."
      navigate={navigate}
    >
      <div className="ea-surface rounded-2xl p-4 space-y-2 text-sm">
        <div className="flex items-center gap-2 font-semibold">
          <Mail className="h-4 w-4 shrink-0" style={{ color: 'var(--accent-text)' }} />
          <span className="truncate">{firebaseUser?.email ?? 'Your registered email'}</span>
        </div>
        <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
          We sent a verification link to your inbox. Click the link in that email, then return here and press <strong>I&apos;ve Verified My Email</strong>.
        </p>
      </div>

      {err && (
        <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
          {err}
        </p>
      )}
      {msg && (
        <p className="rounded-xl bg-emerald-500/10 border border-emerald-500/25 px-3.5 py-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          {msg}
        </p>
      )}

      <div className="space-y-2.5">
        <button
          type="button"
          disabled={busy}
          onClick={handleCheckVerified}
          className="ea-btn-accent w-full rounded-xl py-2.5 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
        >
          <CheckCircle2 className="h-4 w-4" />
          <span>{busy ? 'Checking...' : "I've Verified My Email"}</span>
        </button>

        <button
          type="button"
          disabled={busy}
          onClick={handleResend}
          className="ea-surface w-full rounded-xl py-2.5 text-sm font-medium inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
        >
          <RefreshCw className="h-4 w-4" />
          <span>Resend Verification Email</span>
        </button>

        <button
          type="button"
          disabled={busy}
          onClick={async () => {
            await logout();
            navigate({ name: 'login', initialMode });
          }}
          className="w-full py-2 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
        >
          Use a different account
        </button>
      </div>
    </AuthLayout>
  );
};

export const LoginPage: React.FC<{
  initialMode?: OperatingMode;
  navigate: (route: AppRoute) => void;
}> = ({ initialMode, navigate }) => {
  const { setActiveMode, enterDemoSandbox, setPendingRegistrationMeta } = useAuthTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const navigateForMode = (mode: OperatingMode) => {
    setActiveMode(mode);
    navigate({
      name: mode === 'supermarket' ? 'supermarket-dashboard' : 'household-dashboard',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      if (!cred.user.emailVerified) {
        return; // App renders EmailVerificationGatePage automatically
      }
      navigateForMode(initialMode ?? 'household');
    } catch (err) {
      setError(friendlyAuthError(err, 'Unable to sign in.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setSubmitting(true);
    try {
      if (initialMode) {
        setPendingRegistrationMeta({
          fullName: '',
          accountType: 'both',
          preferredMode: initialMode,
        });
      }
      await signInWithPopup(auth, googleProvider);
      navigateForMode(initialMode ?? 'household');
    } catch (err) {
      setError(friendlyAuthError(err, 'Google sign-in failed.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoLogin = (mode: OperatingMode) => {
    enterDemoSandbox(mode);
    navigateForMode(mode);
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle={
        initialMode === 'supermarket'
          ? 'Sign in to access your Supermarket inventory workspace.'
          : initialMode === 'household'
          ? 'Sign in to access your Household pantry workspace.'
          : 'Sign in with Google or your verified email and password.'
      }
      navigate={navigate}
    >
      <div className="space-y-4">
        <button
          type="button"
          disabled={submitting}
          onClick={handleGoogleSignIn}
          className="ea-surface w-full rounded-xl py-2.5 px-4 text-sm font-semibold flex items-center justify-center gap-2.5 hover:border-[var(--border-strong)] cursor-pointer disabled:opacity-60"
        >
          <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        <div className="flex items-center gap-3 text-xs text-[var(--text-muted)]">
          <div className="h-px flex-1 bg-[var(--border-subtle)]" />
          <span>or with email</span>
          <div className="h-px flex-1 bg-[var(--border-subtle)]" />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="login-email" className="block text-sm font-medium mb-1.5">
            Email address
          </label>
          <input
            id="login-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="login-password" className="block text-sm font-medium">
              Password
            </label>
            <button
              type="button"
              onClick={() => navigate({ name: 'forgot-password' })}
              className="text-xs font-medium hover:underline cursor-pointer"
              style={{ color: 'var(--accent-text)' }}
            >
              Forgot password?
            </button>
          </div>
          <input
            id="login-password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          />
        </div>

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="ea-btn-accent w-full rounded-xl py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
        >
          {submitting ? 'Signing in...' : 'Sign In'}
        </button>
      </form>

      <div className="pt-4 border-t border-[var(--border-subtle)] space-y-3">
        <p className="text-xs text-[var(--text-secondary)] text-center">
          Quick demonstration sandbox (pre-populated sample data)
        </p>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            disabled={submitting}
            onClick={() => handleDemoLogin('household')}
            className="ea-surface rounded-xl py-2 px-3 text-xs font-medium hover:border-[var(--border-strong)] cursor-pointer"
          >
            Demo Household
          </button>
          <button
            type="button"
            disabled={submitting}
            onClick={() => handleDemoLogin('supermarket')}
            className="ea-surface rounded-xl py-2 px-3 text-xs font-medium hover:border-[var(--border-strong)] cursor-pointer"
          >
            Demo Supermarket
          </button>
        </div>
      </div>

      <p className="text-center text-sm text-[var(--text-secondary)]">
        New to ExpiryAlert?{' '}
        <button
          type="button"
          onClick={() => navigate({ name: 'register', initialMode })}
          className="font-semibold hover:underline cursor-pointer"
          style={{ color: 'var(--accent-text)' }}
        >
          Create an account
        </button>
      </p>
    </AuthLayout>
  );
};

export const RegisterPage: React.FC<{
  initialMode?: OperatingMode;
  navigate: (route: AppRoute) => void;
}> = ({ initialMode, navigate }) => {
  const { setActiveMode, setPendingRegistrationMeta } = useAuthTheme();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [accountType, setAccountType] = useState<AccountType>(initialMode ?? 'both');
  const [preferredMode, setPreferredMode] = useState<OperatingMode>(initialMode ?? 'household');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleGoogleSignUp = async () => {
    setError(null);
    setSubmitting(true);
    try {
      const resolvedPreferred = accountType === 'both' ? preferredMode : accountType;
      setPendingRegistrationMeta({
        fullName: fullName.trim(),
        accountType,
        preferredMode: resolvedPreferred,
      });
      await signInWithPopup(auth, googleProvider);
      setActiveMode(resolvedPreferred);
      navigate({
        name:
          resolvedPreferred === 'supermarket' ? 'supermarket-dashboard' : 'household-dashboard',
      });
    } catch (err) {
      setError(friendlyAuthError(err, 'Google registration failed.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (fullName.trim().length < 2) {
      setError('Please enter your full name (at least 2 characters).');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Password and confirm password do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const resolvedPreferred = accountType === 'both' ? preferredMode : accountType;
      setPendingRegistrationMeta({
        fullName: fullName.trim(),
        accountType,
        preferredMode: resolvedPreferred,
      });
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await updateProfile(cred.user, { displayName: fullName.trim() }).catch(() => undefined);
      await sendEmailVerification(cred.user);
      // AuthThemeContext onAuthStateChanged transitions to EmailVerificationGatePage automatically
    } catch (err) {
      setError(friendlyAuthError(err, 'Registration failed.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Register with email verification or Google to sync your pantry and batches securely."
      navigate={navigate}
    >
      <button
        type="button"
        disabled={submitting}
        onClick={handleGoogleSignUp}
        className="ea-surface w-full rounded-xl py-2.5 px-4 text-sm font-semibold flex items-center justify-center gap-2.5 hover:border-[var(--border-strong)] cursor-pointer disabled:opacity-60"
      >
        <span>Continue with Google (Instant Verified)</span>
      </button>

      <div className="flex items-center gap-3 text-xs text-[var(--text-muted)]">
        <div className="h-px flex-1 bg-[var(--border-subtle)]" />
        <span>or register with email verification</span>
        <div className="h-px flex-1 bg-[var(--border-subtle)]" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="reg-name" className="block text-sm font-medium mb-1.5">
            Full name
          </label>
          <input
            id="reg-name"
            type="text"
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="e.g. Keerthana V."
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          />
        </div>

        <div>
          <label htmlFor="reg-email" className="block text-sm font-medium mb-1.5">
            Email address
          </label>
          <input
            id="reg-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="reg-password" className="block text-sm font-medium mb-1.5">
              Password
            </label>
            <input
              id="reg-password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Min. 6 characters"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>
          <div>
            <label htmlFor="reg-confirm" className="block text-sm font-medium mb-1.5">
              Confirm password
            </label>
            <input
              id="reg-confirm"
              type="password"
              required
              minLength={6}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Repeat password"
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>
        </div>

        <div>
          <label htmlFor="reg-account-type" className="block text-sm font-medium mb-1.5">
            Account type
          </label>
          <select
            id="reg-account-type"
            value={accountType}
            onChange={(e) => setAccountType(e.target.value as AccountType)}
            className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
          >
            <option value="household">Household only</option>
            <option value="supermarket">Supermarket only</option>
            <option value="both">Both Household & Supermarket</option>
          </select>
        </div>

        {accountType === 'both' && (
          <div>
            <label htmlFor="reg-preferred" className="block text-sm font-medium mb-1.5">
              Preferred starting mode
            </label>
            <select
              id="reg-preferred"
              value={preferredMode}
              onChange={(e) => setPreferredMode(e.target.value as OperatingMode)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              <option value="household">Household Mode</option>
              <option value="supermarket">Supermarket Mode</option>
            </select>
          </div>
        )}

        {error && (
          <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="ea-btn-accent w-full rounded-xl py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
        >
          {submitting ? 'Creating account...' : 'Create Account & Send Verification Email'}
        </button>
      </form>

      <p className="text-center text-sm text-[var(--text-secondary)]">
        Already have an account?{' '}
        <button
          type="button"
          onClick={() => navigate({ name: 'login', initialMode })}
          className="font-semibold hover:underline cursor-pointer"
          style={{ color: 'var(--accent-text)' }}
        >
          Sign in
        </button>
      </p>
    </AuthLayout>
  );
};

export const ForgotPasswordPage: React.FC<{ navigate: (route: AppRoute) => void }> = ({
  navigate,
}) => {
  const [sent, setSent] = useState(false);
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleRequestResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setSent(true);
    } catch (err) {
      setError(friendlyAuthError(err, 'Unable to send password reset email.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthLayout
      title="Reset your password"
      subtitle="We will send a secure password reset link directly to your registered email inbox."
      navigate={navigate}
    >
      {!sent ? (
        <form onSubmit={handleRequestResetEmail} className="space-y-4">
          <div>
            <label htmlFor="fp-email" className="block text-sm font-medium mb-1.5">
              Registered email address
            </label>
            <div className="relative">
              <Mail className="h-4 w-4 absolute left-3.5 top-3 text-[var(--text-muted)]" />
              <input
                id="fp-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="ea-input w-full rounded-xl pl-10 pr-3.5 py-2.5 text-sm"
              />
            </div>
          </div>

          {error && (
            <p className="rounded-xl bg-red-500/10 border border-red-500/25 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:text-red-400">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="ea-btn-accent w-full rounded-xl py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
          >
            {submitting ? 'Sending reset link...' : 'Send Password Reset Email'}
          </button>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="ea-surface rounded-2xl p-4 space-y-2">
            <p className="text-sm font-semibold" style={{ color: 'var(--accent-text)' }}>
              Password reset email sent
            </p>
            <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
              Check <strong>{email}</strong> (and your spam/promotions folder) for the secure link to choose a new password, then return here to sign in.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate({ name: 'login' })}
            className="ea-btn-accent w-full rounded-xl py-2.5 text-sm font-semibold cursor-pointer"
          >
            Return to Login
          </button>
        </div>
      )}

      <p className="text-center text-sm text-[var(--text-secondary)]">
        Remembered your password?{' '}
        <button
          type="button"
          onClick={() => navigate({ name: 'login' })}
          className="font-semibold hover:underline cursor-pointer"
          style={{ color: 'var(--accent-text)' }}
        >
          Sign in
        </button>
      </p>
    </AuthLayout>
  );
};
