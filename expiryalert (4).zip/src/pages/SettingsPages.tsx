import React, { useEffect, useState } from 'react';
import {
  EmailAuthProvider,
  reauthenticateWithCredential,
  updatePassword,
} from 'firebase/auth';
import {
  Bell,
  BellRing,
  Check,
  CheckCheck,
  Clock,
  Database,
  Download,
  LogOut,
  Moon,
  Palette,
  RotateCcw,
  ShieldCheck,
  Sun,
  Trash2,
  User,
} from 'lucide-react';
import type { AppRoute } from '../components/AppShell.tsx';
import { ImageUploadField } from '../components/ImageUploadField.tsx';
import { PWAInstallButton } from '../components/PWAInstallButton.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import { auth } from '../firebase/config.ts';
import {
  clearNotifications,
  markAllNotificationsRead,
  resetDemoData,
  updateUserProfile,
} from '../services/dataService.ts';
import type {
  AccountType,
  FontSizePref,
  HouseholdProduct,
  NotificationHistoryItem,
  OperatingMode,
  SupermarketProduct,
} from '../types/index.ts';
import { ACCENT_PRESETS } from '../utils/colorContrast.ts';
import {
  exportHouseholdInventoryCsv,
  exportSupermarketInventoryCsv,
} from '../utils/csvExport.ts';
import {
  getNotificationPermission,
  registerFcmDeviceToken,
  requestLockscreenPermission,
  type FcmStatus,
  type NotificationPermissionState,
} from '../utils/notifications.ts';

export const SettingsPage: React.FC<{
  navigate: (route: AppRoute) => void;
  onDemoChanged: () => Promise<void>;
  householdProducts: HouseholdProduct[];
  supermarketProducts: SupermarketProduct[];
}> = ({ navigate, onDemoChanged, householdProducts, supermarketProducts }) => {
  const {
    user,
    setUser,
    theme,
    accentColor,
    fontSize,
    accentPalette,
    updateAppearance,
    resetAppearance,
    setActiveMode,
    logout,
  } = useAuthTheme();

  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [accountType, setAccountType] = useState<AccountType>(user?.accountType ?? 'both');
  const [preferredMode, setPreferredMode] = useState<OperatingMode>(
    user?.preferredMode ?? 'household'
  );
  const [profileImageUrl, setProfileImageUrl] = useState<string | null>(
    user?.profileImageUrl ?? null
  );
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [profileErr, setProfileErr] = useState<string | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwMsg, setPwMsg] = useState<string | null>(null);
  const [pwErr, setPwErr] = useState<string | null>(null);
  const [savingPw, setSavingPw] = useState(false);

  const [demoMsg, setDemoMsg] = useState<string | null>(null);
  const [demoErr, setDemoErr] = useState<string | null>(null);
  const [demoBusy, setDemoBusy] = useState(false);

  const isPasswordProvider = Boolean(
    auth.currentUser?.providerData.some((p) => p.providerId === 'password')
  );

  useEffect(() => {
    if (!user) return;
    setFullName(user.fullName);
    setEmail(user.email);
    setAccountType(user.accountType);
    setPreferredMode(user.preferredMode);
    setProfileImageUrl(user.profileImageUrl ?? null);
  }, [
    user?.uid,
    user?.fullName,
    user?.email,
    user?.accountType,
    user?.preferredMode,
    user?.profileImageUrl,
  ]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setProfileMsg(null);
    setProfileErr(null);
    setSavingProfile(true);
    try {
      const nextPreferred = accountType === 'both' ? preferredMode : accountType;
      const updated = await updateUserProfile(user.uid, {
        fullName,
        email,
        accountType,
        preferredMode: nextPreferred,
        profileImageUrl,
      });
      setUser(updated);
      setActiveMode(updated.preferredMode);
      setProfileMsg('Profile details saved.');
    } catch (err) {
      setProfileErr(err instanceof Error ? err.message : 'Unable to update profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwMsg(null);
    setPwErr(null);
    if (newPassword.length < 6) {
      setPwErr('New password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwErr('New password and confirmation do not match.');
      return;
    }
    const fbUser = auth.currentUser;
    if (!fbUser || !fbUser.email || !isPasswordProvider) {
      setPwErr('Password updates apply to Email/Password accounts. Manage Google Account security in Google settings.');
      return;
    }
    setSavingPw(true);
    try {
      const credential = EmailAuthProvider.credential(fbUser.email, currentPassword);
      await reauthenticateWithCredential(fbUser, credential);
      await updatePassword(fbUser, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setPwMsg('Password changed successfully.');
    } catch (err) {
      setPwErr(err instanceof Error ? err.message : 'Unable to change password. Check your current password.');
    } finally {
      setSavingPw(false);
    }
  };

  const handleDemoAction = async (action: 'reset' | 'clear') => {
    if (!user) return;
    setDemoMsg(null);
    setDemoErr(null);
    setDemoBusy(true);
    try {
      await resetDemoData(user.uid, action, user.accountType ?? 'both');
      await onDemoChanged();
      setDemoMsg(
        action === 'reset'
          ? 'Sample demonstration items have been restored.'
          : 'Sample demonstration items have been cleared.'
      );
    } catch (err) {
      setDemoErr(err instanceof Error ? err.message : 'Unable to update demonstration data.');
    } finally {
      setDemoBusy(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Preferences</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Settings & Personalisation
          </h1>
        </div>

        <button
          type="button"
          onClick={() => navigate({ name: 'notifications' })}
          className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium cursor-pointer"
        >
          <Bell className="h-4 w-4" />
          <span>Notification Preferences</span>
        </button>
      </div>

      {/* Appearance Section */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Palette className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
            <div>
              <h2 className="font-display text-lg font-bold">Appearance</h2>
              <p className="text-xs text-[var(--text-secondary)]">
                Switch between Cream & Green Light Theme and Coffee Dark Theme, and customise your accent colour.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => resetAppearance()}
            className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset to default</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => updateAppearance({ theme: 'light' })}
            className={`rounded-2xl p-4 text-left border transition-all cursor-pointer ${
              theme === 'light'
                ? 'border-[var(--accent)] ring-2 ring-[var(--accent-ring)] bg-[#F5F1E6] text-[#182920]'
                : 'ea-surface'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-2 font-semibold text-sm">
                <Sun className="h-4 w-4" />
                <span>Light Theme</span>
              </span>
              {theme === 'light' && <Check className="h-4 w-4" />}
            </div>
            <p className="text-xs opacity-75 mt-1">
              Cream, warm white & natural green glassmorphism
            </p>
          </button>

          <button
            type="button"
            onClick={() => updateAppearance({ theme: 'dark' })}
            className={`rounded-2xl p-4 text-left border transition-all cursor-pointer ${
              theme === 'dark'
                ? 'border-[var(--accent)] ring-2 ring-[var(--accent-ring)] bg-[#201713] text-[#F6EFE6]'
                : 'ea-surface'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-2 font-semibold text-sm">
                <Moon className="h-4 w-4" />
                <span>Dark Theme</span>
              </span>
              {theme === 'dark' && <Check className="h-4 w-4" />}
            </div>
            <p className="text-xs opacity-75 mt-1">
              Coffee brown, dark chocolate & warm amber glassmorphism
            </p>
          </button>
        </div>

        <div className="space-y-3 pt-2 border-t border-[var(--border-subtle)]">
          <label className="block text-sm font-medium">Accent colour</label>
          <div className="flex flex-wrap items-center gap-2.5">
            {ACCENT_PRESETS.map((preset) => {
              const selected = accentColor.toUpperCase() === preset.hex.toUpperCase();
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => updateAppearance({ accentColor: preset.hex })}
                  className={`ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium cursor-pointer ${
                    selected ? 'ring-2 ring-[var(--accent-ring)] border-[var(--accent)]' : ''
                  }`}
                >
                  <span
                    className="h-4 w-4 rounded-full border border-black/15"
                    style={{ backgroundColor: preset.hex }}
                  />
                  <span>{preset.label}</span>
                </button>
              );
            })}

            <label className="ea-surface inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium cursor-pointer">
              <input
                type="color"
                aria-label="Pick custom accent colour"
                value={accentColor}
                onChange={(e) => updateAppearance({ accentColor: e.target.value })}
                className="h-5 w-6 rounded border-0 bg-transparent cursor-pointer p-0"
              />
              <span className="font-mono">{accentColor}</span>
            </label>
          </div>

          <div className="ea-surface rounded-xl px-4 py-2.5 text-xs text-[var(--text-secondary)] flex flex-wrap items-center justify-between gap-2">
            <span>
              Automatic contrast check: Button text ratio{' '}
              <strong className="font-mono text-[var(--text-primary)]">
                {accentPalette.buttonContrast}:1
              </strong>{' '}
              · Surface label ratio{' '}
              <strong className="font-mono text-[var(--text-primary)]">
                {accentPalette.textContrast}:1
              </strong>
            </span>
            {accentPalette.adjustedForReadability && (
              <span style={{ color: 'var(--accent-text)' }} className="font-medium">
                Label shade auto-adjusted for legibility
              </span>
            )}
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-[var(--border-subtle)]">
          <label className="block text-sm font-medium">Font size preference</label>
          <div className="flex flex-wrap gap-2">
            {(['small', 'medium', 'large'] as FontSizePref[]).map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => updateAppearance({ fontSize: sz })}
                className={`rounded-xl px-4 py-2 text-xs font-semibold capitalize cursor-pointer ${
                  fontSize === sz
                    ? 'ea-btn-accent'
                    : 'ea-surface text-[var(--text-secondary)]'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Profile Section */}
      <form onSubmit={handleSaveProfile} className="ea-glass rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-2.5">
          <User className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
          <div>
            <h2 className="font-display text-lg font-bold">Profile & Operating Modes</h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Update your account details and choose which modes you use.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="set-name" className="block text-sm font-medium mb-1.5">
              Full name
            </label>
            <input
              id="set-name"
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label htmlFor="set-email" className="block text-sm font-medium mb-1.5">
              Email address
            </label>
            <input
              id="set-email"
              type="email"
              required
              disabled
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm opacity-75"
            />
          </div>

          <div>
            <label htmlFor="set-account-type" className="block text-sm font-medium mb-1.5">
              Account access
            </label>
            <select
              id="set-account-type"
              value={accountType}
              onChange={(e) => setAccountType(e.target.value as AccountType)}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              <option value="household">Household only</option>
              <option value="supermarket">Supermarket only</option>
              <option value="both">Both Household & Supermarket</option>
            </select>
          </div>

          {accountType === 'both' && (
            <div>
              <label htmlFor="set-pref-mode" className="block text-sm font-medium mb-1.5">
                Preferred starting mode
              </label>
              <select
                id="set-pref-mode"
                value={preferredMode}
                onChange={(e) => setPreferredMode(e.target.value as OperatingMode)}
                className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
              >
                <option value="household">Household Mode</option>
                <option value="supermarket">Supermarket Mode</option>
              </select>
            </div>
          )}
        </div>

        <ImageUploadField
          label="Profile Photo (Optional)"
          imageUrl={profileImageUrl}
          onChange={setProfileImageUrl}
        />

        {profileErr && (
          <p className="text-xs font-medium text-red-700 dark:text-red-400">{profileErr}</p>
        )}
        {profileMsg && (
          <p className="text-xs font-medium" style={{ color: 'var(--accent-text)' }}>
            {profileMsg}
          </p>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={savingProfile}
            className="ea-btn-accent rounded-xl px-6 py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
          >
            {savingProfile ? 'Saving...' : 'Save Profile'}
          </button>
        </div>
      </form>

      {/* Demonstration Data Section */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2.5">
          <Database className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
          <div>
            <h2 className="font-display text-lg font-bold">Demonstration Data</h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Sample items are clearly labelled and can be restored or cleared from your workspace anytime.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={demoBusy}
            onClick={() => handleDemoAction('reset')}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Sample Data</span>
          </button>
          <button
            type="button"
            disabled={demoBusy}
            onClick={() => handleDemoAction('clear')}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold text-red-700 dark:text-red-400 cursor-pointer"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear Sample Data</span>
          </button>
        </div>
        {demoErr && (
          <p className="text-xs font-medium text-red-700 dark:text-red-400">{demoErr}</p>
        )}
        {demoMsg && (
          <p className="text-xs font-medium" style={{ color: 'var(--accent-text)' }}>
            {demoMsg}
          </p>
        )}
      </section>

      {/* Inventory Backup (CSV Export) Section */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2.5">
          <Download className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
          <div>
            <h2 className="font-display text-lg font-bold">Inventory Backup (CSV)</h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Download your product records and batch expiry dates as a spreadsheet-ready CSV file for backup or record-keeping.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {(user?.accountType === 'household' || user?.accountType === 'both') && (
            <button
              type="button"
              disabled={householdProducts.length === 0}
              onClick={() =>
                exportHouseholdInventoryCsv(
                  householdProducts,
                  user?.defaultReminderDays ?? 5
                )
              }
              className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export Household CSV ({householdProducts.length} items)</span>
            </button>
          )}
          {(user?.accountType === 'supermarket' || user?.accountType === 'both') && (
            <button
              type="button"
              disabled={supermarketProducts.length === 0}
              onClick={() =>
                exportSupermarketInventoryCsv(
                  supermarketProducts,
                  user?.defaultReminderDays ?? 5
                )
              }
              className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export Supermarket CSV ({supermarketProducts.length} products)</span>
            </button>
          )}
        </div>
      </section>

      {/* Account Security & Logout */}
      <form onSubmit={handleChangePassword} className="ea-glass rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
          <div>
            <h2 className="font-display text-lg font-bold">Account Security</h2>
            <p className="text-xs text-[var(--text-secondary)]">
              {isPasswordProvider
                ? 'Update your account password or sign out of ExpiryAlert.'
                : 'Signed in via Google / Demo Sandbox. Sign out below anytime.'}
            </p>
          </div>
        </div>

        {isPasswordProvider && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="pw-curr" className="block text-xs font-medium mb-1">
                Current password
              </label>
              <input
                id="pw-curr"
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="pw-new" className="block text-xs font-medium mb-1">
                New password
              </label>
              <input
                id="pw-new"
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="pw-confirm" className="block text-xs font-medium mb-1">
                Confirm new password
              </label>
              <input
                id="pw-confirm"
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="ea-input w-full rounded-xl px-3.5 py-2 text-sm"
              />
            </div>
          </div>
        )}

        {pwErr && <p className="text-xs font-medium text-red-700 dark:text-red-400">{pwErr}</p>}
        {pwMsg && (
          <p className="text-xs font-medium" style={{ color: 'var(--accent-text)' }}>
            {pwMsg}
          </p>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[var(--border-subtle)]">
          <button
            type="button"
            onClick={async () => {
              await logout();
              navigate({ name: 'landing' });
            }}
            className="ea-surface inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-red-700 dark:text-red-400 cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>{user?.isDemoSession ? 'Exit Demo' : 'Logout'}</span>
          </button>

          {isPasswordProvider && (
            <button
              type="submit"
              disabled={savingPw}
              className="ea-btn-accent rounded-xl px-5 py-2.5 text-sm font-semibold cursor-pointer disabled:opacity-60"
            >
              {savingPw ? 'Updating...' : 'Update Password'}
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

// ---------------- NOTIFICATION PREFERENCES PAGE ----------------

export const NotificationPreferencesPage: React.FC<{
  notifications: NotificationHistoryItem[];
  onRefreshNotifications: () => Promise<void>;
  onSendTestNotification: (delayMs?: number) => Promise<void>;
  navigate: (route: AppRoute) => void;
}> = ({ notifications, onRefreshNotifications, onSendTestNotification, navigate }) => {
  const { user, setUser, activeMode } = useAuthTheme();
  const [permissionState, setPermissionState] = useState<NotificationPermissionState>(() =>
    getNotificationPermission()
  );
  const [fcmStatus, setFcmStatus] = useState<FcmStatus>('permission_needed');
  const [saving, setSaving] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);
  const [lockscreenCountdown, setLockscreenCountdown] = useState<number | null>(null);
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [actionErr, setActionErr] = useState<string | null>(null);

  useEffect(() => {
    const syncPermission = () => setPermissionState(getNotificationPermission());
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncPermission();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, []);

  useEffect(() => {
    if (!user || user.isDemoSession) return;
    void registerFcmDeviceToken(user.uid).then((res) => setFcmStatus(res.status));
  }, [user?.uid, user?.isDemoSession, permissionState]);

  useEffect(() => {
    if (lockscreenCountdown === null) return;
    if (lockscreenCountdown <= 0) {
      setLockscreenCountdown(null);
      setActionMsg('Lock-screen notification dispatched via Service Worker.');
      return;
    }
    const timer = window.setTimeout(() => {
      setLockscreenCountdown((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [lockscreenCountdown]);

  const toggleNotifications = async (enabled: boolean) => {
    if (!user) return;
    setActionErr(null);
    setActionMsg(null);
    setSaving(true);
    try {
      const updated = await updateUserProfile(user.uid, { notificationsEnabled: enabled });
      setUser(updated);
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to update notification settings.');
    } finally {
      setSaving(false);
    }
  };

  const updateDefaultDays = async (days: number) => {
    if (!user) return;
    setActionErr(null);
    setActionMsg(null);
    setSaving(true);
    try {
      const updated = await updateUserProfile(user.uid, { defaultReminderDays: days });
      setUser(updated);
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to update reminder interval.');
    } finally {
      setSaving(false);
    }
  };

  const updateScheduleTime = async (time: string) => {
    if (!user) return;
    setActionErr(null);
    setActionMsg(null);
    setSaving(true);
    try {
      const updated = await updateUserProfile(user.uid, { reminderScheduleTime: time });
      setUser(updated);
      setActionMsg(`Daily background reminder window updated to ${time}.`);
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to update schedule time.');
    } finally {
      setSaving(false);
    }
  };

  const requestBrowserPermission = async () => {
    setActionErr(null);
    setActionMsg(null);
    try {
      const perm = await requestLockscreenPermission();
      setPermissionState(perm);
      if (perm === 'granted' && user && !user.isDemoSession) {
        const res = await registerFcmDeviceToken(user.uid);
        setFcmStatus(res.status);
        setActionMsg('Lock-screen notifications and background push alerts enabled.');
      } else if (perm === 'granted') {
        setActionMsg('Lock-screen notifications enabled for this device.');
      } else if (perm === 'denied') {
        setActionErr('Notification permission was declined. Allow notifications in your browser site settings.');
      }
    } catch {
      setActionErr('Browser notification permission prompt was blocked.');
    }
  };

  const handleTestNotification = async (delayMs = 0) => {
    setActionErr(null);
    setActionMsg(null);
    setSendingTest(true);
    try {
      await onSendTestNotification(delayMs);
      if (delayMs > 0) {
        setLockscreenCountdown(Math.ceil(delayMs / 1000));
      } else {
        setActionMsg('Test notification dispatched to your device.');
      }
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to dispatch test notification.');
    } finally {
      setSendingTest(false);
    }
  };

  const handleMarkAllRead = async () => {
    if (!user) return;
    setActionErr(null);
    try {
      await markAllNotificationsRead(user.uid);
      await onRefreshNotifications();
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to mark notifications read.');
    }
  };

  const handleClearHistory = async () => {
    if (!user) return;
    setActionErr(null);
    try {
      await clearNotifications(user.uid);
      await onRefreshNotifications();
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : 'Unable to clear notifications.');
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[var(--text-secondary)]">Preferences</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mt-0.5">
            Notification Preferences
          </h1>
        </div>
        <button
          type="button"
          onClick={() => navigate({ name: 'settings' })}
          className="ea-surface rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
        >
          Back to Settings
        </button>
      </div>

      {/* Automatic Expiry Alerts & Background Schedule */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <BellRing className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
            <div>
              <h2 className="font-display text-lg font-bold">Automatic Expiry Alerts & Schedule</h2>
              <p className="text-xs text-[var(--text-secondary)]">
                In-app, Service Worker, and scheduled background alerts triggered automatically by expiry dates.
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={saving}
            onClick={() => toggleNotifications(!(user?.notificationsEnabled ?? true))}
            className={`rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer ${
              user?.notificationsEnabled
                ? 'ea-btn-accent'
                : 'ea-surface text-[var(--text-secondary)]'
            }`}
          >
            {user?.notificationsEnabled ? 'Enabled' : 'Disabled'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[var(--border-subtle)]">
          <div>
            <label htmlFor="np-days" className="block text-sm font-medium mb-1.5">
              Default reminder interval
            </label>
            <select
              id="np-days"
              disabled={saving}
              value={user?.defaultReminderDays ?? 5}
              onChange={(e) => updateDefaultDays(Number(e.target.value))}
              className="ea-input w-full rounded-xl px-3.5 py-2.5 text-sm"
            >
              {[15, 7, 5, 3, 1, 0].map((d) => (
                <option key={d} value={d}>
                  {d === 0 ? 'On expiry date (0 days)' : `${d} days before expiry`}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="np-time" className="block text-sm font-medium mb-1.5">
              Daily background check time
            </label>
            <div className="relative">
              <Clock className="h-4 w-4 absolute left-3 top-3 text-[var(--text-muted)]" />
              <input
                id="np-time"
                type="time"
                disabled={saving}
                value={user?.reminderScheduleTime ?? '09:00'}
                onChange={(e) => updateScheduleTime(e.target.value)}
                className="ea-input w-full rounded-xl pl-9 pr-3.5 py-2 text-sm"
              />
            </div>
          </div>

          <div className="flex flex-col justify-end">
            <button
              type="button"
              onClick={() =>
                navigate({
                  name:
                    activeMode === 'supermarket'
                      ? 'supermarket-reminders'
                      : 'household-reminders',
                })
              }
              className="ea-surface rounded-xl px-4 py-2.5 text-sm font-medium text-left cursor-pointer"
            >
              Per-product intervals →
            </button>
          </div>
        </div>
      </section>

      {/* Lock-Screen & FCM Push Notifications */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-lg font-bold">
            Lock-Screen & FCM Push Notifications (PWA)
          </h2>
          <span
            className="text-xs font-semibold"
            style={permissionState === 'granted' ? { color: 'var(--accent-text)' } : undefined}
          >
            {permissionState === 'granted'
              ? fcmStatus === 'active'
                ? 'Push & FCM Token Registered'
                : 'Device Notifications Allowed'
              : permissionState === 'denied'
              ? 'Blocked in browser'
              : permissionState === 'unsupported'
              ? 'Not supported here'
              : 'Permission needed'}
          </span>
        </div>

        <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
          ExpiryAlert combines Service Worker background periodic sync with Firebase Cloud Messaging (FCM) so alerts reach your lock screen even when the tab is minimized.
        </p>

        {permissionState === 'granted' && fcmStatus === 'vapid_missing' && !user?.isDemoSession && (
          <p className="ea-surface rounded-xl px-4 py-2.5 text-xs text-[var(--text-secondary)]">
            Local Service Worker & scheduled reminders are active. To enable remote FCM web-push tokens as well, add your Firebase Web Push Certificate key to <code className="font-mono">VITE_FIREBASE_VAPID_KEY</code>.
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3">
          {permissionState === 'unsupported' ? (
            <span className="text-xs text-[var(--text-muted)]">
              Browser Notification API is not supported in this browser.
            </span>
          ) : permissionState === 'granted' ? (
            <>
              <button
                type="button"
                disabled={sendingTest}
                onClick={() => handleTestNotification(0)}
                className="ea-btn-accent rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer disabled:opacity-60"
              >
                Send Test Notification
              </button>
              <button
                type="button"
                disabled={sendingTest || lockscreenCountdown !== null}
                onClick={() => handleTestNotification(5000)}
                className="ea-surface rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer disabled:opacity-60"
              >
                {lockscreenCountdown !== null
                  ? `Lock screen now (${lockscreenCountdown}s)...`
                  : 'Test on Lock Screen (5s Delay)'}
              </button>
            </>
          ) : permissionState === 'denied' ? (
            <p className="text-xs text-red-700 dark:text-red-400">
              Notifications are currently blocked for this site. Open your browser site settings, set Notifications to Allow, and return here.
            </p>
          ) : (
            <button
              type="button"
              onClick={requestBrowserPermission}
              className="ea-btn-accent rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
            >
              Enable Lock-Screen Notifications
            </button>
          )}
          <PWAInstallButton />
        </div>

        {lockscreenCountdown !== null && (
          <div className="ea-surface rounded-xl px-4 py-3 text-xs font-medium">
            Lock your device screen or switch away from the browser now — your lock-screen expiry alert will arrive in{' '}
            <span className="font-mono font-bold" style={{ color: 'var(--accent-text)' }}>
              {lockscreenCountdown}s
            </span>
            .
          </div>
        )}
        {actionMsg && (
          <p className="text-xs font-medium" style={{ color: 'var(--accent-text)' }}>
            {actionMsg}
          </p>
        )}
        {actionErr && (
          <p className="text-xs font-medium text-red-700 dark:text-red-400">{actionErr}</p>
        )}
      </section>

      {/* Notification History */}
      <section className="ea-glass rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-bold">Notification History</h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Recent expiry and stock alerts recorded for your account
            </p>
          </div>
          {notifications.length > 0 && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleMarkAllRead}
                className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                <span>Mark all read</span>
              </button>
              <button
                type="button"
                onClick={handleClearHistory}
                className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-red-700 dark:text-red-400 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Clear</span>
              </button>
            </div>
          )}
        </div>

        {notifications.length === 0 ? (
          <p className="text-sm text-[var(--text-secondary)] py-6 text-center">
            No notification history recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-[var(--border-subtle)]">
            {notifications.map((n) => {
              const formattedDate = n.createdAt
                ? new Date(n.createdAt).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                  })
                : '';
              return (
                <div key={n.id} className="py-3 flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold">
                      {!n.isRead && (
                        <span
                          className="inline-block mr-2 text-xs font-medium"
                          style={{ color: 'var(--accent-text)' }}
                        >
                          New ·
                        </span>
                      )}
                      {n.title}
                    </p>
                    <p className="text-xs text-[var(--text-secondary)] mt-0.5">{n.message}</p>
                  </div>
                  <span className="text-[11px] font-mono text-[var(--text-muted)] shrink-0 whitespace-nowrap">
                    {n.mode} · {n.channel}
                    {formattedDate ? ` · ${formattedDate}` : ''}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
