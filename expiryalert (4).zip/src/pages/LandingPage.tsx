import React from 'react';
import {
  ArrowRight,
  BellRing,
  Boxes,
  CheckCircle2,
  Home,
  Layers,
  Leaf,
  Mail,
  Moon,
  PiggyBank,
  Store,
  Sun,
} from 'lucide-react';
import type { AppRoute } from '../components/AppShell.tsx';
import { BrandLogoIcon } from '../components/BrandMark.tsx';
import { PWAInstallButton } from '../components/PWAInstallButton.tsx';
import { useAuthTheme } from '../context/AuthThemeContext.tsx';
import type { OperatingMode } from '../types/index.ts';

interface LandingPageProps {
  navigate: (route: AppRoute) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ navigate }) => {
  const { user, theme, updateAppearance, setActiveMode } = useAuthTheme();

  const openMode = (mode: OperatingMode) => {
    if (user) {
      if (user.accountType === 'both' || user.accountType === mode) {
        setActiveMode(mode);
      }
      navigate({ name: mode === 'supermarket' ? 'supermarket-dashboard' : 'household-dashboard' });
    } else {
      navigate({ name: 'login', initialMode: mode });
    }
  };

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-30 ea-glass border-b border-[var(--border-subtle)]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-8">
          <a
            href="#top"
            onClick={(e) => scrollToSection(e, 'top')}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0"
          >
            <BrandLogoIcon className="h-8 w-8 shrink-0" />
            <span className="font-display text-lg font-bold tracking-tight">ExpiryAlert</span>
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[var(--text-secondary)]">
            <a
              href="#features"
              onClick={(e) => scrollToSection(e, 'features')}
              className="hover:text-[var(--text-primary)] hover:underline underline-offset-4 whitespace-nowrap shrink-0 transition-colors"
            >
              Features
            </a>
            <a
              href="#how-it-works"
              onClick={(e) => scrollToSection(e, 'how-it-works')}
              className="hover:text-[var(--text-primary)] hover:underline underline-offset-4 whitespace-nowrap shrink-0 transition-colors"
            >
              How It Works
            </a>
            <a
              href="#about"
              onClick={(e) => scrollToSection(e, 'about')}
              className="hover:text-[var(--text-primary)] hover:underline underline-offset-4 whitespace-nowrap shrink-0 transition-colors"
            >
              About
            </a>
            <a
              href="#contact"
              onClick={(e) => scrollToSection(e, 'contact')}
              className="hover:text-[var(--text-primary)] hover:underline underline-offset-4 whitespace-nowrap shrink-0 transition-colors"
            >
              Contact
            </a>
          </nav>

          <div className="shrink-0">
            {user ? (
              <button
                type="button"
                onClick={() => openMode(user.preferredMode)}
                className="ea-btn-accent rounded-xl px-4 py-2 text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer"
              >
                Open Dashboard
              </button>
            ) : (
              <button
                type="button"
                onClick={() => navigate({ name: 'login' })}
                className="ea-btn-accent rounded-xl px-5 py-2 text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer"
              >
                Login
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="top" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-14 lg:pt-16 lg:pb-20 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          <div className="lg:col-span-6 ea-glass rounded-3xl p-7 sm:p-10 flex flex-col justify-between gap-8">
            <div className="space-y-5">
              <div className="flex items-center justify-between gap-4">
                <p className="text-xs font-medium text-[var(--text-secondary)]">
                  Packaged Food Expiry Tracking
                </p>
                <button
                  type="button"
                  onClick={() => updateAppearance({ theme: theme === 'light' ? 'dark' : 'light' })}
                  className="ea-surface inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer whitespace-nowrap"
                >
                  {theme === 'light' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
                  <span>{theme === 'light' ? 'Dark Theme' : 'Light Theme'}</span>
                </button>
              </div>

              <h1 className="font-display text-[clamp(2rem,3.6vw,2.85rem)] font-bold tracking-tight leading-[1.1] [text-wrap:balance]">
                Never Let Your Food Expire Unnoticed.
              </h1>

              <p className="text-base text-[var(--text-secondary)] leading-relaxed max-w-xl">
                Track packaged food, monitor expiry dates, and receive timely reminders. Reduce food waste and manage your food inventory efficiently with ExpiryAlert.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => openMode('household')}
                  className="ea-btn-accent ea-card-interactive rounded-2xl px-5 py-3.5 text-left flex items-center justify-between gap-3 cursor-pointer"
                >
                  <span className="flex items-center gap-3 min-w-0">
                    <Home className="h-5 w-5 shrink-0" />
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold whitespace-nowrap">Household Mode</span>
                      <span className="block text-xs opacity-85 truncate">Home pantry & fridge</span>
                    </span>
                  </span>
                  <ArrowRight className="h-4 w-4 shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={() => openMode('supermarket')}
                  className="ea-surface ea-card-interactive rounded-2xl px-5 py-3.5 text-left flex items-center justify-between gap-3 cursor-pointer"
                >
                  <span className="flex items-center gap-3 min-w-0">
                    <Store className="h-5 w-5 shrink-0" style={{ color: 'var(--accent-text)' }} />
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold whitespace-nowrap">Supermarket Mode</span>
                      <span className="block text-xs text-[var(--text-secondary)] truncate">
                        Batch & stock control
                      </span>
                    </span>
                  </span>
                  <ArrowRight className="h-4 w-4 shrink-0 text-[var(--text-secondary)]" />
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-sm">
                {user ? (
                  <span className="text-xs text-[var(--text-secondary)]">
                    Signed in as <strong className="text-[var(--text-primary)]">{user.fullName}</strong>
                  </span>
                ) : (
                  <div className="flex items-center gap-4">
                    <button
                      type="button"
                      onClick={() => navigate({ name: 'register' })}
                      className="font-semibold hover:underline underline-offset-4 cursor-pointer"
                      style={{ color: 'var(--accent-text)' }}
                    >
                      Create an account
                    </button>
                    <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
                    <button
                      type="button"
                      onClick={() => navigate({ name: 'login' })}
                      className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                    >
                      Sign in
                    </button>
                  </div>
                )}
                <PWAInstallButton compact />
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative rounded-3xl overflow-hidden border border-[var(--border-subtle)] min-h-[280px] lg:min-h-full">
            <img
              src="/src/assets/images/hero_fresh_pantry_1795166952223.jpg"
              alt="Organised packaged milk, crusty bread, yogurt, oats, and fresh pantry jars on an oak counter"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover lg:absolute lg:inset-0"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent p-6 sm:p-8 text-white">
              <p className="text-xs font-medium text-white/80">Built for daily clarity</p>
              <p className="font-display text-lg font-semibold mt-1">
                Separate workspaces for home kitchens and retail grocery shelves.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Three Key Benefits */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 w-full">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-5 ea-glass rounded-2xl p-6 sm:p-7 flex flex-col justify-between gap-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-semibold" style={{ color: 'var(--accent-text)' }}>
                01
              </span>
              <Leaf className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
            </div>
            <div className="space-y-1.5">
              <h2 className="font-display text-lg font-semibold">Reduce Food Waste</h2>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Spot items approaching expiry days in advance so milk, bread, yogurt, and dry goods are consumed or rotated in time.
              </p>
            </div>
          </div>

          <div className="md:col-span-4 ea-glass rounded-2xl p-6 sm:p-7 flex flex-col justify-between gap-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-semibold" style={{ color: 'var(--accent-text)' }}>
                02
              </span>
              <PiggyBank className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
            </div>
            <div className="space-y-1.5">
              <h2 className="font-display text-lg font-semibold">Save Money</h2>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Avoid duplicate purchases and discarded stock by knowing exact quantities and expiry dates at a glance.
              </p>
            </div>
          </div>

          <div className="md:col-span-3 ea-glass rounded-2xl p-6 sm:p-7 flex flex-col justify-between gap-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-semibold" style={{ color: 'var(--accent-text)' }}>
                03
              </span>
              <Layers className="h-5 w-5" style={{ color: 'var(--accent-text)' }} />
            </div>
            <div className="space-y-1.5">
              <h2 className="font-display text-lg font-semibold">Stay Organised</h2>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Keep pantry items and batches categorised, searchable, and sorted by earliest expiry.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 w-full">
        <div className="ea-glass rounded-3xl p-7 sm:p-10">
          <div className="max-w-2xl mb-8">
            <p className="text-xs font-medium text-[var(--text-secondary)]">How It Works</p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold mt-1 [text-wrap:balance]">
              Three straightforward steps from shelf entry to timely action
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <p className="font-mono text-sm font-semibold" style={{ color: 'var(--accent-text)' }}>
                01. Record your groceries
              </p>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Add packaged food items manually with quantity, purchase date, expiry date, optional photo, and compulsory batch numbers in Supermarket Mode.
              </p>
            </div>
            <div className="space-y-2">
              <p className="font-mono text-sm font-semibold" style={{ color: 'var(--accent-text)' }}>
                02. Monitor automatic status
              </p>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                ExpiryAlert classifies every item as Fresh, Good, Near Expiry, or Expired based on your chosen reminder threshold.
              </p>
            </div>
            <div className="space-y-2">
              <p className="font-mono text-sm font-semibold" style={{ color: 'var(--accent-text)' }}>
                03. Receive alerts & act
              </p>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Review upcoming reminders, snooze or resolve alerts, and mark items as Used, Sold, or Wasted to keep stock accurate.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-5 relative rounded-3xl overflow-hidden border border-[var(--border-subtle)] min-h-[260px]">
            <img
              src="/src/assets/images/supermarket_aisle_fresh_1795166952034.jpg"
              alt="Clean organised grocery shelves with dairy, bakery loaves, and fresh baskets"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover lg:absolute lg:inset-0"
            />
          </div>

          <div className="lg:col-span-7 ea-glass rounded-3xl p-7 sm:p-10 space-y-6">
            <div>
              <p className="text-xs font-medium text-[var(--text-secondary)]">Two Dedicated Modes</p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold mt-1">
                Tailored workflows without unnecessary complexity
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
              <div className="space-y-3">
                <div className="flex items-center gap-2 font-semibold">
                  <Home className="h-4 w-4" style={{ color: 'var(--accent-text)' }} />
                  <span>Household Mode</span>
                </div>
                <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Live expiry overview dashboard & bar chart</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Quick Used & Wasted quantity logging</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Custom per-product reminder intervals</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 font-semibold">
                  <Boxes className="h-4 w-4" style={{ color: 'var(--accent-text)' }} />
                  <span>Supermarket Mode</span>
                </div>
                <ul className="space-y-2 text-sm text-[var(--text-secondary)]">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Separate batch records sorted by earliest expiry</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Custom retail categories & low-stock alerts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" style={{ color: 'var(--accent-text)' }} />
                    <span>Automatic remaining stock recalculation</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="pt-2 border-t border-[var(--border-subtle)] flex items-center gap-2 text-xs text-[var(--text-secondary)]">
              <BellRing className="h-4 w-4 shrink-0" style={{ color: 'var(--accent-text)' }} />
              <span>
                Includes dual Light & Dark themes, accessible custom accent colours, and browser/PWA notifications.
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* About & Contact */}
      <section id="about" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 w-full">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-7 ea-glass rounded-3xl p-7 sm:p-9 space-y-3">
            <p className="text-xs font-medium text-[var(--text-secondary)]">About the Project</p>
            <h2 className="font-display text-2xl font-bold">
              Practical food-waste prevention for our community
            </h2>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
              ExpiryAlert was designed as an undergraduate IEM community project focused on affordability, clarity, and everyday reliability. By avoiding costly hardware or complex external services, families and neighborhood grocery stores can track packaged inventory accurately on any phone, tablet, or desktop browser.
            </p>
          </div>

          <div id="contact" className="md:col-span-5 ea-glass rounded-3xl p-7 sm:p-9 flex flex-col justify-between gap-4">
            <div className="space-y-2">
              <p className="text-xs font-medium text-[var(--text-secondary)]">Contact</p>
              <h2 className="font-display text-2xl font-bold">Get in touch</h2>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                For project feedback, community deployment questions, or bug reports, reach us by email.
              </p>
            </div>
            <a
              href="mailto:contact@expiryalert.org"
              className="ea-surface inline-flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-medium w-fit hover:border-[var(--border-strong)] transition-colors"
            >
              <Mail className="h-4 w-4 shrink-0" style={{ color: 'var(--accent-text)' }} />
              <span>contact@expiryalert.org</span>
            </a>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-[var(--border-subtle)] ea-glass">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[var(--text-secondary)]">
          <div className="flex items-center gap-2">
            <BrandLogoIcon className="h-5 w-5" />
            <span>ExpiryAlert · Packaged Food Expiry Reminder System</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => openMode('household')}
              className="hover:text-[var(--text-primary)] cursor-pointer"
            >
              Household
            </button>
            <button
              type="button"
              onClick={() => openMode('supermarket')}
              className="hover:text-[var(--text-primary)] cursor-pointer"
            >
              Supermarket
            </button>
            <a href="mailto:contact@expiryalert.org" className="hover:text-[var(--text-primary)]">
              contact@expiryalert.org
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
