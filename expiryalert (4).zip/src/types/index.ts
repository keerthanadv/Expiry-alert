export type AccountType = 'household' | 'supermarket' | 'both';
export type OperatingMode = 'household' | 'supermarket';
export type ThemeMode = 'light' | 'dark';
export type FontSizePref = 'small' | 'medium' | 'large';
export type ExpiryStatus = 'Fresh' | 'Good' | 'Near Expiry' | 'Expired';
export type ReminderStateStatus = 'active' | 'snoozed' | 'resolved';

export interface UserProfile {
  id: string;
  uid: string;
  fullName: string;
  email: string;
  accountType: AccountType;
  preferredMode: OperatingMode;
  profileImageUrl: string | null;
  theme: ThemeMode;
  accentColor: string;
  fontSize: FontSizePref;
  notificationsEnabled: boolean;
  defaultReminderDays: number;
  reminderScheduleTime: string;
  emailVerified?: boolean;
  isDemoSession?: boolean;
  createdAt: string;
}

export interface HouseholdProduct {
  id: string;
  userId: string;
  name: string;
  quantity: number;
  unit: string;
  purchaseDate: string;
  expiryDate: string;
  category: string;
  notes: string;
  imageUrl: string | null;
  reminderDays: number | null;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SupermarketCategory {
  id: string;
  userId: string;
  name: string;
  isDefault: boolean;
  createdAt: string;
}

export interface SupermarketBatch {
  id: string;
  userId: string;
  productId: string;
  productName?: string;
  productUnit?: string;
  categoryName?: string;
  batchNumber: string;
  initialQuantity: number;
  remainingQuantity: number;
  purchaseDate: string;
  expiryDate: string;
  notes: string;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SupermarketProduct {
  id: string;
  userId: string;
  name: string;
  categoryId: string;
  categoryName: string;
  unit: string;
  lowStockThreshold: number;
  notes: string;
  imageUrl: string | null;
  reminderDays: number | null;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
  batches: SupermarketBatch[];
}

export interface ProductActionLog {
  id: string;
  userId: string;
  mode: OperatingMode;
  productId: string | null;
  batchId: string | null;
  productName: string;
  actionType: 'used' | 'wasted' | 'sold' | 'added' | 'updated' | 'restocked' | 'deleted';
  quantityDelta: number;
  unit: string;
  note: string;
  createdAt: string;
}

export interface ReminderStateRecord {
  id: string;
  userId: string;
  mode: OperatingMode;
  targetType: 'household_product' | 'supermarket_batch' | 'low_stock';
  targetId: string;
  status: ReminderStateStatus;
  snoozedUntil: string | null;
  resolvedAt: string | null;
  updatedAt: string;
}

export interface NotificationHistoryItem {
  id: string;
  userId: string;
  mode: OperatingMode;
  title: string;
  message: string;
  channel: 'in_app' | 'browser' | 'fcm';
  isRead: boolean;
  createdAt: string;
}
