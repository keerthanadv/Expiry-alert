import type { User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import {
  db,
  handleFirestoreError,
  OperationType,
  storage,
} from '../firebase/config.ts';
import type {
  AccountType,
  FontSizePref,
  HouseholdProduct,
  NotificationHistoryItem,
  OperatingMode,
  ProductActionLog,
  ReminderStateRecord,
  ReminderStateStatus,
  SupermarketBatch,
  SupermarketCategory,
  SupermarketProduct,
  ThemeMode,
  UserProfile,
} from '../types/index.ts';
import { addDaysIso, getTodayIso } from '../utils/expiry.ts';
import {
  createDemoSandboxStore,
  DEFAULT_SUPERMARKET_CATEGORIES,
  type DemoSandboxStore,
} from './demoSandbox.ts';

let activeSandbox: DemoSandboxStore | null = null;

export function startDemoSandbox(mode: OperatingMode): DemoSandboxStore {
  activeSandbox = createDemoSandboxStore(mode);
  return activeSandbox;
}

export function getDemoSandbox(): DemoSandboxStore | null {
  return activeSandbox;
}

export function clearDemoSandbox(): void {
  activeSandbox = null;
}

function makeDocId(prefix: string): string {
  const rand =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 16)
      : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}_${rand}`;
}

function toIsoString(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (val && typeof val === 'object' && 'toDate' in val && typeof (val as { toDate: () => Date }).toDate === 'function') {
    return (val as { toDate: () => Date }).toDate().toISOString();
  }
  if (typeof val === 'string' && val) return val;
  return new Date().toISOString();
}

function clampString(val: string, maxLen: number): string {
  return val.trim().slice(0, maxLen);
}

function validateHttpsImageUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith('blob:') && activeSandbox) return trimmed;
  if (/^https:\/\/.+/i.test(trimmed) && trimmed.length <= 2048) {
    return trimmed;
  }
  return null;
}

function mapUserDoc(uid: string, d: Record<string, unknown>, emailVerified: boolean): UserProfile {
  return {
    id: uid,
    uid,
    fullName: String(d.fullName ?? 'ExpiryAlert User'),
    email: String(d.email ?? ''),
    accountType:
      d.accountType === 'household' || d.accountType === 'supermarket' ? d.accountType : 'both',
    preferredMode: d.preferredMode === 'supermarket' ? 'supermarket' : 'household',
    profileImageUrl: d.profileImageUrl ? String(d.profileImageUrl) : null,
    theme: d.theme === 'dark' ? 'dark' : 'light',
    accentColor:
      typeof d.accentColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(d.accentColor)
        ? d.accentColor.toUpperCase()
        : '#2E6F4E',
    fontSize: d.fontSize === 'small' || d.fontSize === 'large' ? d.fontSize : 'medium',
    notificationsEnabled: d.notificationsEnabled !== false,
    defaultReminderDays:
      typeof d.defaultReminderDays === 'number'
        ? Math.max(0, Math.min(60, Math.round(d.defaultReminderDays)))
        : 5,
    reminderScheduleTime:
      typeof d.reminderScheduleTime === 'string' && /^\d{2}:\d{2}$/.test(d.reminderScheduleTime)
        ? d.reminderScheduleTime
        : '09:00',
    emailVerified,
    isDemoSession: false,
    createdAt: toIsoString(d.createdAt),
  };
}

// ---------------- PROFILE & INITIALIZATION ----------------

export async function loadOrCreateUserProfile(
  fbUser: FirebaseUser,
  registrationMeta?: {
    fullName?: string;
    accountType?: AccountType;
    preferredMode?: OperatingMode;
  }
): Promise<UserProfile> {
  const uid = fbUser.uid;
  const path = `users/${uid}`;
  let snap;
  try {
    snap = await getDoc(doc(db, 'users', uid));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }

  if (snap.exists()) {
    return mapUserDoc(uid, snap.data() as Record<string, unknown>, fbUser.emailVerified);
  }

  const accountType: AccountType =
    registrationMeta?.accountType === 'household' ||
    registrationMeta?.accountType === 'supermarket' ||
    registrationMeta?.accountType === 'both'
      ? registrationMeta.accountType
      : 'both';
  const preferredMode: OperatingMode =
    accountType === 'supermarket'
      ? 'supermarket'
      : accountType === 'household'
      ? 'household'
      : registrationMeta?.preferredMode === 'supermarket'
      ? 'supermarket'
      : 'household';

  const fullName = clampString(
    registrationMeta?.fullName || fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
    120
  );
  const safeName = fullName.length >= 2 ? fullName : `${fullName} User`.slice(0, 120);
  const email = clampString(fbUser.email || `${uid}@expiryalert.app`, 254).toLowerCase();
  const profileImg = validateHttpsImageUrl(fbUser.photoURL);

  const payload = {
    uid,
    fullName: safeName,
    email,
    accountType,
    preferredMode,
    profileImageUrl: profileImg,
    theme: 'light' as ThemeMode,
    accentColor: '#2E6F4E',
    fontSize: 'medium' as FontSizePref,
    notificationsEnabled: true,
    defaultReminderDays: 5,
    reminderScheduleTime: '09:00',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'users', uid), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }

  // Seed default categories & starter demonstration records for new accounts
  await seedCloudDemonstrationData(uid, accountType);

  let createdSnap;
  try {
    createdSnap = await getDoc(doc(db, 'users', uid));
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }

  return mapUserDoc(
    uid,
    (createdSnap.data() ?? payload) as Record<string, unknown>,
    fbUser.emailVerified
  );
}

export async function updateUserProfile(
  uid: string,
  updates: Partial<{
    fullName: string;
    email: string;
    accountType: AccountType;
    preferredMode: OperatingMode;
    profileImageUrl: string | null;
    theme: ThemeMode;
    accentColor: string;
    fontSize: FontSizePref;
    notificationsEnabled: boolean;
    defaultReminderDays: number;
    reminderScheduleTime: string;
  }>
): Promise<UserProfile> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    activeSandbox.user = {
      ...activeSandbox.user,
      ...updates,
    };
    return { ...activeSandbox.user };
  }

  const path = `users/${uid}`;
  const cleanUpdates: Record<string, unknown> = { updatedAt: serverTimestamp() };

  if (typeof updates.fullName === 'string' && updates.fullName.trim().length >= 2) {
    cleanUpdates.fullName = clampString(updates.fullName, 120);
  }
  if (typeof updates.email === 'string' && updates.email.includes('@')) {
    cleanUpdates.email = clampString(updates.email.toLowerCase(), 254);
  }
  if (
    updates.accountType === 'household' ||
    updates.accountType === 'supermarket' ||
    updates.accountType === 'both'
  ) {
    cleanUpdates.accountType = updates.accountType;
  }
  if (updates.preferredMode === 'household' || updates.preferredMode === 'supermarket') {
    cleanUpdates.preferredMode = updates.preferredMode;
  }
  if (updates.profileImageUrl !== undefined) {
    cleanUpdates.profileImageUrl = validateHttpsImageUrl(updates.profileImageUrl);
  }
  if (updates.theme === 'light' || updates.theme === 'dark') {
    cleanUpdates.theme = updates.theme;
  }
  if (typeof updates.accentColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(updates.accentColor.trim())) {
    cleanUpdates.accentColor = updates.accentColor.trim().toUpperCase();
  }
  if (updates.fontSize === 'small' || updates.fontSize === 'medium' || updates.fontSize === 'large') {
    cleanUpdates.fontSize = updates.fontSize;
  }
  if (typeof updates.notificationsEnabled === 'boolean') {
    cleanUpdates.notificationsEnabled = updates.notificationsEnabled;
  }
  if (
    typeof updates.defaultReminderDays === 'number' &&
    updates.defaultReminderDays >= 0 &&
    updates.defaultReminderDays <= 60
  ) {
    cleanUpdates.defaultReminderDays = Math.round(updates.defaultReminderDays);
  }
  if (
    typeof updates.reminderScheduleTime === 'string' &&
    /^\d{2}:\d{2}$/.test(updates.reminderScheduleTime)
  ) {
    cleanUpdates.reminderScheduleTime = updates.reminderScheduleTime;
  }

  try {
    await updateDoc(doc(db, 'users', uid), cleanUpdates);
    const snap = await getDoc(doc(db, 'users', uid));
    return mapUserDoc(uid, snap.data() as Record<string, unknown>, true);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ---------------- PERMANENT IMAGE STORAGE (FIREBASE STORAGE) ----------------

const ALLOWED_IMAGE_MIME: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

export async function uploadProductImage(userId: string, file: File): Promise<string> {
  const mime = file.type.toLowerCase();
  const ext = ALLOWED_IMAGE_MIME[mime];
  if (!ext) {
    throw new Error('Please choose a JPG, PNG, or WebP image file.');
  }
  if (file.size === 0 || file.size > 2 * 1024 * 1024) {
    throw new Error('Image size must be 2 MB or smaller.');
  }

  if (activeSandbox && userId === activeSandbox.user.uid) {
    return URL.createObjectURL(file);
  }

  const filename = `${makeDocId('img')}.${ext}`;
  const storagePath = `users/${userId}/images/${filename}`;
  const fileRef = ref(storage, storagePath);

  try {
    await uploadBytes(fileRef, file, {
      contentType: mime,
      cacheControl: 'public,max-age=31536000',
    });
    return await getDownloadURL(fileRef);
  } catch (err) {
    const code = (err as { code?: string })?.code ?? '';
    if (code === 'storage/unauthorized' || code === 'storage/unauthenticated') {
      throw new Error(
        'Cloud image upload requires Firebase Storage rules enabled for authenticated users in Firebase Console -> Storage. You can still save items cleanly without an image.'
      );
    }
    throw new Error('Unable to upload image to cloud storage. You can save the item without an image.');
  }
}

// ---------------- HOUSEHOLD DATA & MUTATIONS ----------------

export async function fetchHouseholdData(uid: string): Promise<{
  products: HouseholdProduct[];
  actions: ProductActionLog[];
  reminderStates: ReminderStateRecord[];
}> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    return {
      products: [...activeSandbox.householdProducts].sort((a, b) =>
        a.expiryDate.localeCompare(b.expiryDate)
      ),
      actions: [...activeSandbox.householdActions].slice(0, 40),
      reminderStates: [...activeSandbox.householdReminderStates],
    };
  }

  try {
    const [prodSnap, actSnap, remSnap] = await Promise.all([
      getDocs(collection(db, 'users', uid, 'householdProducts')),
      getDocs(
        query(
          collection(db, 'users', uid, 'productActions'),
          where('mode', '==', 'household'),
          limit(40)
        )
      ),
      getDocs(
        query(collection(db, 'users', uid, 'reminderStates'), where('mode', '==', 'household'))
      ),
    ]);

    const products: HouseholdProduct[] = prodSnap.docs
      .map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          userId: String(d.userId ?? uid),
          name: String(d.name),
          quantity: Number(d.quantity),
          unit: String(d.unit),
          purchaseDate: String(d.purchaseDate),
          expiryDate: String(d.expiryDate),
          category: String(d.category),
          notes: String(d.notes ?? ''),
          imageUrl: d.imageUrl ? String(d.imageUrl) : null,
          reminderDays: d.reminderDays === null || d.reminderDays === undefined ? null : Number(d.reminderDays),
          isDemo: Boolean(d.isDemo),
          createdAt: toIsoString(d.createdAt),
          updatedAt: toIsoString(d.updatedAt),
        };
      })
      .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));

    const actions: ProductActionLog[] = actSnap.docs
      .map((docSnap) => mapActionDoc(docSnap.id, uid, docSnap.data()))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    const reminderStates: ReminderStateRecord[] = remSnap.docs.map((docSnap) =>
      mapReminderStateDoc(docSnap.id, uid, docSnap.data())
    );

    return { products, actions, reminderStates };
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, `users/${uid}/householdProducts`);
  }
}

export async function createHouseholdProduct(
  uid: string,
  input: {
    name: string;
    quantity: number;
    unit: string;
    purchaseDate: string;
    expiryDate: string;
    category: string;
    notes: string;
    imageUrl: string | null;
    reminderDays: number | null;
  }
): Promise<HouseholdProduct> {
  const cleanName = clampString(input.name, 140);
  const qty = Number(input.quantity);
  if (!cleanName) throw new Error('Product name is required.');
  if (!Number.isFinite(qty) || qty < 0) throw new Error('Quantity must be zero or greater.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.purchaseDate)) throw new Error('Valid purchase date is required.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.expiryDate)) throw new Error('Valid expiry date is required.');

  const cleanUnit = clampString(input.unit || 'pcs', 32) || 'pcs';
  const cleanCat = clampString(input.category || 'Pantry', 64) || 'Pantry';
  const cleanNotes = clampString(input.notes || '', 1000);
  const cleanImg = validateHttpsImageUrl(input.imageUrl);
  const cleanRem =
    input.reminderDays === null || input.reminderDays === undefined
      ? null
      : Math.max(0, Math.min(60, Math.round(Number(input.reminderDays))));

  const productId = makeDocId('hp');

  if (activeSandbox && uid === activeSandbox.user.uid) {
    const ts = new Date().toISOString();
    const item: HouseholdProduct = {
      id: productId,
      userId: uid,
      name: cleanName,
      quantity: qty,
      unit: cleanUnit,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      category: cleanCat,
      notes: cleanNotes,
      imageUrl: cleanImg,
      reminderDays: cleanRem,
      isDemo: false,
      createdAt: ts,
      updatedAt: ts,
    };
    activeSandbox.householdProducts.unshift(item);
    activeSandbox.householdActions.unshift({
      id: makeDocId('ha'),
      userId: uid,
      mode: 'household',
      productId,
      batchId: null,
      productName: cleanName,
      actionType: 'added',
      quantityDelta: qty,
      unit: cleanUnit,
      note: 'Added to household pantry',
      createdAt: ts,
    });
    return item;
  }

  const prodPath = `users/${uid}/householdProducts/${productId}`;
  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'users', uid, 'householdProducts', productId), {
      userId: uid,
      name: cleanName,
      quantity: qty,
      unit: cleanUnit,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      category: cleanCat,
      notes: cleanNotes,
      imageUrl: cleanImg,
      reminderDays: cleanRem,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    const actionId = makeDocId('act');
    batch.set(doc(db, 'users', uid, 'productActions', actionId), {
      userId: uid,
      mode: 'household',
      productId,
      batchId: null,
      productName: clampString(cleanName, 220),
      actionType: 'added',
      quantityDelta: qty,
      unit: cleanUnit,
      note: 'Added to household pantry',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
    const snap = await getDoc(doc(db, 'users', uid, 'householdProducts', productId));
    const d = snap.data() as Record<string, unknown>;
    return {
      id: productId,
      userId: uid,
      name: String(d.name),
      quantity: Number(d.quantity),
      unit: String(d.unit),
      purchaseDate: String(d.purchaseDate),
      expiryDate: String(d.expiryDate),
      category: String(d.category),
      notes: String(d.notes ?? ''),
      imageUrl: d.imageUrl ? String(d.imageUrl) : null,
      reminderDays: d.reminderDays === null || d.reminderDays === undefined ? null : Number(d.reminderDays),
      isDemo: Boolean(d.isDemo),
      createdAt: toIsoString(d.createdAt),
      updatedAt: toIsoString(d.updatedAt),
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, prodPath);
  }
}

export async function updateHouseholdProduct(
  uid: string,
  id: string,
  input: Partial<{
    name: string;
    quantity: number;
    unit: string;
    purchaseDate: string;
    expiryDate: string;
    category: string;
    notes: string;
    imageUrl: string | null;
    reminderDays: number | null;
  }>
): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    const idx = activeSandbox.householdProducts.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error('Product not found.');
    const cur = activeSandbox.householdProducts[idx];
    const updated: HouseholdProduct = {
      ...cur,
      ...input,
      updatedAt: new Date().toISOString(),
    };
    activeSandbox.householdProducts[idx] = updated;
    activeSandbox.householdActions.unshift({
      id: makeDocId('ha'),
      userId: uid,
      mode: 'household',
      productId: id,
      batchId: null,
      productName: updated.name,
      actionType: 'updated',
      quantityDelta: 0,
      unit: updated.unit,
      note: 'Updated product details',
      createdAt: new Date().toISOString(),
    });
    return;
  }

  const path = `users/${uid}/householdProducts/${id}`;
  try {
    const existingSnap = await getDoc(doc(db, 'users', uid, 'householdProducts', id));
    if (!existingSnap.exists()) throw new Error('Product not found.');
    const existing = existingSnap.data();

    const cleanName = input.name !== undefined ? clampString(input.name, 140) || String(existing.name) : String(existing.name);
    const cleanUnit = input.unit !== undefined ? clampString(input.unit, 32) || String(existing.unit) : String(existing.unit);

    const batch = writeBatch(db);
    batch.update(doc(db, 'users', uid, 'householdProducts', id), {
      name: cleanName,
      quantity:
        input.quantity !== undefined && Number.isFinite(Number(input.quantity)) && Number(input.quantity) >= 0
          ? Number(input.quantity)
          : Number(existing.quantity),
      unit: cleanUnit,
      purchaseDate:
        input.purchaseDate && /^\d{4}-\d{2}-\d{2}$/.test(input.purchaseDate)
          ? input.purchaseDate
          : String(existing.purchaseDate),
      expiryDate:
        input.expiryDate && /^\d{4}-\d{2}-\d{2}$/.test(input.expiryDate)
          ? input.expiryDate
          : String(existing.expiryDate),
      category:
        input.category !== undefined ? clampString(input.category, 64) || String(existing.category) : String(existing.category),
      notes: input.notes !== undefined ? clampString(input.notes, 1000) : String(existing.notes ?? ''),
      imageUrl: input.imageUrl !== undefined ? validateHttpsImageUrl(input.imageUrl) : existing.imageUrl ?? null,
      reminderDays:
        input.reminderDays === undefined
          ? existing.reminderDays ?? null
          : input.reminderDays === null
          ? null
          : Math.max(0, Math.min(60, Math.round(Number(input.reminderDays)))),
      updatedAt: serverTimestamp(),
    });
    const actionId = makeDocId('act');
    batch.set(doc(db, 'users', uid, 'productActions', actionId), {
      userId: uid,
      mode: 'household',
      productId: id,
      batchId: null,
      productName: clampString(cleanName, 220),
      actionType: 'updated',
      quantityDelta: 0,
      unit: cleanUnit,
      note: 'Updated product details',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function logHouseholdAction(
  uid: string,
  id: string,
  actionType: 'used' | 'wasted',
  requestedQty?: number,
  note?: string
): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    const idx = activeSandbox.householdProducts.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error('Product not found.');
    const cur = activeSandbox.householdProducts[idx];
    const req = requestedQty ?? cur.quantity;
    if (!Number.isFinite(req) || req <= 0) throw new Error('Action quantity must be greater than zero.');
    const deduct = Math.min(cur.quantity, req);
    const remaining = Math.max(0, Number((cur.quantity - deduct).toFixed(3)));
    const ts = new Date().toISOString();
    activeSandbox.householdProducts[idx] = { ...cur, quantity: remaining, updatedAt: ts };
    activeSandbox.householdActions.unshift({
      id: makeDocId('ha'),
      userId: uid,
      mode: 'household',
      productId: id,
      batchId: null,
      productName: cur.name,
      actionType,
      quantityDelta: deduct,
      unit: cur.unit,
      note: note?.trim() || (actionType === 'used' ? 'Marked as used' : 'Marked as wasted'),
      createdAt: ts,
    });
    return;
  }

  const path = `users/${uid}/householdProducts/${id}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'householdProducts', id));
    if (!snap.exists()) throw new Error('Product not found.');
    const cur = snap.data();
    const currentQty = Number(cur.quantity);
    const req = requestedQty !== undefined ? Number(requestedQty) : currentQty;
    if (!Number.isFinite(req) || req <= 0) {
      throw new Error('Action quantity must be greater than zero.');
    }
    const deduct = Math.min(currentQty, req);
    const remaining = Math.max(0, Number((currentQty - deduct).toFixed(3)));
    const cleanNote = clampString(
      note || (actionType === 'used' ? 'Marked as used' : 'Marked as wasted'),
      500
    );

    const batch = writeBatch(db);
    batch.update(doc(db, 'users', uid, 'householdProducts', id), {
      quantity: remaining,
      updatedAt: serverTimestamp(),
    });
    const actionId = makeDocId('act');
    batch.set(doc(db, 'users', uid, 'productActions', actionId), {
      userId: uid,
      mode: 'household',
      productId: id,
      batchId: null,
      productName: clampString(String(cur.name), 220),
      actionType,
      quantityDelta: deduct,
      unit: clampString(String(cur.unit), 32),
      note: cleanNote,
      createdAt: serverTimestamp(),
    });

    if (remaining === 0) {
      const remId = `household_product_${id}`;
      const remRef = doc(db, 'users', uid, 'reminderStates', remId);
      const remSnap = await getDoc(remRef);
      if (remSnap.exists()) {
        batch.update(remRef, {
          status: 'resolved',
          snoozedUntil: null,
          resolvedAt: new Date().toISOString(),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(remRef, {
          userId: uid,
          mode: 'household',
          targetType: 'household_product',
          targetId: id,
          status: 'resolved',
          snoozedUntil: null,
          resolvedAt: new Date().toISOString(),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    }
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteHouseholdProduct(uid: string, id: string): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    const target = activeSandbox.householdProducts.find((p) => p.id === id);
    if (!target) throw new Error('Product not found.');
    activeSandbox.householdProducts = activeSandbox.householdProducts.filter((p) => p.id !== id);
    activeSandbox.householdActions.unshift({
      id: makeDocId('ha'),
      userId: uid,
      mode: 'household',
      productId: null,
      batchId: null,
      productName: target.name,
      actionType: 'deleted',
      quantityDelta: target.quantity,
      unit: target.unit,
      note: 'Removed from pantry',
      createdAt: new Date().toISOString(),
    });
    return;
  }

  const path = `users/${uid}/householdProducts/${id}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'householdProducts', id));
    if (!snap.exists()) throw new Error('Product not found.');
    const cur = snap.data();

    const batch = writeBatch(db);
    batch.delete(doc(db, 'users', uid, 'householdProducts', id));
    const remId = `household_product_${id}`;
    batch.delete(doc(db, 'users', uid, 'reminderStates', remId));
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'household',
      productId: null,
      batchId: null,
      productName: clampString(String(cur.name), 220),
      actionType: 'deleted',
      quantityDelta: Number(cur.quantity),
      unit: clampString(String(cur.unit), 32),
      note: 'Removed from pantry',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ---------------- SUPERMARKET DATA & MUTATIONS ----------------

export async function ensureDefaultCategories(uid: string): Promise<SupermarketCategory[]> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    return activeSandbox.supermarketCategories;
  }

  const colRef = collection(db, 'users', uid, 'supermarketCategories');
  try {
    const snap = await getDocs(colRef);
    const existingNames = new Set(snap.docs.map((d) => String(d.data().name).toLowerCase()));
    const missing = DEFAULT_SUPERMARKET_CATEGORIES.filter(
      (name) => !existingNames.has(name.toLowerCase())
    );

    if (missing.length > 0) {
      const batch = writeBatch(db);
      for (const name of missing) {
        const catId = `cat_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
        batch.set(doc(db, 'users', uid, 'supermarketCategories', catId), {
          userId: uid,
          name,
          isDefault: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
      const refreshed = await getDocs(colRef);
      return refreshed.docs.map((d) => mapCategoryDoc(d.id, uid, d.data()));
    }
    return snap.docs.map((d) => mapCategoryDoc(d.id, uid, d.data()));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, `users/${uid}/supermarketCategories`);
  }
}

export async function fetchSupermarketData(uid: string): Promise<{
  categories: SupermarketCategory[];
  products: SupermarketProduct[];
  batches: SupermarketBatch[];
  actions: ProductActionLog[];
  reminderStates: ReminderStateRecord[];
}> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    return {
      categories: [...activeSandbox.supermarketCategories],
      products: activeSandbox.supermarketProducts.map((p) => ({
        ...p,
        batches: activeSandbox!.supermarketBatches.filter((b) => b.productId === p.id),
      })),
      batches: [...activeSandbox.supermarketBatches].sort((a, b) =>
        a.expiryDate.localeCompare(b.expiryDate)
      ),
      actions: [...activeSandbox.supermarketActions].slice(0, 50),
      reminderStates: [...activeSandbox.supermarketReminderStates],
    };
  }

  try {
    const categories = (await ensureDefaultCategories(uid)).sort((a, b) => {
      if (a.isDefault !== b.isDefault) return a.isDefault ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    const catMap = new Map(categories.map((c) => [c.id, c.name]));

    const [prodSnap, batchSnap, actSnap, remSnap] = await Promise.all([
      getDocs(collection(db, 'users', uid, 'supermarketProducts')),
      getDocs(collection(db, 'users', uid, 'supermarketBatches')),
      getDocs(
        query(
          collection(db, 'users', uid, 'productActions'),
          where('mode', '==', 'supermarket'),
          limit(50)
        )
      ),
      getDocs(
        query(collection(db, 'users', uid, 'reminderStates'), where('mode', '==', 'supermarket'))
      ),
    ]);

    const productMetaMap = new Map<
      string,
      { name: string; unit: string; categoryName: string }
    >();
    const rawProducts = prodSnap.docs.map((d) => {
      const x = d.data();
      const catId = String(x.categoryId);
      const categoryName = catMap.get(catId) ?? String(x.categoryName ?? 'Uncategorized');
      productMetaMap.set(d.id, {
        name: String(x.name),
        unit: String(x.unit),
        categoryName,
      });
      return { id: d.id, x, categoryName };
    });

    const batchesByProduct = new Map<string, SupermarketBatch[]>();
    const allBatches: SupermarketBatch[] = batchSnap.docs
      .map((d) => {
        const x = d.data();
        const productId = String(x.productId);
        const meta = productMetaMap.get(productId);
        const mapped: SupermarketBatch = {
          id: d.id,
          userId: uid,
          productId,
          productName: meta?.name ?? '',
          productUnit: meta?.unit ?? '',
          categoryName: meta?.categoryName ?? '',
          batchNumber: String(x.batchNumber),
          initialQuantity: Number(x.initialQuantity),
          remainingQuantity: Number(x.remainingQuantity),
          purchaseDate: String(x.purchaseDate),
          expiryDate: String(x.expiryDate),
          notes: String(x.notes ?? ''),
          isDemo: Boolean(x.isDemo),
          createdAt: toIsoString(x.createdAt),
          updatedAt: toIsoString(x.updatedAt),
        };
        const arr = batchesByProduct.get(productId) ?? [];
        arr.push(mapped);
        batchesByProduct.set(productId, arr);
        return mapped;
      })
      .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));

    const products: SupermarketProduct[] = rawProducts
      .map(({ id, x, categoryName }) => ({
        id,
        userId: uid,
        name: String(x.name),
        categoryId: String(x.categoryId),
        categoryName,
        unit: String(x.unit),
        lowStockThreshold: Number(x.lowStockThreshold),
        notes: String(x.notes ?? ''),
        imageUrl: x.imageUrl ? String(x.imageUrl) : null,
        reminderDays:
          x.reminderDays === null || x.reminderDays === undefined ? null : Number(x.reminderDays),
        isDemo: Boolean(x.isDemo),
        createdAt: toIsoString(x.createdAt),
        updatedAt: toIsoString(x.updatedAt),
        batches: (batchesByProduct.get(id) ?? []).sort((a, b) =>
          a.expiryDate.localeCompare(b.expiryDate)
        ),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));

    const actions = actSnap.docs
      .map((d) => mapActionDoc(d.id, uid, d.data()))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    const reminderStates = remSnap.docs.map((d) => mapReminderStateDoc(d.id, uid, d.data()));

    return { categories, products, batches: allBatches, actions, reminderStates };
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, `users/${uid}/supermarketProducts`);
  }
}

export async function createCategory(uid: string, name: string): Promise<SupermarketCategory> {
  const cleanName = clampString(name, 64);
  if (cleanName.length < 2) throw new Error('Category name must be at least 2 characters.');

  if (activeSandbox && uid === activeSandbox.user.uid) {
    if (
      activeSandbox.supermarketCategories.some(
        (c) => c.name.toLowerCase() === cleanName.toLowerCase()
      )
    ) {
      throw new Error('A category with that name already exists.');
    }
    const cat: SupermarketCategory = {
      id: makeDocId('cat'),
      userId: uid,
      name: cleanName,
      isDefault: false,
      createdAt: new Date().toISOString(),
    };
    activeSandbox.supermarketCategories.push(cat);
    return cat;
  }

  try {
    const existing = await getDocs(collection(db, 'users', uid, 'supermarketCategories'));
    if (
      existing.docs.some((d) => String(d.data().name).toLowerCase() === cleanName.toLowerCase())
    ) {
      throw new Error('A category with that name already exists.');
    }
    const id = makeDocId('cat');
    await setDoc(doc(db, 'users', uid, 'supermarketCategories', id), {
      userId: uid,
      name: cleanName,
      isDefault: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return {
      id,
      userId: uid,
      name: cleanName,
      isDefault: false,
      createdAt: new Date().toISOString(),
    };
  } catch (err) {
    if (err instanceof Error && err.message.includes('already exists')) throw err;
    handleFirestoreError(err, OperationType.CREATE, `users/${uid}/supermarketCategories`);
  }
}

export async function renameCategory(uid: string, id: string, name: string): Promise<void> {
  const cleanName = clampString(name, 64);
  if (cleanName.length < 2) throw new Error('Category name must be at least 2 characters.');

  if (activeSandbox && uid === activeSandbox.user.uid) {
    if (
      activeSandbox.supermarketCategories.some(
        (c) => c.id !== id && c.name.toLowerCase() === cleanName.toLowerCase()
      )
    ) {
      throw new Error('Another category already uses that name.');
    }
    const target = activeSandbox.supermarketCategories.find((c) => c.id === id);
    if (!target) throw new Error('Category not found.');
    target.name = cleanName;
    activeSandbox.supermarketProducts.forEach((p) => {
      if (p.categoryId === id) p.categoryName = cleanName;
    });
    return;
  }

  try {
    const snap = await getDocs(collection(db, 'users', uid, 'supermarketCategories'));
    if (
      snap.docs.some(
        (d) => d.id !== id && String(d.data().name).toLowerCase() === cleanName.toLowerCase()
      )
    ) {
      throw new Error('Another category already uses that name.');
    }
    await updateDoc(doc(db, 'users', uid, 'supermarketCategories', id), {
      name: cleanName,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    if (err instanceof Error && err.message.includes('already uses')) throw err;
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}/supermarketCategories/${id}`);
  }
}

export async function deleteCategory(uid: string, id: string): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    if (activeSandbox.supermarketProducts.some((p) => p.categoryId === id)) {
      throw new Error('Cannot delete a category that still has products assigned to it.');
    }
    activeSandbox.supermarketCategories = activeSandbox.supermarketCategories.filter(
      (c) => c.id !== id
    );
    return;
  }

  try {
    const prods = await getDocs(
      query(
        collection(db, 'users', uid, 'supermarketProducts'),
        where('categoryId', '==', id),
        limit(1)
      )
    );
    if (!prods.empty) {
      throw new Error('Cannot delete a category that still has products assigned to it.');
    }
    await deleteDoc(doc(db, 'users', uid, 'supermarketCategories', id));
  } catch (err) {
    if (err instanceof Error && err.message.includes('Cannot delete')) throw err;
    handleFirestoreError(err, OperationType.DELETE, `users/${uid}/supermarketCategories/${id}`);
  }
}

export async function createSupermarketProduct(
  uid: string,
  input: {
    name: string;
    categoryId: string;
    unit: string;
    lowStockThreshold: number;
    notes: string;
    imageUrl: string | null;
    reminderDays: number | null;
    batchNumber: string;
    initialQuantity: number;
    purchaseDate: string;
    expiryDate: string;
    batchNotes: string;
  }
): Promise<{ productId: string; batchId: string }> {
  const cleanName = clampString(input.name, 140);
  const cleanBatch = clampString(input.batchNumber, 80);
  const qty = Number(input.initialQuantity);
  if (!cleanName) throw new Error('Product name is required.');
  if (!cleanBatch) throw new Error('Batch number is compulsory for supermarket products.');
  if (!Number.isFinite(qty) || qty <= 0) throw new Error('Initial batch quantity must be greater than zero.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.purchaseDate)) throw new Error('Valid purchase date is required.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.expiryDate)) throw new Error('Valid expiry date is required.');

  const cleanUnit = clampString(input.unit || 'units', 32) || 'units';
  const lowStock = Math.max(0, Number(input.lowStockThreshold) || 0);
  const cleanNotes = clampString(input.notes || '', 1000);
  const cleanBatchNotes = clampString(input.batchNotes || '', 1000);
  const cleanImg = validateHttpsImageUrl(input.imageUrl);
  const cleanRem =
    input.reminderDays === null || input.reminderDays === undefined
      ? null
      : Math.max(0, Math.min(60, Math.round(Number(input.reminderDays))));

  const productId = makeDocId('sp');
  const batchId = makeDocId('sb');

  if (activeSandbox && uid === activeSandbox.user.uid) {
    const cat = activeSandbox.supermarketCategories.find((c) => c.id === input.categoryId);
    if (!cat) throw new Error('Please select a valid category.');
    const ts = new Date().toISOString();
    const batchRecord: SupermarketBatch = {
      id: batchId,
      userId: uid,
      productId,
      productName: cleanName,
      productUnit: cleanUnit,
      categoryName: cat.name,
      batchNumber: cleanBatch,
      initialQuantity: qty,
      remainingQuantity: qty,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      notes: cleanBatchNotes,
      isDemo: false,
      createdAt: ts,
      updatedAt: ts,
    };
    activeSandbox.supermarketBatches.push(batchRecord);
    activeSandbox.supermarketProducts.push({
      id: productId,
      userId: uid,
      name: cleanName,
      categoryId: cat.id,
      categoryName: cat.name,
      unit: cleanUnit,
      lowStockThreshold: lowStock,
      notes: cleanNotes,
      imageUrl: cleanImg,
      reminderDays: cleanRem,
      isDemo: false,
      createdAt: ts,
      updatedAt: ts,
      batches: [batchRecord],
    });
    activeSandbox.supermarketActions.unshift({
      id: makeDocId('sa'),
      userId: uid,
      mode: 'supermarket',
      productId,
      batchId,
      productName: `${cleanName} (${cleanBatch})`,
      actionType: 'added',
      quantityDelta: qty,
      unit: cleanUnit,
      note: 'Created product with initial batch',
      createdAt: ts,
    });
    return { productId, batchId };
  }

  try {
    const catSnap = await getDoc(doc(db, 'users', uid, 'supermarketCategories', input.categoryId));
    if (!catSnap.exists()) throw new Error('Please select a valid category.');
    const categoryName = clampString(String(catSnap.data().name), 64);

    // Parent category exists; product write must commit before batch rule's exists(product) passes
    await setDoc(doc(db, 'users', uid, 'supermarketProducts', productId), {
      userId: uid,
      name: cleanName,
      categoryId: input.categoryId,
      categoryName,
      unit: cleanUnit,
      lowStockThreshold: lowStock,
      notes: cleanNotes,
      imageUrl: cleanImg,
      reminderDays: cleanRem,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    const batch = writeBatch(db);
    batch.set(doc(db, 'users', uid, 'supermarketBatches', batchId), {
      userId: uid,
      productId,
      batchNumber: cleanBatch,
      initialQuantity: qty,
      remainingQuantity: qty,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      notes: cleanBatchNotes,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'supermarket',
      productId,
      batchId,
      productName: clampString(`${cleanName} (${cleanBatch})`, 220),
      actionType: 'added',
      quantityDelta: qty,
      unit: cleanUnit,
      note: 'Created product with initial batch',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
    return { productId, batchId };
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${uid}/supermarketProducts/${productId}`);
  }
}

export async function updateSupermarketProduct(
  uid: string,
  id: string,
  input: Partial<{
    name: string;
    categoryId: string;
    unit: string;
    lowStockThreshold: number;
    notes: string;
    imageUrl: string | null;
    reminderDays: number | null;
  }>
): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    const idx = activeSandbox.supermarketProducts.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error('Product not found.');
    const cur = activeSandbox.supermarketProducts[idx];
    const cat = input.categoryId
      ? activeSandbox.supermarketCategories.find((c) => c.id === input.categoryId)
      : undefined;
    const updated: SupermarketProduct = {
      ...cur,
      ...input,
      categoryId: cat ? cat.id : cur.categoryId,
      categoryName: cat ? cat.name : cur.categoryName,
      updatedAt: new Date().toISOString(),
    };
    activeSandbox.supermarketProducts[idx] = updated;
    activeSandbox.supermarketBatches.forEach((b) => {
      if (b.productId === id) {
        b.productName = updated.name;
        b.productUnit = updated.unit;
        b.categoryName = updated.categoryName;
      }
    });
    return;
  }

  try {
    const existingSnap = await getDoc(doc(db, 'users', uid, 'supermarketProducts', id));
    if (!existingSnap.exists()) throw new Error('Product not found.');
    const existing = existingSnap.data();

    let categoryId = String(existing.categoryId);
    let categoryName = String(existing.categoryName);
    if (input.categoryId && input.categoryId !== categoryId) {
      const catSnap = await getDoc(doc(db, 'users', uid, 'supermarketCategories', input.categoryId));
      if (catSnap.exists()) {
        categoryId = catSnap.id;
        categoryName = clampString(String(catSnap.data().name), 64);
      }
    }

    const cleanName = input.name !== undefined ? clampString(input.name, 140) || String(existing.name) : String(existing.name);
    const cleanUnit = input.unit !== undefined ? clampString(input.unit, 32) || String(existing.unit) : String(existing.unit);

    const batch = writeBatch(db);
    batch.update(doc(db, 'users', uid, 'supermarketProducts', id), {
      name: cleanName,
      categoryId,
      categoryName,
      unit: cleanUnit,
      lowStockThreshold:
        input.lowStockThreshold !== undefined && Number.isFinite(Number(input.lowStockThreshold))
          ? Math.max(0, Number(input.lowStockThreshold))
          : Number(existing.lowStockThreshold),
      notes: input.notes !== undefined ? clampString(input.notes, 1000) : String(existing.notes ?? ''),
      imageUrl: input.imageUrl !== undefined ? validateHttpsImageUrl(input.imageUrl) : existing.imageUrl ?? null,
      reminderDays:
        input.reminderDays === undefined
          ? existing.reminderDays ?? null
          : input.reminderDays === null
          ? null
          : Math.max(0, Math.min(60, Math.round(Number(input.reminderDays)))),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'supermarket',
      productId: id,
      batchId: null,
      productName: clampString(cleanName, 220),
      actionType: 'updated',
      quantityDelta: 0,
      unit: cleanUnit,
      note: 'Updated product details',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}/supermarketProducts/${id}`);
  }
}

export async function deleteSupermarketProduct(uid: string, id: string): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    const cur = activeSandbox.supermarketProducts.find((p) => p.id === id);
    if (!cur) throw new Error('Product not found.');
    activeSandbox.supermarketProducts = activeSandbox.supermarketProducts.filter((p) => p.id !== id);
    activeSandbox.supermarketBatches = activeSandbox.supermarketBatches.filter(
      (b) => b.productId !== id
    );
    activeSandbox.supermarketActions.unshift({
      id: makeDocId('sa'),
      userId: uid,
      mode: 'supermarket',
      productId: null,
      batchId: null,
      productName: cur.name,
      actionType: 'deleted',
      quantityDelta: 0,
      unit: cur.unit,
      note: 'Deleted product and batches',
      createdAt: new Date().toISOString(),
    });
    return;
  }

  try {
    const prodSnap = await getDoc(doc(db, 'users', uid, 'supermarketProducts', id));
    if (!prodSnap.exists()) throw new Error('Product not found.');
    const cur = prodSnap.data();
    const batchesSnap = await getDocs(
      query(collection(db, 'users', uid, 'supermarketBatches'), where('productId', '==', id))
    );

    const batch = writeBatch(db);
    batchesSnap.docs.forEach((b) => {
      batch.delete(b.ref);
      batch.delete(doc(db, 'users', uid, 'reminderStates', `supermarket_batch_${b.id}`));
    });
    batch.delete(doc(db, 'users', uid, 'reminderStates', `low_stock_${id}`));
    batch.delete(doc(db, 'users', uid, 'supermarketProducts', id));
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'supermarket',
      productId: null,
      batchId: null,
      productName: clampString(String(cur.name), 220),
      actionType: 'deleted',
      quantityDelta: 0,
      unit: clampString(String(cur.unit), 32),
      note: 'Deleted product and batches',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${uid}/supermarketProducts/${id}`);
  }
}

export async function createSupermarketBatch(
  uid: string,
  input: {
    productId: string;
    batchNumber: string;
    initialQuantity: number;
    purchaseDate: string;
    expiryDate: string;
    notes: string;
  }
): Promise<string> {
  const cleanBatch = clampString(input.batchNumber, 80);
  const qty = Number(input.initialQuantity);
  if (!cleanBatch) throw new Error('Batch number is compulsory.');
  if (!Number.isFinite(qty) || qty <= 0) throw new Error('Initial quantity must be greater than zero.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.purchaseDate)) throw new Error('Valid purchase date is required.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.expiryDate)) throw new Error('Valid expiry date is required.');

  const batchId = makeDocId('sb');
  const cleanNotes = clampString(input.notes || '', 1000);

  if (activeSandbox && uid === activeSandbox.user.uid) {
    const prod = activeSandbox.supermarketProducts.find((p) => p.id === input.productId);
    if (!prod) throw new Error('Selected product was not found.');
    const ts = new Date().toISOString();
    const record: SupermarketBatch = {
      id: batchId,
      userId: uid,
      productId: prod.id,
      productName: prod.name,
      productUnit: prod.unit,
      categoryName: prod.categoryName,
      batchNumber: cleanBatch,
      initialQuantity: qty,
      remainingQuantity: qty,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      notes: cleanNotes,
      isDemo: false,
      createdAt: ts,
      updatedAt: ts,
    };
    activeSandbox.supermarketBatches.push(record);
    prod.batches.push(record);
    activeSandbox.supermarketActions.unshift({
      id: makeDocId('sa'),
      userId: uid,
      mode: 'supermarket',
      productId: prod.id,
      batchId,
      productName: `${prod.name} (${cleanBatch})`,
      actionType: 'restocked',
      quantityDelta: qty,
      unit: prod.unit,
      note: 'Added separate batch record',
      createdAt: ts,
    });
    return batchId;
  }

  try {
    const prodSnap = await getDoc(doc(db, 'users', uid, 'supermarketProducts', input.productId));
    if (!prodSnap.exists()) throw new Error('Selected product was not found.');
    const prod = prodSnap.data();

    const batch = writeBatch(db);
    batch.set(doc(db, 'users', uid, 'supermarketBatches', batchId), {
      userId: uid,
      productId: input.productId,
      batchNumber: cleanBatch,
      initialQuantity: qty,
      remainingQuantity: qty,
      purchaseDate: input.purchaseDate,
      expiryDate: input.expiryDate,
      notes: cleanNotes,
      isDemo: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'supermarket',
      productId: input.productId,
      batchId,
      productName: clampString(`${String(prod.name)} (${cleanBatch})`, 220),
      actionType: 'restocked',
      quantityDelta: qty,
      unit: clampString(String(prod.unit), 32),
      note: 'Added separate batch record',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
    return batchId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${uid}/supermarketBatches/${batchId}`);
  }
}

export async function bulkImportSupermarketBatches(
  uid: string,
  rows: Array<{
    rowNumber: number;
    productId: string;
    batchNumber: string;
    initialQuantity: number;
    remainingQuantity: number;
    purchaseDate: string;
    expiryDate: string;
    notes: string;
  }>
): Promise<number> {
  if (!rows.length) throw new Error('At least one batch row is required for CSV import.');
  if (rows.length > 200) throw new Error('Please split CSV imports into 200 rows or fewer per upload.');

  if (activeSandbox && uid === activeSandbox.user.uid) {
    for (const r of rows) {
      await createSupermarketBatch(uid, {
        productId: r.productId,
        batchNumber: r.batchNumber,
        initialQuantity: r.initialQuantity,
        purchaseDate: r.purchaseDate,
        expiryDate: r.expiryDate,
        notes: r.notes,
      });
      if (r.remainingQuantity !== r.initialQuantity) {
        const added = activeSandbox.supermarketBatches[activeSandbox.supermarketBatches.length - 1];
        if (added) added.remainingQuantity = r.remainingQuantity;
      }
    }
    return rows.length;
  }

  try {
    const prodsSnap = await getDocs(collection(db, 'users', uid, 'supermarketProducts'));
    const prodMap = new Map(prodsSnap.docs.map((d) => [d.id, d.data()]));

    const batch = writeBatch(db);
    for (const r of rows) {
      const prod = prodMap.get(r.productId);
      if (!prod) {
        throw new Error(`Row ${r.rowNumber}: Referenced supermarket product was not found.`);
      }
      const batchId = makeDocId('sb');
      const cleanBatch = clampString(r.batchNumber, 80);
      batch.set(doc(db, 'users', uid, 'supermarketBatches', batchId), {
        userId: uid,
        productId: r.productId,
        batchNumber: cleanBatch,
        initialQuantity: r.initialQuantity,
        remainingQuantity: r.remainingQuantity,
        purchaseDate: r.purchaseDate,
        expiryDate: r.expiryDate,
        notes: clampString(r.notes || '', 1000),
        isDemo: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
        userId: uid,
        mode: 'supermarket',
        productId: r.productId,
        batchId,
        productName: clampString(`${String(prod.name)} (${cleanBatch})`, 220),
        actionType: 'restocked',
        quantityDelta: r.remainingQuantity,
        unit: clampString(String(prod.unit), 32),
        note: 'Bulk CSV batch import',
        createdAt: serverTimestamp(),
      });
    }
    await batch.commit();
    return rows.length;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${uid}/supermarketBatches`);
  }
}

export async function logBatchAction(
  uid: string,
  batchId: string,
  actionType: 'sold' | 'wasted' | 'restocked',
  quantity: number,
  note?: string
): Promise<void> {
  if (!Number.isFinite(quantity) || quantity <= 0) {
    throw new Error('Quantity must be greater than zero.');
  }

  if (activeSandbox && uid === activeSandbox.user.uid) {
    const b = activeSandbox.supermarketBatches.find((x) => x.id === batchId);
    if (!b) throw new Error('Batch not found.');
    let newRem = b.remainingQuantity;
    let newInit = b.initialQuantity;
    let delta = quantity;
    if (actionType === 'restocked') {
      newRem = Number((b.remainingQuantity + quantity).toFixed(3));
      newInit = Math.max(newInit, newRem);
    } else {
      delta = Math.min(b.remainingQuantity, quantity);
      newRem = Math.max(0, Number((b.remainingQuantity - delta).toFixed(3)));
    }
    b.remainingQuantity = newRem;
    b.initialQuantity = newInit;
    b.updatedAt = new Date().toISOString();
    activeSandbox.supermarketActions.unshift({
      id: makeDocId('sa'),
      userId: uid,
      mode: 'supermarket',
      productId: b.productId,
      batchId,
      productName: `${b.productName ?? ''} (${b.batchNumber})`,
      actionType,
      quantityDelta: delta,
      unit: b.productUnit ?? 'units',
      note:
        note?.trim() ||
        (actionType === 'sold'
          ? 'Batch stock sold'
          : actionType === 'wasted'
          ? 'Batch stock marked wasted'
          : 'Batch stock adjusted'),
      createdAt: new Date().toISOString(),
    });
    return;
  }

  const path = `users/${uid}/supermarketBatches/${batchId}`;
  try {
    const bSnap = await getDoc(doc(db, 'users', uid, 'supermarketBatches', batchId));
    if (!bSnap.exists()) throw new Error('Batch not found.');
    const cur = bSnap.data();
    const prodSnap = await getDoc(
      doc(db, 'users', uid, 'supermarketProducts', String(cur.productId))
    );
    const prod = prodSnap.exists() ? prodSnap.data() : { name: 'Product', unit: 'units' };

    const curRem = Number(cur.remainingQuantity);
    let newRem = curRem;
    let newInit = Number(cur.initialQuantity);
    let delta = quantity;

    if (actionType === 'restocked') {
      newRem = Number((curRem + quantity).toFixed(3));
      newInit = Math.max(newInit, newRem);
    } else {
      delta = Math.min(curRem, quantity);
      newRem = Math.max(0, Number((curRem - delta).toFixed(3)));
    }

    const cleanNote = clampString(
      note ||
        (actionType === 'sold'
          ? 'Batch stock sold'
          : actionType === 'wasted'
          ? 'Batch stock marked wasted'
          : 'Batch stock adjusted'),
      500
    );

    const batch = writeBatch(db);
    batch.update(doc(db, 'users', uid, 'supermarketBatches', batchId), {
      initialQuantity: newInit,
      remainingQuantity: newRem,
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', uid, 'productActions', makeDocId('act')), {
      userId: uid,
      mode: 'supermarket',
      productId: String(cur.productId),
      batchId,
      productName: clampString(`${String(prod.name)} (${String(cur.batchNumber)})`, 220),
      actionType,
      quantityDelta: delta,
      unit: clampString(String(prod.unit), 32),
      note: cleanNote,
      createdAt: serverTimestamp(),
    });

    if (newRem === 0) {
      const remId = `supermarket_batch_${batchId}`;
      const remRef = doc(db, 'users', uid, 'reminderStates', remId);
      const remSnap = await getDoc(remRef);
      if (remSnap.exists()) {
        batch.update(remRef, {
          status: 'resolved',
          snoozedUntil: null,
          resolvedAt: new Date().toISOString(),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(remRef, {
          userId: uid,
          mode: 'supermarket',
          targetType: 'supermarket_batch',
          targetId: batchId,
          status: 'resolved',
          snoozedUntil: null,
          resolvedAt: new Date().toISOString(),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    }
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ---------------- REMINDERS, NOTIFICATIONS & FCM TOKENS ----------------

export async function setReminderState(
  uid: string,
  input: {
    mode: OperatingMode;
    targetType: 'household_product' | 'supermarket_batch' | 'low_stock';
    targetId: string;
    status: ReminderStateStatus;
    snoozeDays?: number;
  }
): Promise<void> {
  let snoozedUntil: string | null = null;
  let resolvedAt: string | null = null;
  if (input.status === 'snoozed') {
    const days = Math.max(1, Math.min(30, input.snoozeDays ?? 1));
    snoozedUntil = new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);
  } else if (input.status === 'resolved') {
    resolvedAt = new Date().toISOString();
  }

  const stateId = `${input.targetType}_${input.targetId}`;

  if (activeSandbox && uid === activeSandbox.user.uid) {
    const list =
      input.mode === 'household'
        ? activeSandbox.householdReminderStates
        : activeSandbox.supermarketReminderStates;
    const idx = list.findIndex((r) => r.id === stateId);
    const rec: ReminderStateRecord = {
      id: stateId,
      userId: uid,
      mode: input.mode,
      targetType: input.targetType,
      targetId: input.targetId,
      status: input.status,
      snoozedUntil,
      resolvedAt,
      updatedAt: new Date().toISOString(),
    };
    if (idx === -1) list.push(rec);
    else list[idx] = rec;
    return;
  }

  const path = `users/${uid}/reminderStates/${stateId}`;
  try {
    const refDoc = doc(db, 'users', uid, 'reminderStates', stateId);
    const snap = await getDoc(refDoc);
    if (snap.exists()) {
      await updateDoc(refDoc, {
        status: input.status,
        snoozedUntil,
        resolvedAt,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(refDoc, {
        userId: uid,
        mode: input.mode,
        targetType: input.targetType,
        targetId: input.targetId,
        status: input.status,
        snoozedUntil,
        resolvedAt,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function fetchNotifications(uid: string): Promise<NotificationHistoryItem[]> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    return [...activeSandbox.notifications];
  }

  try {
    const snap = await getDocs(
      query(
        collection(db, 'users', uid, 'notifications'),
        orderBy('createdAt', 'desc'),
        limit(50)
      )
    );
    return snap.docs.map((d) => {
      const x = d.data();
      return {
        id: d.id,
        userId: uid,
        mode: x.mode === 'supermarket' ? 'supermarket' : 'household',
        title: String(x.title),
        message: String(x.message),
        channel: x.channel === 'fcm' ? 'fcm' : x.channel === 'browser' ? 'browser' : 'in_app',
        isRead: Boolean(x.isRead),
        createdAt: toIsoString(x.createdAt),
      };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, `users/${uid}/notifications`);
  }
}

export async function createNotificationRecord(
  uid: string,
  input: {
    mode: OperatingMode;
    title: string;
    message: string;
    channel: 'in_app' | 'browser' | 'fcm';
  }
): Promise<void> {
  const cleanTitle = clampString(input.title, 160);
  const cleanMsg = clampString(input.message, 1000);
  if (!cleanTitle || !cleanMsg) return;

  if (activeSandbox && uid === activeSandbox.user.uid) {
    activeSandbox.notifications.unshift({
      id: makeDocId('ntf'),
      userId: uid,
      mode: input.mode,
      title: cleanTitle,
      message: cleanMsg,
      channel: input.channel,
      isRead: false,
      createdAt: new Date().toISOString(),
    });
    return;
  }

  const id = makeDocId('ntf');
  try {
    await setDoc(doc(db, 'users', uid, 'notifications', id), {
      userId: uid,
      mode: input.mode,
      title: cleanTitle,
      message: cleanMsg,
      channel: input.channel,
      isRead: false,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${uid}/notifications/${id}`);
  }
}

export async function markAllNotificationsRead(uid: string): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    activeSandbox.notifications.forEach((n) => {
      n.isRead = true;
    });
    return;
  }

  try {
    const snap = await getDocs(collection(db, 'users', uid, 'notifications'));
    const batch = writeBatch(db);
    snap.docs.forEach((d) => {
      if (d.data().isRead === false) {
        batch.update(d.ref, { isRead: true });
      }
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}/notifications`);
  }
}

export async function clearNotifications(uid: string): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    activeSandbox.notifications = [];
    return;
  }

  try {
    const snap = await getDocs(collection(db, 'users', uid, 'notifications'));
    const batch = writeBatch(db);
    snap.docs.forEach((d) => batch.delete(d.ref));
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${uid}/notifications`);
  }
}

export async function saveFcmToken(uid: string, token: string, platform = 'web-pwa'): Promise<void> {
  if (!uid || activeSandbox) return;
  // Normalize deterministic safe document ID for this token
  const rawSuffix = token.replace(/[^a-zA-Z0-9_-]/g, '').slice(-32);
  const tokenId = `fcm_${rawSuffix || 'device'}`;
  const path = `users/${uid}/fcmTokens/${tokenId}`;

  try {
    const tokenRef = doc(db, 'users', uid, 'fcmTokens', tokenId);
    const snap = await getDoc(tokenRef);
    if (snap.exists()) {
      await updateDoc(tokenRef, {
        token: clampString(token, 512),
        platform: clampString(platform, 64),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(tokenRef, {
        userId: uid,
        token: clampString(token, 512),
        platform: clampString(platform, 64),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

// ---------------- DEMONSTRATION DATA RESET / SEEDING ----------------

export async function resetDemoData(
  uid: string,
  action: 'reset' | 'clear',
  scope: 'household' | 'supermarket' | 'both' = 'both'
): Promise<void> {
  if (activeSandbox && uid === activeSandbox.user.uid) {
    if (action === 'clear') {
      if (scope === 'household' || scope === 'both') {
        activeSandbox.householdProducts = activeSandbox.householdProducts.filter((p) => !p.isDemo);
      }
      if (scope === 'supermarket' || scope === 'both') {
        activeSandbox.supermarketBatches = activeSandbox.supermarketBatches.filter((b) => !b.isDemo);
        activeSandbox.supermarketProducts = activeSandbox.supermarketProducts.filter(
          (p) => !p.isDemo
        );
      }
    } else {
      const fresh = createDemoSandboxStore(activeSandbox.user.preferredMode);
      if (scope === 'household' || scope === 'both') {
        activeSandbox.householdProducts = [
          ...activeSandbox.householdProducts.filter((p) => !p.isDemo),
          ...fresh.householdProducts,
        ];
      }
      if (scope === 'supermarket' || scope === 'both') {
        activeSandbox.supermarketBatches = [
          ...activeSandbox.supermarketBatches.filter((b) => !b.isDemo),
          ...fresh.supermarketBatches,
        ];
        activeSandbox.supermarketProducts = [
          ...activeSandbox.supermarketProducts.filter((p) => !p.isDemo),
          ...fresh.supermarketProducts,
        ];
      }
    }
    return;
  }

  if (action === 'clear') {
    await clearCloudDemonstrationData(uid, scope);
  } else {
    await seedCloudDemonstrationData(uid, scope);
  }
}

async function clearCloudDemonstrationData(
  uid: string,
  scope: 'household' | 'supermarket' | 'both'
): Promise<void> {
  try {
    const batch = writeBatch(db);
    if (scope === 'household' || scope === 'both') {
      const hSnap = await getDocs(
        query(collection(db, 'users', uid, 'householdProducts'), where('isDemo', '==', true))
      );
      hSnap.docs.forEach((d) => batch.delete(d.ref));
    }
    if (scope === 'supermarket' || scope === 'both') {
      const bSnap = await getDocs(
        query(collection(db, 'users', uid, 'supermarketBatches'), where('isDemo', '==', true))
      );
      bSnap.docs.forEach((d) => batch.delete(d.ref));
      const pSnap = await getDocs(
        query(collection(db, 'users', uid, 'supermarketProducts'), where('isDemo', '==', true))
      );
      pSnap.docs.forEach((d) => batch.delete(d.ref));
    }
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${uid}`);
  }
}

async function seedCloudDemonstrationData(
  uid: string,
  scope: 'household' | 'supermarket' | 'both'
): Promise<void> {
  await clearCloudDemonstrationData(uid, scope);
  const categories = await ensureDefaultCategories(uid);
  const today = getTodayIso();
  const seedTemplate = createDemoSandboxStore('household');

  try {
    if (scope === 'household' || scope === 'both') {
      const hBatch = writeBatch(db);
      for (const item of seedTemplate.householdProducts) {
        const pid = makeDocId('hp');
        hBatch.set(doc(db, 'users', uid, 'householdProducts', pid), {
          userId: uid,
          name: item.name,
          quantity: item.quantity,
          unit: item.unit,
          purchaseDate: item.purchaseDate,
          expiryDate: item.expiryDate,
          category: item.category,
          notes: item.notes,
          imageUrl: null,
          reminderDays: null,
          isDemo: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await hBatch.commit();
    }

    if (scope === 'supermarket' || scope === 'both') {
      // Products must be committed first so supermarketBatches create rules pass exists(product)
      const pBatch = writeBatch(db);
      const idMapping = new Map<string, string>();

      for (const prod of seedTemplate.supermarketProducts) {
        const matchedCat =
          categories.find((c) => c.name === prod.categoryName) ?? categories[0];
        const pid = makeDocId('sp');
        idMapping.set(prod.id, pid);
        pBatch.set(doc(db, 'users', uid, 'supermarketProducts', pid), {
          userId: uid,
          name: prod.name,
          categoryId: matchedCat.id,
          categoryName: matchedCat.name,
          unit: prod.unit,
          lowStockThreshold: prod.lowStockThreshold,
          notes: prod.notes,
          imageUrl: null,
          reminderDays: null,
          isDemo: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await pBatch.commit();

      const bBatch = writeBatch(db);
      for (const b of seedTemplate.supermarketBatches) {
        const newProdId = idMapping.get(b.productId);
        if (!newProdId) continue;
        const bid = makeDocId('sb');
        bBatch.set(doc(db, 'users', uid, 'supermarketBatches', bid), {
          userId: uid,
          productId: newProdId,
          batchNumber: b.batchNumber,
          initialQuantity: b.initialQuantity,
          remainingQuantity: b.remainingQuantity,
          purchaseDate: b.purchaseDate || today,
          expiryDate: b.expiryDate || addDaysIso(today, 5),
          notes: b.notes,
          isDemo: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await bBatch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${uid}`);
  }
}

function mapActionDoc(id: string, uid: string, d: Record<string, unknown>): ProductActionLog {
  return {
    id,
    userId: uid,
    mode: d.mode === 'supermarket' ? 'supermarket' : 'household',
    productId: d.productId ? String(d.productId) : null,
    batchId: d.batchId ? String(d.batchId) : null,
    productName: String(d.productName),
    actionType: String(d.actionType) as ProductActionLog['actionType'],
    quantityDelta: Number(d.quantityDelta ?? 0),
    unit: String(d.unit ?? 'pcs'),
    note: String(d.note ?? ''),
    createdAt: toIsoString(d.createdAt),
  };
}

function mapReminderStateDoc(
  id: string,
  uid: string,
  d: Record<string, unknown>
): ReminderStateRecord {
  return {
    id,
    userId: uid,
    mode: d.mode === 'supermarket' ? 'supermarket' : 'household',
    targetType: String(d.targetType) as ReminderStateRecord['targetType'],
    targetId: String(d.targetId),
    status: String(d.status) as ReminderStateStatus,
    snoozedUntil: d.snoozedUntil ? String(d.snoozedUntil) : null,
    resolvedAt: d.resolvedAt ? String(d.resolvedAt) : null,
    updatedAt: toIsoString(d.updatedAt),
  };
}

function mapCategoryDoc(id: string, uid: string, d: Record<string, unknown>): SupermarketCategory {
  return {
    id,
    userId: uid,
    name: String(d.name),
    isDefault: Boolean(d.isDefault),
    createdAt: toIsoString(d.createdAt),
  };
}
