import type {
  HouseholdProduct,
  NotificationHistoryItem,
  OperatingMode,
  ProductActionLog,
  ReminderStateRecord,
  SupermarketBatch,
  SupermarketCategory,
  SupermarketProduct,
  UserProfile,
} from '../types/index.ts';
import { addDaysIso, getTodayIso } from '../utils/expiry.ts';

export const DEFAULT_SUPERMARKET_CATEGORIES = [
  'Dairy',
  'Beverages',
  'Snacks',
  'Bakery',
  'Staples & Grains',
  'Sauces & Condiments',
  'Canned & Preserved Foods',
  'Frozen Foods',
  'Ready-to-Eat & Instant Foods',
  'Confectionery',
  'Cooking Essentials',
];

export interface DemoSandboxStore {
  user: UserProfile;
  householdProducts: HouseholdProduct[];
  householdActions: ProductActionLog[];
  householdReminderStates: ReminderStateRecord[];
  supermarketCategories: SupermarketCategory[];
  supermarketProducts: SupermarketProduct[];
  supermarketBatches: SupermarketBatch[];
  supermarketActions: ProductActionLog[];
  supermarketReminderStates: ReminderStateRecord[];
  notifications: NotificationHistoryItem[];
}

function nowIso(): string {
  return new Date().toISOString();
}

export function createDemoSandboxStore(initialMode: OperatingMode = 'household'): DemoSandboxStore {
  const uid = 'demo-sandbox';
  const today = getTodayIso();
  const ts = nowIso();

  const user: UserProfile = {
    id: uid,
    uid,
    fullName: 'Aarav Patel (Demo)',
    email: 'demo@expiryalert.app',
    accountType: 'both',
    preferredMode: initialMode,
    profileImageUrl: null,
    theme: 'light',
    accentColor: '#2E6F4E',
    fontSize: 'medium',
    notificationsEnabled: true,
    defaultReminderDays: 5,
    reminderScheduleTime: '09:00',
    emailVerified: true,
    isDemoSession: true,
    createdAt: ts,
  };

  const householdSeeds = [
    {
      id: 'demo-hp-1',
      name: 'Whole Fresh Milk',
      quantity: 1,
      unit: 'L',
      purchaseDate: addDaysIso(today, -4),
      expiryDate: addDaysIso(today, 0),
      category: 'Dairy',
      notes: 'Keep refrigerated below 4°C.',
    },
    {
      id: 'demo-hp-2',
      name: 'Wholemeal Sandwich Bread',
      quantity: 1,
      unit: 'loaf',
      purchaseDate: addDaysIso(today, -3),
      expiryDate: addDaysIso(today, 2),
      category: 'Bakery',
      notes: 'Use for breakfast toast before weekend.',
    },
    {
      id: 'demo-hp-3',
      name: 'Greek Plain Yogurt',
      quantity: 2,
      unit: 'cups',
      purchaseDate: addDaysIso(today, -9),
      expiryDate: addDaysIso(today, -1),
      category: 'Dairy',
      notes: 'Opened earlier this week.',
    },
    {
      id: 'demo-hp-4',
      name: 'Oat & Honey Biscuits',
      quantity: 1,
      unit: 'pack',
      purchaseDate: addDaysIso(today, -12),
      expiryDate: addDaysIso(today, 24),
      category: 'Snacks',
      notes: 'Pantry upper shelf.',
    },
    {
      id: 'demo-hp-5',
      name: 'Cold-Pressed Orange Juice',
      quantity: 1,
      unit: 'bottle',
      purchaseDate: addDaysIso(today, -5),
      expiryDate: addDaysIso(today, 4),
      category: 'Beverages',
      notes: 'Chilled door shelf.',
    },
    {
      id: 'demo-hp-6',
      name: 'Rolled Oats Cereal',
      quantity: 750,
      unit: 'g',
      purchaseDate: addDaysIso(today, -15),
      expiryDate: addDaysIso(today, 45),
      category: 'Breakfast & Grains',
      notes: 'Stored in airtight jar.',
    },
  ];

  const householdProducts: HouseholdProduct[] = householdSeeds.map((item) => ({
    ...item,
    userId: uid,
    imageUrl: null,
    reminderDays: null,
    isDemo: true,
    createdAt: ts,
    updatedAt: ts,
  }));

  const householdActions: ProductActionLog[] = householdProducts.map((item, idx) => ({
    id: `demo-ha-${idx + 1}`,
    userId: uid,
    mode: 'household',
    productId: item.id,
    batchId: null,
    productName: item.name,
    actionType: 'added',
    quantityDelta: item.quantity,
    unit: item.unit,
    note: 'Sample demonstration item',
    createdAt: ts,
  }));

  const supermarketCategories: SupermarketCategory[] = DEFAULT_SUPERMARKET_CATEGORIES.map(
    (name, idx) => ({
      id: `demo-cat-${idx + 1}`,
      userId: uid,
      name,
      isDefault: true,
      createdAt: ts,
    })
  );

  const catIdFor = (name: string) =>
    supermarketCategories.find((c) => c.name === name)?.id ?? supermarketCategories[0].id;

  const marketSeed = [
    {
      id: 'demo-sp-1',
      name: 'Farmstead UHT Full Cream Milk 1L',
      category: 'Dairy',
      unit: 'cartons',
      lowStock: 12,
      notes: 'Chilled aisle 2 display.',
      batches: [
        {
          id: 'demo-sb-1',
          batchNumber: 'DY-2401A',
          initial: 24,
          remaining: 6,
          purchaseDate: addDaysIso(today, -14),
          expiryDate: addDaysIso(today, 2),
          notes: 'Front shelf priority rotation',
        },
        {
          id: 'demo-sb-2',
          batchNumber: 'DY-2409B',
          initial: 36,
          remaining: 30,
          purchaseDate: addDaysIso(today, -3),
          expiryDate: addDaysIso(today, 18),
          notes: 'Reserve stockroom pallet',
        },
      ],
    },
    {
      id: 'demo-sp-2',
      name: 'Sparkling Citrus Mineral Drink 500ml',
      category: 'Beverages',
      unit: 'bottles',
      lowStock: 15,
      notes: 'Beverage cooler rack B.',
      batches: [
        {
          id: 'demo-sb-3',
          batchNumber: 'BV-8812',
          initial: 40,
          remaining: 11,
          purchaseDate: addDaysIso(today, -20),
          expiryDate: addDaysIso(today, 32),
          notes: 'Low stock alert threshold test batch',
        },
      ],
    },
    {
      id: 'demo-sp-3',
      name: 'Sea Salt Baked Potato Crisps 150g',
      category: 'Snacks',
      unit: 'packs',
      lowStock: 10,
      notes: 'Snack aisle endcap.',
      batches: [
        {
          id: 'demo-sb-4',
          batchNumber: 'SN-104X',
          initial: 20,
          remaining: 4,
          purchaseDate: addDaysIso(today, -45),
          expiryDate: addDaysIso(today, -2),
          notes: 'Remove expired batch from shelf',
        },
        {
          id: 'demo-sb-5',
          batchNumber: 'SN-118Y',
          initial: 30,
          remaining: 26,
          purchaseDate: addDaysIso(today, -5),
          expiryDate: addDaysIso(today, 60),
          notes: 'Fresh restock batch',
        },
      ],
    },
    {
      id: 'demo-sp-4',
      name: 'Artisan Multigrain Loaf',
      category: 'Bakery',
      unit: 'loaves',
      lowStock: 8,
      notes: 'Daily bakery rack.',
      batches: [
        {
          id: 'demo-sb-6',
          batchNumber: 'BK-5501',
          initial: 16,
          remaining: 5,
          purchaseDate: addDaysIso(today, -2),
          expiryDate: addDaysIso(today, 1),
          notes: 'Move to same-day clearance shelf',
        },
      ],
    },
    {
      id: 'demo-sp-5',
      name: 'Organic Basmati Rice 2kg',
      category: 'Staples & Grains',
      unit: 'bags',
      lowStock: 10,
      notes: 'Dry staples aisle 5.',
      batches: [
        {
          id: 'demo-sb-7',
          batchNumber: 'SG-9021',
          initial: 50,
          remaining: 42,
          purchaseDate: addDaysIso(today, -10),
          expiryDate: addDaysIso(today, 140),
          notes: 'Dry pallet shelf',
        },
      ],
    },
  ];

  const supermarketBatches: SupermarketBatch[] = [];
  const supermarketProducts: SupermarketProduct[] = [];
  const supermarketActions: ProductActionLog[] = [];

  marketSeed.forEach((item) => {
    const categoryId = catIdFor(item.category);
    const prodBatches: SupermarketBatch[] = item.batches.map((b) => ({
      id: b.id,
      userId: uid,
      productId: item.id,
      productName: item.name,
      productUnit: item.unit,
      categoryName: item.category,
      batchNumber: b.batchNumber,
      initialQuantity: b.initial,
      remainingQuantity: b.remaining,
      purchaseDate: b.purchaseDate,
      expiryDate: b.expiryDate,
      notes: b.notes,
      isDemo: true,
      createdAt: ts,
      updatedAt: ts,
    }));
    supermarketBatches.push(...prodBatches);
    supermarketProducts.push({
      id: item.id,
      userId: uid,
      name: item.name,
      categoryId,
      categoryName: item.category,
      unit: item.unit,
      lowStockThreshold: item.lowStock,
      notes: item.notes,
      imageUrl: null,
      reminderDays: null,
      isDemo: true,
      createdAt: ts,
      updatedAt: ts,
      batches: prodBatches,
    });
    prodBatches.forEach((b, idx) => {
      supermarketActions.push({
        id: `demo-sa-${item.id}-${idx + 1}`,
        userId: uid,
        mode: 'supermarket',
        productId: item.id,
        batchId: b.id,
        productName: `${item.name} (${b.batchNumber})`,
        actionType: 'added',
        quantityDelta: b.remainingQuantity,
        unit: item.unit,
        note: 'Sample demonstration batch',
        createdAt: ts,
      });
    });
  });

  return {
    user,
    householdProducts,
    householdActions,
    householdReminderStates: [],
    supermarketCategories,
    supermarketProducts,
    supermarketBatches,
    supermarketActions,
    supermarketReminderStates: [],
    notifications: [],
  };
}
