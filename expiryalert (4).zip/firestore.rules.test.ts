import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';

const ROOT = process.cwd();
const RULES_PATH = path.resolve(ROOT, 'firestore.rules');
const rulesText = fs.readFileSync(RULES_PATH, 'utf8');

function extractBlock(marker: string): string {
  const start = rulesText.indexOf(marker);
  assert.notEqual(start, -1, `Expected block marker not found: ${marker}`);
  const tail = rulesText.slice(start);
  const nextTopMatch = tail.slice(marker.length).search(/\n\s{4}(match \/|function )/);
  return nextTopMatch === -1 ? tail : tail.slice(0, marker.length + nextTopMatch);
}

test('Firestore Rules: Global default-deny safety net is present', () => {
  assert.match(
    rulesText,
    /match \/\{document=\*\*\}[\s\S]*allow read, write: if false;/,
    'Default deny rule must lock down unspecified paths'
  );
});

test('Firestore Rules: Cross-tenant & email verification gate (isVerifiedOwner)', () => {
  assert.match(
    rulesText,
    /function isVerifiedOwner\(userId\)\s*\{\s*return isSignedIn\(\)\s*&&\s*request\.auth\.token\.email_verified == true\s*&&\s*request\.auth\.uid == userId;/,
    'isVerifiedOwner must enforce authentication, email verification, and UID ownership'
  );

  const subcollections = [
    'match /users/{userId}',
    'match /householdProducts/{productId}',
    'match /supermarketCategories/{categoryId}',
    'match /supermarketProducts/{productId}',
    'match /supermarketBatches/{batchId}',
    'match /productActions/{actionId}',
    'match /reminderStates/{stateId}',
    'match /notifications/{notificationId}',
    'match /fcmTokens/{tokenId}',
  ];

  for (const sub of subcollections) {
    assert.ok(rulesText.includes(sub), `Missing subcollection rule block: ${sub}`);
    const block = extractBlock(sub);
    assert.ok(
      block.includes('isVerifiedOwner(userId)'),
      `${sub} must enforce isVerifiedOwner(userId)`
    );
    assert.ok(
      block.includes('isValidId('),
      `${sub} must validate document/path ID format`
    );
  }
});

test('Firestore Rules: Dirty Dozen schema, timestamp, URL & referential integrity checks', () => {
  // 1-4: UID spoofing & immutable ownership
  assert.match(rulesText, /data\.uid == userId/);
  assert.match(rulesText, /data\.userId == userId/);
  assert.match(rulesText, /incoming\(\)\.uid == existing\(\)\.uid/);
  assert.match(rulesText, /incoming\(\)\.userId == existing\(\)\.userId/);

  // 5-6: Closed schemas (hasAll + hasOnly + affectedKeys().hasOnly) prevent shadow/escalation fields
  assert.match(rulesText, /data\.keys\(\)\.hasOnly\(\[/);
  assert.match(rulesText, /incoming\(\)\.diff\(existing\(\)\)\.affectedKeys\(\)\.hasOnly\(\[/);
  assert.match(rulesText, /match \/productActions\/\{actionId\}[\s\S]*allow update: if false;/);
  assert.match(rulesText, /match \/users\/\{userId\}[\s\S]*allow delete: if false;/);

  // 7-8: Referential integrity for supermarket products -> categories and batches -> products
  assert.match(
    rulesText,
    /exists\(\/databases\/\$\(database\)\/documents\/users\/\$\(userId\)\/supermarketCategories\/\$\(incoming\(\)\.categoryId\)\)/
  );
  assert.match(
    rulesText,
    /exists\(\/databases\/\$\(database\)\/documents\/users\/\$\(userId\)\/supermarketProducts\/\$\(incoming\(\)\.productId\)\)/
  );

  // 9-10: Temporal integrity (server timestamps & immutable createdAt)
  assert.match(rulesText, /incoming\(\)\.createdAt == request\.time/);
  assert.match(rulesText, /incoming\(\)\.updatedAt == request\.time/);
  assert.match(rulesText, /incoming\(\)\.createdAt == existing\(\)\.createdAt/);

  // 11-12: Bounds poisoning, hex color & HTTPS-only URL enforcement
  assert.match(rulesText, /data\.quantity >= 0 && data\.quantity <= 1000000/);
  assert.match(rulesText, /data\.remainingQuantity >= 0 && data\.remainingQuantity <= data\.initialQuantity/);
  assert.match(rulesText, /data\.accentColor\.matches\('\^#\[0-9a-fA-F\]\{6\}\$'\)/);
  assert.match(rulesText, /data\[field\]\.matches\('\^https:\/\/\.\*\$'\)/);
  assert.match(rulesText, /id\.matches\('\^\[a-zA-Z0-9_\\\\-\]\+\$'\)/);
});

test('Frontend Security Boundaries: Zero hardcoded secrets or localStorage auth tokens', () => {
  const srcFiles: string[] = [];
  const walk = (dir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (/\.(ts|tsx)$/.test(entry.name)) srcFiles.push(full);
    }
  };
  walk(path.resolve(ROOT, 'src'));

  for (const file of srcFiles) {
    const content = fs.readFileSync(file, 'utf8');
    assert.ok(!content.includes('CRON_SECRET'), `Client file must not reference CRON_SECRET: ${file}`);
    assert.ok(!content.includes('FCM_SERVER_KEY'), `Client file must not reference FCM_SERVER_KEY: ${file}`);
    assert.ok(!content.includes('ea_token'), `Client file must not persist legacy auth tokens: ${file}`);
    assert.ok(!content.includes('apiFetch'), `Client file must not call removed SQLite APIs: ${file}`);
  }

  const demoSandbox = fs.readFileSync(path.resolve(ROOT, 'src/services/demoSandbox.ts'), 'utf8');
  assert.ok(
    !demoSandbox.includes('firebase/firestore'),
    'Demo Sandbox must stay isolated in memory and never write to Firestore'
  );
});

test('Backend & PWA Runtime Verification on http://localhost:3000', async () => {
  const baseUrl = 'http://127.0.0.1:3000';

  const healthRes = await fetch(`${baseUrl}/api/health`);
  assert.equal(healthRes.status, 200);
  const healthJson = (await healthRes.json()) as Record<string, unknown>;
  assert.equal(healthJson.ok, true);
  assert.equal(healthJson.projectId, 'gen-lang-client-0572336529');
  assert.equal('CRON_SECRET' in healthJson, false);
  assert.equal('FCM_SERVER_KEY' in healthJson, false);

  // Unauthenticated push dispatch must fail closed with 401
  const pushUnauth = await fetch(`${baseUrl}/api/push/dispatch`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: 'Test', body: 'Blocked' }),
  });
  assert.equal(pushUnauth.status, 401);

  // Forged bearer token must fail closed with 401
  const pushForged = await fetch(`${baseUrl}/api/push/dispatch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer invalid.forged.token',
    },
    body: JSON.stringify({ title: 'Test', body: 'Blocked' }),
  });
  assert.equal(pushForged.status, 401);

  // Cron endpoint must fail closed (503 when CRON_SECRET unset, or 401 when missing credentials)
  const cronNoAuth = await fetch(`${baseUrl}/api/cron/expiry-reminders`, {
    method: 'POST',
  });
  assert.ok(cronNoAuth.status === 503 || cronNoAuth.status === 401);

  // Unknown API route must return JSON 404
  const unknownApi = await fetch(`${baseUrl}/api/nonexistent-endpoint`);
  assert.equal(unknownApi.status, 404);

  // PWA assets & SPA shell
  const [homeRes, manifestRes, swRes, iconRes] = await Promise.all([
    fetch(`${baseUrl}/`),
    fetch(`${baseUrl}/manifest.webmanifest`),
    fetch(`${baseUrl}/sw.js`),
    fetch(`${baseUrl}/pwa-192x192.png`),
  ]);

  assert.equal(homeRes.status, 200);
  const homeHtml = await homeRes.text();
  assert.match(homeHtml, /<title>ExpiryAlert/i);
  assert.match(homeHtml, /manifest\.webmanifest/);

  assert.equal(manifestRes.status, 200);
  const manifest = (await manifestRes.json()) as { name?: string; display?: string };
  assert.equal(manifest.name, 'ExpiryAlert');
  assert.equal(manifest.display, 'standalone');

  assert.equal(swRes.status, 200);
  const swCode = await swRes.text();
  assert.match(swCode, /periodicsync/);
  assert.match(swCode, /addEventListener\('push'/);

  assert.equal(iconRes.status, 200);
});
