import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import { getApps, initializeApp } from 'firebase-admin/app';
import { getAuth, type DecodedIdToken } from 'firebase-admin/auth';
import { createServer as createViteServer } from 'vite';

interface FirebaseAppletConfig {
  projectId?: string;
  firestoreDatabaseId?: string;
}

function loadFirebaseAppletConfig(): FirebaseAppletConfig {
  try {
    const raw = fs.readFileSync(path.resolve(process.cwd(), 'firebase-applet-config.json'), 'utf8');
    return JSON.parse(raw) as FirebaseAppletConfig;
  } catch {
    return {};
  }
}

const firebaseConfig = loadFirebaseAppletConfig();
const firebaseAdminApp =
  getApps().length > 0
    ? getApps()[0]
    : initializeApp(firebaseConfig.projectId ? { projectId: firebaseConfig.projectId } : undefined);

interface VerifiedRequest extends Request {
  authUser?: DecodedIdToken;
}

async function requireVerifiedFirebaseUser(
  req: VerifiedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const token = header.slice(7).trim();
  if (!token || token.length > 8192) {
    res.status(401).json({ error: 'Invalid authorization token.' });
    return;
  }

  try {
    const decoded = await getAuth(firebaseAdminApp).verifyIdToken(token);
    if (!decoded.email_verified) {
      res.status(403).json({ error: 'Please verify your email address before performing this action.' });
      return;
    }
    req.authUser = decoded;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired Firebase authentication token.' });
  }
}

function safeTimingEqual(a: string, b: string): boolean {
  const hashA = crypto.createHash('sha256').update(a, 'utf8').digest();
  const hashB = crypto.createHash('sha256').update(b, 'utf8').digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

function sanitizeAppRelativeUrl(rawUrl: unknown): string {
  if (typeof rawUrl !== 'string') return '/#/household/reminders';
  const trimmed = rawUrl.trim();
  if (trimmed.startsWith('/#/') && trimmed.length <= 200) {
    return trimmed;
  }
  return '/#/household/reminders';
}

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '512kb' }));

// Baseline security headers compatible with iframe preview
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// ---------------- HEALTH & STATUS ----------------

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'expiryalert',
    projectId: firebaseConfig.projectId ?? null,
    databaseId: firebaseConfig.firestoreDatabaseId ?? null,
    pushGatewayConfigured: Boolean(process.env.FCM_SERVER_KEY?.trim()),
    cronSchedulerConfigured: Boolean(process.env.CRON_SECRET?.trim()),
    timestamp: new Date().toISOString(),
  });
});

// ---------------- AUTHENTICATED PUSH DISPATCH ----------------

app.post('/api/push/dispatch', requireVerifiedFirebaseUser, async (req: VerifiedRequest, res) => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const title = typeof body.title === 'string' ? body.title.trim().slice(0, 140) : '';
  const messageBody = typeof body.body === 'string' ? body.body.trim().slice(0, 400) : '';
  const tag =
    typeof body.tag === 'string' && /^[a-zA-Z0-9_.\-:]{1,80}$/.test(body.tag.trim())
      ? body.tag.trim()
      : 'expiryalert-reminder';
  const url = sanitizeAppRelativeUrl(body.url);

  if (!title || !messageBody) {
    res.status(400).json({ error: 'Notification title and body are required.' });
    return;
  }

  const rawTokens = Array.isArray(body.fcmTokens) ? body.fcmTokens : [];
  const validTokens = rawTokens
    .filter((t): t is string => typeof t === 'string' && t.trim().length >= 20 && t.trim().length <= 512)
    .map((t) => t.trim())
    .slice(0, 5);

  const serverKey = process.env.FCM_SERVER_KEY?.trim();
  if (!serverKey || validTokens.length === 0) {
    res.json({
      ok: true,
      uid: req.authUser?.uid ?? null,
      delivered: 0,
      mode: 'service_worker_local',
    });
    return;
  }

  try {
    const fcmRes = await fetch('https://fcm.googleapis.com/fcm/send', {
      method: 'POST',
      headers: {
        Authorization: `key=${serverKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        registration_ids: validTokens,
        notification: {
          title,
          body: messageBody,
          icon: '/pwa-192x192.png',
          click_action: url,
          tag,
        },
        data: {
          title,
          body: messageBody,
          url,
          tag,
          uid: req.authUser?.uid ?? '',
        },
      }),
    });

    if (!fcmRes.ok) {
      res.status(502).json({ error: 'Push gateway delivery returned an unexpected response.' });
      return;
    }

    const result = (await fcmRes.json()) as { success?: number };
    res.json({
      ok: true,
      uid: req.authUser?.uid ?? null,
      delivered: Number(result.success ?? validTokens.length),
      mode: 'fcm',
    });
  } catch {
    res.status(502).json({ error: 'Unable to reach Firebase Cloud Messaging gateway.' });
  }
});

// ---------------- SCHEDULED REMINDER TRIGGER ----------------

app.post('/api/cron/expiry-reminders', (req, res) => {
  const configuredSecret = process.env.CRON_SECRET?.trim();
  if (!configuredSecret) {
    res.status(503).json({
      error: 'Scheduler secret is not configured on this server.',
    });
    return;
  }

  const authHeader = req.headers.authorization;
  const xCronHeader = req.headers['x-cron-secret'];
  const presented =
    typeof authHeader === 'string' && authHeader.startsWith('Bearer ')
      ? authHeader.slice(7).trim()
      : typeof xCronHeader === 'string'
      ? xCronHeader.trim()
      : '';

  if (!presented) {
    res.status(401).json({ error: 'Missing scheduler authorization credentials.' });
    return;
  }

  if (!safeTimingEqual(presented, configuredSecret)) {
    res.status(403).json({ error: 'Invalid scheduler authorization credentials.' });
    return;
  }

  res.json({
    ok: true,
    checkedAt: new Date().toISOString(),
    projectId: firebaseConfig.projectId ?? null,
    status: 'expiry_reminder_window_verified',
  });
});

// ---------------- API 404 GUARD ----------------

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});

// ---------------- VITE / STATIC SERVER ----------------

const PORT = 3000;
const isProd = process.env.NODE_ENV === 'production';

async function startServer(): Promise<void> {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ExpiryAlert server listening on http://localhost:${PORT}`);
  });
}

void startServer();
