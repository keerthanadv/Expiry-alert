# ExpiryAlert Firestore Security Specification (Phase 0)

## 1. Data Invariants
1. **Strict Multi-User Tenant Isolation**: All application entities (`users`, `householdProducts`, `supermarketCategories`, `supermarketProducts`, `supermarketBatches`, `productActions`, `reminderStates`, `notifications`, `fcmTokens`) live under `/users/{userId}` and require `request.auth != null`, `request.auth.token.email_verified == true`, and `request.auth.uid == userId`.
2. **Identity Integrity**: Every document created inside `/users/{userId}/...` must contain `userId == request.auth.uid` (or `uid == request.auth.uid` on the root user profile) and cannot be reassigned to another `userId` on update (`incoming().userId == existing().userId`).
3. **Referential Integrity**:
   - Creating a `supermarketProduct` requires `categoryId` to reference an existing document in `/users/{userId}/supermarketCategories/{categoryId}`.
   - Creating a `supermarketBatch` requires `productId` to reference an existing document in `/users/{userId}/supermarketProducts/{productId}`.
4. **Immutable Audit & Temporal Integrity**: Every document enforces server timestamps (`createdAt == request.time` on create; `createdAt == existing().createdAt && updatedAt == request.time` on update).
5. **Path & Size Bounds**: Every document ID matches `^[a-zA-Z0-9_-]+$` (`<= 128` chars) and every string/number field enforces explicit type, range, and length caps to prevent resource exhaustion and shadow-field injection.

## 2. Adversarial "Dirty Dozen" Payloads (Must Return PERMISSION_DENIED)
1. **Cross-Tenant Read**: User B (`uid_b`) reads `/users/uid_a/householdProducts/prod_1`.
2. **Cross-Tenant Write**: User B (`uid_b`) creates `/users/uid_a/householdProducts/prod_2` with `userId: "uid_b"`.
3. **Unverified Email Write**: Authenticated User A with `email_verified: false` attempts to create a `householdProduct`.
4. **UID Spoofing inside Subcollection**: User A creates `/users/uid_a/householdProducts/prod_3` with `userId: "uid_b"`.
5. **Shadow / Ghost Field Injection**: User A creates `/users/uid_a` with extra field `isAdmin: true` or `role: "superadmin"`.
6. **Privilege Escalation Update**: User A updates `/users/uid_a` to change `uid` or add `verifiedOverride: true`.
7. **Orphan Batch Creation**: User A creates `/users/uid_a/supermarketBatches/b_1` referencing a non-existent `productId: "missing_prod"`.
8. **Orphan Product Creation**: User A creates `/users/uid_a/supermarketProducts/p_1` referencing a non-existent `categoryId: "missing_cat"`.
9. **Client Timestamp Forgery**: User A creates a `householdProduct` with a spoofed past `createdAt` instead of `request.time`.
10. **Immutable CreatedAt Overwrite**: User A updates a `householdProduct` and alters `createdAt`.
11. **Value / Bounds Poisoning**: User A sets `quantity: -5` or injects a 5,000-char `name` string on a product, or an invalid hex `#ZZZZZZ` in `accentColor`.
12. **Path ID Poisoning**: User A writes to `/users/uid_a/householdProducts/` with malformed ID `../../admin` or >128 chars, or queries another tenant's collection via `list`.
